# Audio assets

The MVP ships with `SilentAudioService`, so no binary audio files are required
for a clean checkout to build and run.

When adding real audio, drop the files here and implement `AudioService`
against your chosen backend. The cue set expected by the game is:

| Cue | Suggested file | Character |
| --- | --- | --- |
| `perfect` | `perfect.wav` | short, bright, ~120 ms |
| `good` | `good.wav` | softer variant of `perfect` |
| `pass` | `pass.wav` | near-silent tick |
| `collision` | `collision.wav` | dull, non-punitive thud |
| `rewindStart` / `rewindLoop` / `rewindEnd` | `rewind_*.wav` | pitch-shiftable loop |
| `comboMilestone` | `combo.wav` | rising interval |
| `menuOpen` / `menuSelect` | `menu_*.wav` | neutral UI clicks |
| ambient | `ambient.ogg` | seamless loop, low energy |

Keep every one-shot under 300 ms and pre-decoded; the game fires cues on the
same frame as the visual, and any decode-on-play latency is immediately audible
as the feedback drifting away from the impact.
