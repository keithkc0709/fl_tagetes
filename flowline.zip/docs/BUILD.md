# Build and release configuration

Nothing in this repository contains credentials, and nothing should. Everything
below uses placeholders you replace locally or in CI secrets.

## Identifiers

| Platform | Placeholder | Where |
| --- | --- | --- |
| Android | `com.example.flowline` | `android/app/build.gradle` → `applicationId` |
| iOS | `com.example.flowline` | Xcode → Runner → Signing & Capabilities |

Set both when you first run `flutter create --org <your.org> ...`, or edit them
afterwards. Keep them identical across stores so analytics and support stay
sane.

## Minimum OS versions

- **Android:** `minSdkVersion 21` (Android 5.0). The game uses no APIs above
  this level; the constraint comes from Flutter itself.
- **iOS:** `13.0`, set in `ios/Runner/Info.plist` (`MinimumOSVersion`) and in
  the Xcode deployment target. Keep the two in sync or archiving will fail.

## Orientation and permissions

Portrait is locked in three places, and all three must agree:

1. `SystemChrome.setPreferredOrientations` in `lib/main.dart`
2. `android:screenOrientation="portrait"` in `AndroidManifest.xml`
3. `UISupportedInterfaceOrientations` in `Info.plist`

The manifest declares **no** permissions. If you add analytics or leaderboards
later you will need `android.permission.INTERNET` — add it then, not
speculatively. Do not add contacts, location, microphone, camera or photo
library; nothing in the design needs them, and a future replay share should use
the system share sheet, which requires no permission at all.

## Android debug build

```bash
flutter run -d <device>
flutter build apk --debug
```

## Android release build

1. Create a keystore (once, and never commit it):

```bash
keytool -genkey -v -keystore ~/flowline-upload.jks \
  -keyalg RSA -keysize 2048 -validity 10000 -alias upload
```

2. Create `android/key.properties` (git-ignored):

```properties
storePassword=<from-your-password-manager>
keyPassword=<from-your-password-manager>
keyAlias=upload
storeFile=/Users/you/flowline-upload.jks
```

3. Wire it into `android/app/build.gradle`:

```groovy
def keystoreProperties = new Properties()
def keystorePropertiesFile = rootProject.file('key.properties')
if (keystorePropertiesFile.exists()) {
    keystoreProperties.load(new FileInputStream(keystorePropertiesFile))
}

android {
    compileSdk 34
    defaultConfig {
        applicationId "com.example.flowline"
        minSdkVersion 21
        targetSdkVersion 34
    }
    signingConfigs {
        release {
            keyAlias keystoreProperties['keyAlias']
            keyPassword keystoreProperties['keyPassword']
            storeFile keystoreProperties['storeFile'] ? file(keystoreProperties['storeFile']) : null
            storePassword keystoreProperties['storePassword']
        }
    }
    buildTypes {
        release {
            signingConfig signingConfigs.release
            minifyEnabled true
            shrinkResources true
        }
    }
}
```

4. Build:

```bash
flutter build appbundle --release
flutter build apk --release --split-per-abi
```

Add `android/key.properties` and `*.jks` to `.gitignore` before your first
commit, not after.

## iOS simulator build

```bash
open -a Simulator
flutter run -d "iPhone 15 Pro"
```

Haptics do nothing on the simulator, and frame timings there are meaningless.

## iOS device build

```bash
open ios/Runner.xcworkspace
```

Set your Team under Signing & Capabilities, pick an automatic provisioning
profile, then:

```bash
flutter run -d <device-id> --profile
```

## iOS archive preparation

```bash
flutter build ipa --release
open build/ios/archive/Runner.xcarchive
```

Before submitting:

- Confirm the display name reads `FLOWLINE` on the home screen.
- Confirm the app has no privacy-relevant data collection to declare. With the
  MVP as shipped, App Privacy is "Data Not Collected" — the installation id
  never leaves the device. **This changes the moment you enable remote
  analytics**; update the declaration in the same release.
- Confirm portrait-only on an iPhone with a Dynamic Island and on an iPad.
- Confirm launch-to-playable on the oldest device you support.

## CI notes

`flutter analyze` and `flutter test` are the gate. The generator invariant tests
are the ones that matter most on every change to obstacles or generation — they
exercise tens of thousands of segment combinations and will catch impossible
geometry that no amount of manual play will find reliably.
