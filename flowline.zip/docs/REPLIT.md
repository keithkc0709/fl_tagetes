# Running FLOWLINE on Replit

FLOWLINE is a Flutter game. Replit cannot build Android APKs or iOS apps — no
Android SDK, no emulator, and certainly no Xcode. What it *can* do is run the
real game, compiled to WebAssembly/JS, in the browser pane. That is genuinely
the same code: the same time controller, the same rewind buffer, the same
generator. Only the packaging differs.

So: use Replit to play, tune and iterate. Use a local machine (or CI) for the
actual store binaries.

---

## 1. Create the repl

**Option A — import from GitHub (recommended).** Push this project to a repo,
then in Replit choose *Create Repl → Import from GitHub*. Pick the **Blank
Repl** / Nix template if asked for a language; the language is determined by
`replit.nix`, not by the template.

**Option B — upload.** Create a Blank Repl, then drag the unzipped project
folder's contents into the file tree. Make sure the dotfiles come across:
`.replit` and `replit.nix` are what make the whole thing work, and file
managers love to hide them.

## 2. Press Run

The first run downloads the Flutter toolchain into the Nix environment and
compiles the whole app. **Expect 3–8 minutes, and expect the console to look
idle for long stretches.** Subsequent runs are 10–30 seconds because
`.dart_tool/` and `.pub-cache/` persist in the repl.

When it finishes you will see:

```
==> serving build/web on 0.0.0.0:8080
```

and the webview pane will show the game. Drag with the mouse exactly as you
would with a thumb: the game listens to raw pointer deltas, so a mouse drag,
a trackpad drag and a touch drag are all the same input.

## 3. The two modes

`scripts/replit_run.sh` reads a `MODE` variable.

| Mode | Command | Use it for |
| --- | --- | --- |
| `prod` (default) | release build, served statically | playing, judging feel, checking frame rate |
| `dev` | `flutter run -d web-server` | rapid iteration — press `R` in the console to hot restart |

To switch, open the Shell and run:

```bash
MODE=dev bash scripts/replit_run.sh
```

Do not tune game feel in `dev`. The debug web build's frame pacing is bad
enough that you will end up compensating for the toolchain instead of the
design, and every number you pick will be wrong on device.

## 4. Running the tests

The test suite is the fastest signal in this project and it needs no browser:

```bash
flutter test
flutter test test/generator_test.dart
flutter analyze
```

Run these in the Shell, not the Run button.

## 5. What works, what doesn't

**Works on web:**

- The full gameplay loop, all eight obstacle families, rewind, scoring, adaptive
  difficulty, themes, the menu, the debug HUD and debug panel.
- Persistence. `shared_preferences` falls back to `localStorage` on web, so your
  high score and settings survive a page reload.
- Pointer input at full fidelity — mouse, trackpad and touch.

**Doesn't, and won't:**

- **Haptics.** The web has no vibration API Flutter targets here, so
  `HapticService` calls are silently dropped. This matters more than it sounds:
  a meaningful slice of FLOWLINE's feedback is haptic, and the game reads
  noticeably flatter without it. Judge that part on a phone.
- **Orientation lock.** `SystemChrome.setPreferredOrientations` is a no-op on
  web. Resize the browser pane to a tall, narrow shape — roughly 9:19.5 — or
  the layout will be technically fine and aesthetically wrong.
- **Android/iOS builds.** No SDK, no signing, no archive. See `docs/BUILD.md`.
- **Real frame timings on a phone.** Browser vsync in a Replit webview is not
  device vsync. Treat web performance as directional only.

## 6. If it fails

**"Flutter is not on PATH"** — the Nix environment did not load. Open the Shell,
run `kill 1`, wait for the repl to restart, press Run again.

**Build runs out of memory or is killed** — release web builds are memory-hungry.
Free RAM by closing other repls, or build once with
`bash scripts/replit_build.sh` in the Shell and then just serve the output:

```bash
cd build/web && python3 -m http.server 8080 --bind 0.0.0.0
```

**Port already in use** — a previous run is still alive. `pkill -f http.server`
or `kill 1`.

**The webview is blank and the console shows a CanvasKit fetch error** — the
CanvasKit renderer pulls a wasm bundle from a CDN on first load. If your repl
has restricted networking, fall back to the HTML renderer by editing the build
line in `scripts/replit_run.sh` to `--web-renderer html`. Expect visibly worse
particle and glow performance; the glow is drawn with mask filters, which the
HTML renderer handles poorly.

**`flutter create` overwrote something** — the run script only calls it when
`web/index.html` is absent, and this repo ships that file precisely so it never
fires. If you deleted `web/` and the script regenerated it, restore
`web/index.html` from git: the shipped one disables browser scroll and zoom,
which the generated one does not, and without that the drag gesture fights the
page.
