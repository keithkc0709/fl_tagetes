# Tuning FLOWLINE

Every number that changes how the game *feels* lives in one file:
`lib/core/game_balance_config.dart`. It is immutable and has a `copyWith`, so
you can A/B a variant without editing the default.

Tune in this order. Time feel first, because everything downstream is judged
relative to it.

## 1. Time feel — the ones that matter most

| Field | Default | What moving it does |
| --- | --- | --- |
| `referenceScrollSpeed` | 1150 px/s | The drag speed that means "1× time". Lower it and the game feels eager; raise it and the player has to work for normal speed. This is the single most important number in the project. |
| `timeScaleCurveExponent` | 0.85 | Below 1 compresses the fast end, so flicks feel controllable. Push toward 1.0 for a rawer, twitchier response. |
| `minActiveTimeScale` | 0.15 | The floor while the thumb is genuinely moving. Too low and slow drags feel broken rather than deliberate. |
| `normalMaxTimeScale` | 1.6 | The ceiling for ordinary scrolling. |
| `maxForwardTimeScale` | 3.6 | The flick-only ceiling. The gap between this and `normalMaxTimeScale` *is* the flick as a mechanic. |
| `flickThresholdSpeed` | 2100 px/s | Where a scroll becomes a flick. |
| `timeScaleSmoothing` | 14 /s | How fast actual time scale chases target. Lower feels heavy and cinematic; higher feels immediate and jittery. |
| `velocitySmoothing` | 18 /s | Smoothing on the raw gesture velocity itself. Raise it if input feels mushy, lower it if it feels noisy. |
| `freezeEpsilon` | 0.02 | Below this, time is considered stopped. |
| `deadZoneSpeed` | 40 px/s | Finger jitter below this does not advance time. |

## 2. Movement mapping

| Field | Default | Effect |
| --- | --- | --- |
| `worldUnitsPerPixel` | 0.115 | Screen pixels dragged → world units travelled. This sets how much ground a swipe covers, independent of time scale. |
| `flingDecay` | 3.2 /s | How long momentum carries after the thumb lifts. |
| `sparkAnchorFraction` | 0.32 | How far up the screen the Spark sits. Higher shows more of what is coming and makes the game easier to read. |

## 3. Rewind

| Field | Default | Effect |
| --- | --- | --- |
| `maxRewindSeconds` | 3.2 | How far back history goes. Memory cost is linear in this. |
| `snapshotInterval` | 1/30 s | Snapshot granularity, in **game time**. |
| `rewindActivationSpeed` | 90 px/s | How decisive a downward drag must be before it counts as rewinding. |
| `autoRewindSeconds` | 1.2 | How far a collision throws you back. |
| `postRewindGrace` | 0.45 s | Invulnerability after an auto-rewind, so you cannot be caught in a loop. |

## 4. Scoring

| Field | Default | Effect |
| --- | --- | --- |
| `perfectThreshold` | 0.82 | Centring precision needed for Perfect. |
| `goodThreshold` | 0.55 | Centring precision needed for Good. |
| `basePoints` | 10 | Points for a Pass. |
| `goodMultiplier` / `perfectMultiplier` | 1.8 / 2.6 | Grade value. |
| `comboStep` | 3 | Clean clears per multiplier step. |
| `comboMultiplierStep` | 0.25 | Size of each step. |
| `maxComboMultiplier` | 4.0 | Ceiling. |

## 5. Difficulty adaptation

| Field | Default | Effect |
| --- | --- | --- |
| `skillRiseRate` | 0.045 | How fast success promotes. |
| `skillFallRate` | 0.12 | How fast failure demotes. Deliberately ~2.7× the rise rate: the game should catch a struggling player quickly and promote a good one slowly. |
| `maxToleranceBoost` | 0.45 | Extra collision leniency at the bottom tier. |
| `stuckToleranceBonus` | 0.15 | Extra leniency for a mechanic the player keeps failing specifically. |
| `speedRangeLow` / `speedRangeHigh` | 0.8 / 1.25 | Obstacle speed multiplier across the tier range. |

## 6. Collision and forgiveness

| Field | Default | Effect |
| --- | --- | --- |
| `sparkRadius` | 3.1 world units | Visual size. |
| `collisionForgiveness` | 0.55 | Subtracted from `sparkRadius` for collision only, so near-misses read as skill rather than as bugs. Raising this is the gentlest possible difficulty reduction. |

## How to tune well

1. **Change one number at a time.** These interact, and a two-variable change
   will teach you nothing about either.
2. **Play in `--profile`, on a device.** Debug builds and browsers both lie
   about frame pacing, and time feel is exactly the thing frame pacing corrupts.
3. **Re-run `flutter test` afterwards.** The generator tests check ~30,000
   segments for impossible geometry. Widening a gap is safe; narrowing anything
   is exactly the change that quietly makes some rare combination unplayable.
4. **Trust the first thirty seconds.** If a change needs a paragraph of
   explanation before it feels right, it doesn't.
