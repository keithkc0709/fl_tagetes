import 'package:flutter/foundation.dart';

/// Canonical event names. Kept as constants so a typo cannot silently create a
/// second, near-identical funnel step.
class AnalyticsEvents {
  const AnalyticsEvents._();

  static const String appOpen = 'app_open';
  static const String sessionStart = 'session_start';
  static const String sessionEnd = 'session_end';
  static const String firstInteraction = 'first_interaction';
  static const String tutorialHintSeen = 'tutorial_hint_seen';
  static const String tutorialComplete = 'tutorial_complete';
  static const String segmentStart = 'segment_start';
  static const String segmentPass = 'segment_pass';
  static const String segmentGood = 'segment_good';
  static const String segmentPerfect = 'segment_perfect';
  static const String segmentFail = 'segment_fail';
  static const String rewindStart = 'rewind_start';
  static const String rewindEnd = 'rewind_end';
  static const String autoRewind = 'auto_rewind';
  static const String comboStarted = 'combo_started';
  static const String comboBroken = 'combo_broken';
  static const String comboMilestone = 'combo_milestone';
  static const String dailyStarted = 'daily_started';
  static const String dailyCompleted = 'daily_completed';
  static const String zenStarted = 'zen_started';
  static const String themeSelected = 'theme_selected';
  static const String settingsChanged = 'settings_changed';
}

@immutable
class AnalyticsEvent {
  final String name;
  final Map<String, Object?> properties;
  final DateTime timestamp;

  AnalyticsEvent(this.name, this.properties) : timestamp = DateTime.now();
}

abstract class AnalyticsService {
  bool get enabled;

  /// Properties merged into every subsequent event (session id, mode, tier).
  void setSuperProperties(Map<String, Object?> properties);

  void track(String name, [Map<String, Object?> properties = const {}]);

  Future<void> flush();
}

/// Development implementation: keeps the last N events in memory and prints in
/// debug builds. No network, no identifiers, no third-party SDK.
class LocalAnalyticsService implements AnalyticsService {
  @override
  final bool enabled;

  final int maxRetained;
  final List<AnalyticsEvent> events = <AnalyticsEvent>[];
  final Map<String, Object?> _superProperties = <String, Object?>{};

  LocalAnalyticsService({this.enabled = true, this.maxRetained = 200});

  @override
  void setSuperProperties(Map<String, Object?> properties) {
    _superProperties.addAll(properties);
  }

  @override
  void track(String name, [Map<String, Object?> properties = const {}]) {
    if (!enabled) return;
    final merged = <String, Object?>{..._superProperties, ...properties};
    events.add(AnalyticsEvent(name, merged));
    if (events.length > maxRetained) events.removeAt(0);
    assert(() {
      debugPrint('[analytics] $name $merged');
      return true;
    }());
  }

  @override
  Future<void> flush() async {}
}

class NoopAnalyticsService implements AnalyticsService {
  @override
  bool get enabled => false;

  @override
  void setSuperProperties(Map<String, Object?> properties) {}

  @override
  void track(String name, [Map<String, Object?> properties = const {}]) {}

  @override
  Future<void> flush() async {}
}
