import 'package:flutter/material.dart';

import 'analytics/analytics_service.dart';
import 'core/design_tokens.dart';
import 'core/feature_flags.dart';
import 'core/game_balance_config.dart';
import 'repositories/profile_repository.dart';
import 'services/audio_service.dart';
import 'services/haptic_service.dart';
import 'themes/theme_catalog.dart';
import 'ui/game_screen.dart';

/// Composition root.
///
/// Every service is constructed here and injected downward. Nothing reaches for
/// a singleton, which is what makes the whole game testable without a device.
class FlowlineApp extends StatelessWidget {
  final ProfileRepository profileRepository;
  final FeatureFlags flags;
  final GameBalanceConfig balance;
  final AnalyticsService analytics;
  final AudioService audio;
  final HapticService haptics;

  const FlowlineApp({
    super.key,
    required this.profileRepository,
    required this.flags,
    required this.balance,
    required this.analytics,
    required this.audio,
    required this.haptics,
  });

  factory FlowlineApp.production() {
    final flags = FeatureFlags.forBuild();
    return FlowlineApp(
      profileRepository: SharedPreferencesProfileRepository(),
      flags: flags,
      balance: const GameBalanceConfig(),
      analytics: flags.enableAnalytics
          ? LocalAnalyticsService()
          : NoopAnalyticsService(),
      audio: SilentAudioService(),
      haptics: SystemHapticService(enabled: flags.enableHaptics),
    );
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'FLOWLINE',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        brightness: Brightness.dark,
        scaffoldBackgroundColor: ThemeCatalog.minimal.backgroundTop,
        colorScheme: ColorScheme.fromSeed(
          seedColor: ThemeCatalog.minimal.accent,
          brightness: Brightness.dark,
        ),
        textTheme: const TextTheme(bodyMedium: Typo.label),
      ),
      home: GameScreen(
        profileRepository: profileRepository,
        flags: flags,
        balance: balance,
        analytics: analytics,
        audio: audio,
        haptics: haptics,
      ),
    );
  }
}
