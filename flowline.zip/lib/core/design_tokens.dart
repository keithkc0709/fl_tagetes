import 'package:flutter/widgets.dart';

/// Centralised, non-gameplay design tokens.
///
/// Anything that affects *balance* lives in [GameBalanceConfig]; anything that
/// affects *presentation* lives here. No magic numbers in widgets.
class Spacing {
  const Spacing._();
  static const double xs = 4.0;
  static const double sm = 8.0;
  static const double md = 16.0;
  static const double lg = 24.0;
  static const double xl = 40.0;
}

class Radii {
  const Radii._();
  static const double sm = 8.0;
  static const double md = 16.0;
  static const double lg = 28.0;
  static const Radius pill = Radius.circular(999.0);
}

class Motion {
  const Motion._();
  static const Duration instant = Duration(milliseconds: 90);
  static const Duration quick = Duration(milliseconds: 180);
  static const Duration normal = Duration(milliseconds: 300);
  static const Duration slow = Duration(milliseconds: 600);
  static const Duration hintCycle = Duration(milliseconds: 2200);
  static const Duration splash = Duration(milliseconds: 550);
}

class Typo {
  const Typo._();
  static const String family = 'monospace';

  static const TextStyle score = TextStyle(
    fontFamily: family,
    fontSize: 34,
    height: 1.0,
    fontWeight: FontWeight.w300,
    letterSpacing: 1.5,
  );
  static const TextStyle combo = TextStyle(
    fontFamily: family,
    fontSize: 15,
    height: 1.0,
    fontWeight: FontWeight.w400,
    letterSpacing: 2.0,
  );
  static const TextStyle label = TextStyle(
    fontFamily: family,
    fontSize: 12,
    height: 1.2,
    fontWeight: FontWeight.w400,
    letterSpacing: 1.0,
  );
  static const TextStyle debug = TextStyle(
    fontFamily: family,
    fontSize: 10,
    height: 1.25,
    fontWeight: FontWeight.w400,
  );
  static const TextStyle menuItem = TextStyle(
    fontFamily: family,
    fontSize: 18,
    height: 1.2,
    fontWeight: FontWeight.w400,
    letterSpacing: 1.5,
  );
}

/// Fixed logical world width. Every gameplay coordinate is expressed in these
/// units, so the game is resolution independent: the renderer derives a single
/// `scale = screenWidthPx / worldWidth` and never bakes device pixels into
/// simulation state.
class WorldMetrics {
  const WorldMetrics._();
  static const double width = 100.0;
  static const double centerX = width / 2.0;

  /// Fraction of the visible height at which the Spark is anchored.
  static const double sparkScreenAnchor = 0.32;

  /// Clamp for extreme aspect ratios so ultra-tall phones do not see a
  /// disproportionate amount of the world.
  static const double minVisibleHeight = 130.0;
  static const double maxVisibleHeight = 260.0;
}
