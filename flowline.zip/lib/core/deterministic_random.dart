/// Deterministic 64-bit xorshift PRNG.
///
/// We deliberately do NOT use `dart:math`'s `Random`, because its algorithm is
/// not specified by the language and may differ between SDK versions or
/// platforms. FLOWLINE's daily challenges, replays and generator tests all
/// require that `(seed, version)` reproduces byte-identical worlds on Android
/// and iOS, so the generator must own its own bit-mixing.
class DeterministicRandom {
  static const int _mask = 0x3FFFFFFFFFFFFFFF;

  int _state;

  DeterministicRandom(int seed) : _state = _normalize(seed);

  static int _normalize(int seed) {
    final s = (seed ^ 0x2545F4914F6CDD1D) & _mask;
    return s == 0 ? 0x9E3779B97F4A7C15 & _mask : s;
  }

  /// Current internal state. Exposed so a generator can be forked or resumed.
  int get state => _state;
  set state(int value) => _state = _normalize(value);

  int nextRaw() {
    var x = _state;
    x ^= (x << 13) & _mask;
    x ^= x >> 7;
    x ^= (x << 17) & _mask;
    _state = x & _mask;
    if (_state == 0) _state = 0x9E3779B9;
    return _state;
  }

  /// Uniform double in `[0, 1)`.
  double nextDouble() => (nextRaw() % 1000000007) / 1000000007.0;

  /// Uniform integer in `[0, max)`.
  int nextIntBelow(int max) {
    assert(max > 0, 'max must be positive');
    return nextRaw() % max;
  }

  double range(double min, double max) => min + (max - min) * nextDouble();

  int rangeInt(int minInclusive, int maxInclusive) =>
      minInclusive + nextIntBelow(maxInclusive - minInclusive + 1);

  bool chance(double probability) => nextDouble() < probability;

  int sign() => nextRaw().isEven ? 1 : -1;

  T pick<T>(List<T> items) {
    assert(items.isNotEmpty, 'cannot pick from an empty list');
    return items[nextIntBelow(items.length)];
  }

  /// Stable hash of two integers. Used to derive a per-segment seed from the
  /// run seed and the segment index, so segment N is reproducible without
  /// replaying segments 0..N-1 through the same stream.
  static int hash2(int a, int b) {
    var h = (a * 0x27220A95) & _mask;
    h ^= (b + 0x9E3779B9 + ((h << 6) & _mask) + (h >> 2)) & _mask;
    h ^= h >> 31;
    return h & _mask;
  }
}
