import 'package:flutter/foundation.dart';

/// Compile-time-ish feature gating.
///
/// Monetization and networked features are OFF for the MVP; their interfaces
/// exist so they can be switched on without touching gameplay code.
@immutable
class FeatureFlags {
  final bool enableDailyMode;
  final bool enableZenMode;
  final bool enableAnalytics;
  final bool enableLeaderboard;
  final bool enableRewardedAds;
  final bool enablePurchases;
  final bool enableReplaySharing;
  final bool enableDebugHud;
  final bool enableDebugPanel;
  final bool enableAdaptiveDifficulty;
  final bool enableHaptics;
  final bool logRawInputTrajectories;

  const FeatureFlags({
    this.enableDailyMode = true,
    this.enableZenMode = true,
    this.enableAnalytics = true,
    this.enableLeaderboard = false,
    this.enableRewardedAds = false,
    this.enablePurchases = false,
    this.enableReplaySharing = false,
    this.enableDebugHud = false,
    this.enableDebugPanel = false,
    this.enableAdaptiveDifficulty = true,
    this.enableHaptics = true,
    this.logRawInputTrajectories = false,
  });

  /// Debug tooling is available only in debug builds, regardless of what a
  /// stray configuration says. `kDebugMode` is tree-shaken in release.
  static const FeatureFlags development = FeatureFlags(
    enableDebugHud: true,
    enableDebugPanel: true,
  );

  static const FeatureFlags production = FeatureFlags();

  static FeatureFlags forBuild() => kDebugMode ? development : production;

  FeatureFlags copyWith({
    bool? enableDailyMode,
    bool? enableZenMode,
    bool? enableAnalytics,
    bool? enableLeaderboard,
    bool? enableRewardedAds,
    bool? enablePurchases,
    bool? enableReplaySharing,
    bool? enableDebugHud,
    bool? enableDebugPanel,
    bool? enableAdaptiveDifficulty,
    bool? enableHaptics,
    bool? logRawInputTrajectories,
  }) {
    return FeatureFlags(
      enableDailyMode: enableDailyMode ?? this.enableDailyMode,
      enableZenMode: enableZenMode ?? this.enableZenMode,
      enableAnalytics: enableAnalytics ?? this.enableAnalytics,
      enableLeaderboard: enableLeaderboard ?? this.enableLeaderboard,
      enableRewardedAds: enableRewardedAds ?? this.enableRewardedAds,
      enablePurchases: enablePurchases ?? this.enablePurchases,
      enableReplaySharing: enableReplaySharing ?? this.enableReplaySharing,
      enableDebugHud: (enableDebugHud ?? this.enableDebugHud) && kDebugMode,
      enableDebugPanel: (enableDebugPanel ?? this.enableDebugPanel) && kDebugMode,
      enableAdaptiveDifficulty:
          enableAdaptiveDifficulty ?? this.enableAdaptiveDifficulty,
      enableHaptics: enableHaptics ?? this.enableHaptics,
      logRawInputTrajectories:
          (logRawInputTrajectories ?? this.logRawInputTrajectories) && kDebugMode,
    );
  }
}
