import 'package:flutter/foundation.dart';

/// THE tuning surface for FLOWLINE.
///
/// Every number that changes how the game *feels* is here. Systems receive a
/// config instance by injection; nothing reads a global. Changing feel should
/// never require editing a system.
@immutable
class GameBalanceConfig {
  // ---------------------------------------------------------------- gesture
  /// World units advanced per logical pixel of forward (upward) drag.
  final double scrollSensitivity;

  /// Scroll speed (logical px/s) that maps to 1.0x simulation speed.
  final double referenceScrollSpeed;

  /// Exponent applied to normalised scroll speed. <1 compresses the range and
  /// makes slow drags more expressive; >1 makes fast flicks more dramatic.
  final double speedCurveExponent;

  /// Below this scroll speed the simulation eases to a full freeze.
  final double deadZoneSpeed;

  /// Lower bound of forward simulation speed while the thumb is genuinely moving.
  final double minForwardTimeScale;

  /// Cap applied while scrolling below [flickThresholdSpeed].
  final double normalMaxTimeScale;

  /// Absolute cap, reachable only by a deliberate flick.
  final double maxForwardTimeScale;

  final double flickThresholdSpeed;

  /// Smoothing rate for the measured scroll velocity (higher = twitchier).
  final double velocitySmoothing;

  /// Smoothing rates for the simulation speed itself.
  final double timeAccelRate;
  final double timeDecelRate;

  /// |timeScale| below this counts as frozen.
  final double freezeEpsilon;

  // ---------------------------------------------------------------- inertia
  final double maxFlingVelocity;
  final double flingDecay;
  final double flingCutoff;

  /// Real delta-time is clamped to this to survive stalls without teleporting.
  final double maxRealDelta;

  // ----------------------------------------------------------------- rewind
  final double rewindActivationSpeed;
  final double rewindSensitivity;
  final double maxRewindRate;
  final double maxRewindSeconds;

  /// Game-time spacing between state snapshots.
  final double snapshotInterval;

  final double autoRewindSeconds;
  final double autoRewindRate;

  /// After an auto-rewind the player gets a brief window where hazards cannot
  /// kill them again, so a bad state cannot loop.
  final double postRewindGraceSeconds;

  // ------------------------------------------------------------------ world
  final double sparkRadius;
  final double segmentLength;

  /// How many screens of content to keep generated ahead of the Spark.
  final double lookaheadScreens;

  /// Screens of content kept behind before recycling (must exceed rewind reach).
  final double trailingScreens;

  /// Shrinks the effective collision radius. Pure generosity: the player reads
  /// a near miss as a near miss, not as an unfair hit.
  final double collisionForgiveness;

  // ---------------------------------------------------------------- scoring
  /// Precision (0..1, 1 = dead centre of the safe window) needed for a grade.
  final double perfectThreshold;
  final double goodThreshold;

  final int basePoints;
  final double goodMultiplier;
  final double perfectMultiplier;

  /// Perfects needed per combo-multiplier step.
  final int comboStep;
  final double comboMultiplierStep;
  final double maxComboMultiplier;

  // ------------------------------------------------------------- difficulty
  final double skillRiseRate;
  final double skillFallRate;
  final double failSkillPenalty;
  final double manualRewindSkillPenalty;

  /// Multiplier applied to safe-window sizes at skill 0 (fully struggling).
  final double maxToleranceBoost;

  /// Multiplier applied to obstacle speeds at skill 0.
  final double minSpeedScale;

  // ------------------------------------------------------------------- feel
  final double shakeMagnitude;
  final double shakeDuration;
  final double perfectPulseDuration;
  final int maxParticles;

  const GameBalanceConfig({
    this.scrollSensitivity = 0.115,
    this.referenceScrollSpeed = 1150.0,
    this.speedCurveExponent = 0.85,
    this.deadZoneSpeed = 26.0,
    this.minForwardTimeScale = 0.15,
    this.normalMaxTimeScale = 1.6,
    this.maxForwardTimeScale = 3.6,
    this.flickThresholdSpeed = 2100.0,
    this.velocitySmoothing = 18.0,
    this.timeAccelRate = 14.0,
    this.timeDecelRate = 22.0,
    this.freezeEpsilon = 0.02,
    this.maxFlingVelocity = 6000.0,
    this.flingDecay = 3.4,
    this.flingCutoff = 40.0,
    this.maxRealDelta = 0.05,
    this.rewindActivationSpeed = 90.0,
    this.rewindSensitivity = 0.0016,
    this.maxRewindRate = 2.4,
    this.maxRewindSeconds = 3.2,
    this.snapshotInterval = 1.0 / 30.0,
    this.autoRewindSeconds = 1.15,
    this.autoRewindRate = 4.5,
    this.postRewindGraceSeconds = 0.35,
    this.sparkRadius = 3.1,
    this.segmentLength = 130.0,
    this.lookaheadScreens = 2.2,
    this.trailingScreens = 1.4,
    this.collisionForgiveness = 0.55,
    this.perfectThreshold = 0.72,
    this.goodThreshold = 0.38,
    this.basePoints = 10,
    this.goodMultiplier = 1.6,
    this.perfectMultiplier = 2.6,
    this.comboStep = 3,
    this.comboMultiplierStep = 0.25,
    this.maxComboMultiplier = 4.0,
    this.skillRiseRate = 0.045,
    this.skillFallRate = 0.09,
    this.failSkillPenalty = 0.12,
    this.manualRewindSkillPenalty = 0.02,
    this.maxToleranceBoost = 1.45,
    this.minSpeedScale = 0.72,
    this.shakeMagnitude = 5.0,
    this.shakeDuration = 0.22,
    this.perfectPulseDuration = 0.3,
    this.maxParticles = 160,
  });

  /// Zen: no meaningful failure, wide windows, slow mechanisms.
  GameBalanceConfig get zen => copyWith(
        maxForwardTimeScale: 2.4,
        normalMaxTimeScale: 1.2,
        collisionForgiveness: 1.6,
        maxToleranceBoost: 1.9,
        minSpeedScale: 0.55,
        autoRewindSeconds: 0.9,
        shakeMagnitude: 1.5,
      );

  GameBalanceConfig copyWith({
    double? scrollSensitivity,
    double? referenceScrollSpeed,
    double? speedCurveExponent,
    double? deadZoneSpeed,
    double? minForwardTimeScale,
    double? normalMaxTimeScale,
    double? maxForwardTimeScale,
    double? flickThresholdSpeed,
    double? velocitySmoothing,
    double? timeAccelRate,
    double? timeDecelRate,
    double? freezeEpsilon,
    double? maxFlingVelocity,
    double? flingDecay,
    double? flingCutoff,
    double? maxRealDelta,
    double? rewindActivationSpeed,
    double? rewindSensitivity,
    double? maxRewindRate,
    double? maxRewindSeconds,
    double? snapshotInterval,
    double? autoRewindSeconds,
    double? autoRewindRate,
    double? postRewindGraceSeconds,
    double? sparkRadius,
    double? segmentLength,
    double? lookaheadScreens,
    double? trailingScreens,
    double? collisionForgiveness,
    double? perfectThreshold,
    double? goodThreshold,
    int? basePoints,
    double? goodMultiplier,
    double? perfectMultiplier,
    int? comboStep,
    double? comboMultiplierStep,
    double? maxComboMultiplier,
    double? skillRiseRate,
    double? skillFallRate,
    double? failSkillPenalty,
    double? manualRewindSkillPenalty,
    double? maxToleranceBoost,
    double? minSpeedScale,
    double? shakeMagnitude,
    double? shakeDuration,
    double? perfectPulseDuration,
    int? maxParticles,
  }) {
    return GameBalanceConfig(
      scrollSensitivity: scrollSensitivity ?? this.scrollSensitivity,
      referenceScrollSpeed: referenceScrollSpeed ?? this.referenceScrollSpeed,
      speedCurveExponent: speedCurveExponent ?? this.speedCurveExponent,
      deadZoneSpeed: deadZoneSpeed ?? this.deadZoneSpeed,
      minForwardTimeScale: minForwardTimeScale ?? this.minForwardTimeScale,
      normalMaxTimeScale: normalMaxTimeScale ?? this.normalMaxTimeScale,
      maxForwardTimeScale: maxForwardTimeScale ?? this.maxForwardTimeScale,
      flickThresholdSpeed: flickThresholdSpeed ?? this.flickThresholdSpeed,
      velocitySmoothing: velocitySmoothing ?? this.velocitySmoothing,
      timeAccelRate: timeAccelRate ?? this.timeAccelRate,
      timeDecelRate: timeDecelRate ?? this.timeDecelRate,
      freezeEpsilon: freezeEpsilon ?? this.freezeEpsilon,
      maxFlingVelocity: maxFlingVelocity ?? this.maxFlingVelocity,
      flingDecay: flingDecay ?? this.flingDecay,
      flingCutoff: flingCutoff ?? this.flingCutoff,
      maxRealDelta: maxRealDelta ?? this.maxRealDelta,
      rewindActivationSpeed:
          rewindActivationSpeed ?? this.rewindActivationSpeed,
      rewindSensitivity: rewindSensitivity ?? this.rewindSensitivity,
      maxRewindRate: maxRewindRate ?? this.maxRewindRate,
      maxRewindSeconds: maxRewindSeconds ?? this.maxRewindSeconds,
      snapshotInterval: snapshotInterval ?? this.snapshotInterval,
      autoRewindSeconds: autoRewindSeconds ?? this.autoRewindSeconds,
      autoRewindRate: autoRewindRate ?? this.autoRewindRate,
      postRewindGraceSeconds:
          postRewindGraceSeconds ?? this.postRewindGraceSeconds,
      sparkRadius: sparkRadius ?? this.sparkRadius,
      segmentLength: segmentLength ?? this.segmentLength,
      lookaheadScreens: lookaheadScreens ?? this.lookaheadScreens,
      trailingScreens: trailingScreens ?? this.trailingScreens,
      collisionForgiveness: collisionForgiveness ?? this.collisionForgiveness,
      perfectThreshold: perfectThreshold ?? this.perfectThreshold,
      goodThreshold: goodThreshold ?? this.goodThreshold,
      basePoints: basePoints ?? this.basePoints,
      goodMultiplier: goodMultiplier ?? this.goodMultiplier,
      perfectMultiplier: perfectMultiplier ?? this.perfectMultiplier,
      comboStep: comboStep ?? this.comboStep,
      comboMultiplierStep: comboMultiplierStep ?? this.comboMultiplierStep,
      maxComboMultiplier: maxComboMultiplier ?? this.maxComboMultiplier,
      skillRiseRate: skillRiseRate ?? this.skillRiseRate,
      skillFallRate: skillFallRate ?? this.skillFallRate,
      failSkillPenalty: failSkillPenalty ?? this.failSkillPenalty,
      manualRewindSkillPenalty:
          manualRewindSkillPenalty ?? this.manualRewindSkillPenalty,
      maxToleranceBoost: maxToleranceBoost ?? this.maxToleranceBoost,
      minSpeedScale: minSpeedScale ?? this.minSpeedScale,
      shakeMagnitude: shakeMagnitude ?? this.shakeMagnitude,
      shakeDuration: shakeDuration ?? this.shakeDuration,
      perfectPulseDuration: perfectPulseDuration ?? this.perfectPulseDuration,
      maxParticles: maxParticles ?? this.maxParticles,
    );
  }
}
