import 'dart:math' as math;

/// Full turn in radians.
const double tau = math.pi * 2.0;

double clampd(double v, double lo, double hi) => v < lo ? lo : (v > hi ? hi : v);

double lerpd(double a, double b, double t) => a + (b - a) * t;

/// Frame-rate independent exponential approach.
///
/// Using `1 - exp(-rate * dt)` instead of a fixed lerp factor guarantees that
/// the smoothing behaves identically at 60Hz, 90Hz and 120Hz. This is critical:
/// the whole game-feel of FLOWLINE depends on time-scale smoothing being a
/// function of *real seconds*, never of frame count.
double approach(double current, double target, double rate, double dt) {
  if (rate <= 0.0 || dt <= 0.0) return target;
  final f = 1.0 - math.exp(-rate * dt);
  return current + (target - current) * f;
}

double smoothStep(double edge0, double edge1, double x) {
  if (edge1 <= edge0) return x < edge0 ? 0.0 : 1.0;
  final t = clampd((x - edge0) / (edge1 - edge0), 0.0, 1.0);
  return t * t * (3.0 - 2.0 * t);
}

double wrapAngle(double a) {
  var r = a % tau;
  if (r < 0) r += tau;
  return r;
}

/// Shortest signed delta from [a] to [b], in `(-pi, pi]`.
double signedAngleDelta(double a, double b) {
  var d = (b - a) % tau;
  if (d > math.pi) d -= tau;
  if (d < -math.pi) d += tau;
  return d;
}

/// Absolute angular distance between two angles, in `[0, pi]`.
double angularDistance(double a, double b) => signedAngleDelta(a, b).abs();

double distance(double ax, double ay, double bx, double by) {
  final dx = ax - bx;
  final dy = ay - by;
  return math.sqrt(dx * dx + dy * dy);
}

/// Triangle wave in `[0, 1]` with period 1. Used for oscillators that should
/// feel mechanical rather than sinusoidal.
double triangle01(double phase) {
  final p = phase - phase.floorToDouble();
  return p < 0.5 ? p * 2.0 : 2.0 - p * 2.0;
}

/// Bounce easing in `[0, 1]`: fast at the floor, slow at the apex.
double bounce01(double phase) {
  final p = phase - phase.floorToDouble();
  final s = math.sin(p * math.pi);
  return s.abs();
}

/// Shortest distance from point `p` to the segment `a`-`b`.
double distancePointSegment(
  double px,
  double py,
  double ax,
  double ay,
  double bx,
  double by,
) {
  final abx = bx - ax;
  final aby = by - ay;
  final lengthSquared = abx * abx + aby * aby;
  if (lengthSquared <= 1e-9) return distance(px, py, ax, ay);
  var t = ((px - ax) * abx + (py - ay) * aby) / lengthSquared;
  t = clampd(t, 0.0, 1.0);
  return distance(px, py, ax + abx * t, ay + aby * t);
}
