import 'dart:math' as math;

import '../../core/design_tokens.dart';
import '../../core/math_utils.dart';

/// The centre line the Spark travels along.
///
/// A gentle, long-wavelength sway keeps the corridor from reading as a ruler
/// while staying completely predictable — the player can always see where the
/// line is going before they get there.
class LanePath {
  final double amplitude;
  final double wavelength;

  const LanePath({this.amplitude = 3.0, this.wavelength = 260.0});

  static const LanePath straight = LanePath(amplitude: 0.0);

  double xAt(double y) {
    if (amplitude <= 0.0) return WorldMetrics.centerX;
    return WorldMetrics.centerX +
        amplitude * math.sin(tau * y / wavelength);
  }
}
