import 'dart:math' as math;
import 'dart:typed_data';

import '../../core/game_balance_config.dart';
import '../../core/math_utils.dart';
import '../../render/render_context.dart';
import 'lane_path.dart';

/// The player's avatar: a single luminous circle.
///
/// Abstract on purpose — no face, no gender, no cultural read — so cosmetic
/// skins can change everything about how it looks without touching a hitbox.
class Spark {
  final GameBalanceConfig cfg;
  final LanePath path;

  Spark(this.cfg, {this.path = const LanePath()});

  double x = 0.0;
  double y = 0.0;

  /// Decaying 0..1 used for the success pulse.
  double pulse = 0.0;

  /// Decaying 0..1 used for the impact flash.
  double impact = 0.0;

  double get radius => cfg.sparkRadius;

  /// Radius actually used for collision. Slightly smaller than the drawn
  /// radius: the player should never lose to a pixel they could not see.
  double get collisionRadius =>
      math.max(0.6, cfg.sparkRadius - cfg.collisionForgiveness);

  static const int _trailCapacity = 26;
  final Float64List _trailX = Float64List(_trailCapacity);
  final Float64List _trailY = Float64List(_trailCapacity);
  int _trailLength = 0;

  int get trailLength => _trailLength;

  void syncTo(double flowPosition) {
    y = flowPosition;
    x = path.xAt(flowPosition);
  }

  void update(double realDt, {required bool rewinding}) {
    pulse = math.max(0.0, pulse - realDt / cfg.perfectPulseDuration);
    impact = math.max(0.0, impact - realDt / 0.35);

    if (rewinding) {
      while (_trailLength > 0 && _trailY[_trailLength - 1] > y + 0.4) {
        _trailLength--;
      }
      return;
    }

    if (_trailLength == 0 ||
        (y - _trailY[_trailLength - 1]).abs() > 1.4) {
      if (_trailLength == _trailCapacity) {
        _trailX.setRange(0, _trailCapacity - 1, _trailX, 1);
        _trailY.setRange(0, _trailCapacity - 1, _trailY, 1);
        _trailLength--;
      }
      _trailX[_trailLength] = x;
      _trailY[_trailLength] = y;
      _trailLength++;
    }
  }

  void triggerPulse() => pulse = 1.0;

  void triggerImpact() => impact = 1.0;

  void reset() {
    pulse = 0.0;
    impact = 0.0;
    _trailLength = 0;
  }

  void render(RenderContext ctx) {
    final theme = ctx.theme;

    for (var i = 0; i < _trailLength; i++) {
      final t = (i + 1) / _trailLength;
      final r = radius * (0.18 + 0.55 * t);
      ctx.fill.color = theme.sparkHalo.withOpacity(0.06 + 0.20 * t);
      ctx.canvas.drawCircle(
        ctx.sp(_trailX[i], _trailY[i]),
        ctx.sl(r),
        ctx.fill,
      );
    }

    final pulseScale = 1.0 + 0.55 * pulse + 0.25 * impact;
    ctx.drawGlow(
      x,
      y,
      radius * 2.6 * pulseScale,
      impact > 0.01 ? theme.hazardEdge : theme.sparkHalo,
      intensity: 0.9 + pulse,
    );

    ctx.fill.color = theme.sparkHalo.withOpacity(0.35);
    ctx.canvas.drawCircle(
      ctx.sp(x, y),
      ctx.sl(radius * 1.55 * pulseScale),
      ctx.fill,
    );

    ctx.fill.color = theme.sparkCore;
    ctx.canvas.drawCircle(ctx.sp(x, y), ctx.sl(radius), ctx.fill);

    if (pulse > 0.01) {
      ctx.stroke
        ..color = theme.accent.withOpacity(clampd(pulse, 0.0, 1.0) * 0.8)
        ..strokeWidth = ctx.sl(0.5);
      ctx.canvas.drawCircle(
        ctx.sp(x, y),
        ctx.sl(radius * (1.6 + 3.4 * (1.0 - pulse))),
        ctx.stroke,
      );
    }
  }
}
