import 'dart:math' as math;

import 'package:flutter/foundation.dart';

import '../../core/game_balance_config.dart';
import '../../core/math_utils.dart';
import '../obstacles/obstacle_family.dart';
import '../../models/score_event.dart';

/// Immutable difficulty view handed to the generator.
@immutable
class DifficultySnapshot {
  /// 0 onboarding, 1 very easy, 2 easy, 3 normal, 4 challenging, 5 expert.
  final int tier;

  /// Multiplier applied to safe-window sizes (>= 1 makes life easier).
  final double toleranceMultiplier;

  /// Multiplier applied to mechanism speeds (<= 1 makes life easier).
  final double speedMultiplier;

  const DifficultySnapshot({
    required this.tier,
    required this.toleranceMultiplier,
    required this.speedMultiplier,
  });

  static const DifficultySnapshot onboarding = DifficultySnapshot(
    tier: 0,
    toleranceMultiplier: 1.45,
    speedMultiplier: 0.7,
  );
}

/// A deliberately small local skill model.
///
/// It is never surfaced to the player. No "difficulty reduced" toast, no
/// visible tier. The player should only ever notice that the game seems to
/// understand them.
class AdaptiveDifficulty {
  final GameBalanceConfig cfg;
  final bool enabled;

  AdaptiveDifficulty(this.cfg, {this.enabled = true, double initialSkill = 0.35})
      : _skill = clampd(initialSkill, 0.0, 1.0);

  double _skill;
  double _precisionAverage = 0.5;
  int _consecutiveFailures = 0;
  int _segmentsSinceFailure = 0;

  ObstacleFamily? _lastFailedFamily;
  int _sameFamilyFailures = 0;

  double get skill => _skill;
  double get precisionAverage => _precisionAverage;
  int get consecutiveFailures => _consecutiveFailures;

  /// Tier rises through six bands. The bands are wide at the bottom so a
  /// struggling player is not yanked upward by a single lucky pass.
  int get tier {
    if (!enabled) return 3;
    if (_skill < 0.08) return 0;
    if (_skill < 0.24) return 1;
    if (_skill < 0.42) return 2;
    if (_skill < 0.62) return 3;
    if (_skill < 0.82) return 4;
    return 5;
  }

  double get toleranceMultiplier {
    if (!enabled) return 1.0;
    // Interpolates from maxToleranceBoost at skill 0 down to 1.0 at skill 1.
    final base = lerpd(cfg.maxToleranceBoost, 1.0, _skill);
    // Extra mercy when the player is stuck on one specific mechanic.
    final stuckBonus = math.min(_sameFamilyFailures, 4) * 0.05;
    return base + stuckBonus;
  }

  double get speedMultiplier {
    if (!enabled) return 1.0;
    return lerpd(cfg.minSpeedScale, 1.08, _skill);
  }

  DifficultySnapshot snapshot() => DifficultySnapshot(
        tier: tier,
        toleranceMultiplier: toleranceMultiplier,
        speedMultiplier: speedMultiplier,
      );

  void registerResult(Grade grade, double precision, ObstacleFamily family) {
    if (grade == Grade.fail) {
      _consecutiveFailures++;
      _segmentsSinceFailure = 0;
      if (_lastFailedFamily == family) {
        _sameFamilyFailures++;
      } else {
        _lastFailedFamily = family;
        _sameFamilyFailures = 1;
      }
      _skill = clampd(
        _skill - cfg.failSkillPenalty * (1.0 + _consecutiveFailures * 0.3),
        0.0,
        1.0,
      );
      return;
    }

    _consecutiveFailures = 0;
    _segmentsSinceFailure++;
    if (_sameFamilyFailures > 0 && family == _lastFailedFamily) {
      _sameFamilyFailures = math.max(0, _sameFamilyFailures - 1);
    }

    _precisionAverage = lerpd(_precisionAverage, precision, 0.25);

    // Only genuinely clean play raises skill, and it raises it slowly. Ramping
    // difficulty faster than a player's actual learning curve is the classic
    // way to make an endless game feel unfair.
    final quality = switch (grade) {
      Grade.perfect => 1.0,
      Grade.good => 0.55,
      Grade.pass => 0.2,
      Grade.fail => 0.0,
    };
    _skill = clampd(_skill + cfg.skillRiseRate * quality, 0.0, 1.0);
  }

  /// Manual rewinds are a mild signal of struggle, not a failure.
  void registerManualRewind() {
    if (!enabled) return;
    _skill = clampd(_skill - cfg.manualRewindSkillPenalty, 0.0, 1.0);
  }

  void reset({double? skill}) {
    _skill = clampd(skill ?? _skill, 0.0, 1.0);
    _precisionAverage = 0.5;
    _consecutiveFailures = 0;
    _segmentsSinceFailure = 0;
    _lastFailedFamily = null;
    _sameFamilyFailures = 0;
  }
}
