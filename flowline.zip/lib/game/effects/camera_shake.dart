import 'dart:math' as math;

import '../../core/game_balance_config.dart';

/// Short, decaying positional shake.
///
/// Capped hard: shake that outlives the impact reads as a bug, and shake that
/// exceeds a few pixels makes a timing game unreadable at exactly the moment
/// the player most needs to read it.
class CameraShake {
  final GameBalanceConfig cfg;

  CameraShake(this.cfg);

  double _remaining = 0.0;
  double _magnitude = 0.0;
  double _seed = 0.0;

  double offsetX = 0.0;
  double offsetY = 0.0;

  bool get active => _remaining > 0.0;

  void trigger({double intensity = 1.0}) {
    _remaining = cfg.shakeDuration;
    _magnitude = cfg.shakeMagnitude * intensity;
    _seed += 1.37;
  }

  void update(double realDt, {required bool reducedMotion}) {
    if (_remaining <= 0.0) {
      offsetX = 0.0;
      offsetY = 0.0;
      return;
    }
    _remaining = math.max(0.0, _remaining - realDt);
    final falloff = _remaining / cfg.shakeDuration;
    final amount = _magnitude * falloff * falloff * (reducedMotion ? 0.25 : 1.0);
    final phase = (cfg.shakeDuration - _remaining) * 58.0 + _seed;
    offsetX = math.sin(phase * 1.7) * amount;
    offsetY = math.sin(phase * 2.3 + 1.1) * amount * 0.6;
  }

  void reset() {
    _remaining = 0.0;
    offsetX = 0.0;
    offsetY = 0.0;
  }
}
