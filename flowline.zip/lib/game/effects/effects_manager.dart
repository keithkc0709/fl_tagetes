import 'dart:ui';

import '../../core/game_balance_config.dart';
import '../../models/score_event.dart';
import '../../render/render_context.dart';
import '../../services/audio_service.dart';
import '../../services/haptic_service.dart';
import '../../settings/settings_model.dart';
import '../../themes/game_theme.dart';
import 'camera_shake.dart';
import 'particle_system.dart';

/// Routes gameplay events to particles, shake, audio and haptics.
///
/// Centralised so feedback stays consistent and so accessibility settings are
/// honoured in exactly one place instead of being re-checked at every call site.
class EffectsManager {
  final GameBalanceConfig cfg;
  final AudioService audio;
  final HapticService haptics;

  final ParticleSystem particles;
  final CameraShake shake;

  GameSettings settings;

  EffectsManager({
    required this.cfg,
    required this.audio,
    required this.haptics,
    required this.settings,
  })  : particles = ParticleSystem(cfg),
        shake = CameraShake(cfg);

  void onScore(ScoreEvent event, GameTheme theme, double x, double y) {
    switch (event.grade) {
      case Grade.perfect:
        audio.play(AudioCue.perfect);
        haptics.fire(HapticStrength.light);
        _burst(x, y, theme.accent, 16, 34.0, 0.6, 1.0);
      case Grade.good:
        audio.play(AudioCue.good);
        haptics.fire(HapticStrength.selection);
        _burst(x, y, theme.particle, 8, 22.0, 0.45, 0.8);
      case Grade.pass:
        audio.play(AudioCue.pass, volumeScale: 0.6);
        _burst(x, y, theme.particle, 4, 16.0, 0.35, 0.6);
      case Grade.fail:
        onCollision(theme, x, y);
    }
  }

  void onCollision(GameTheme theme, double x, double y) {
    audio.play(AudioCue.collision);
    haptics.fire(HapticStrength.heavy);
    shake.trigger();
    _burst(x, y, theme.hazardEdge, 22, 46.0, 0.5, 1.1);
  }

  void onNearMiss(GameTheme theme, double x, double y) {
    audio.play(AudioCue.pass, volumeScale: 0.35);
    _burst(x, y, theme.safeGlow, 3, 12.0, 0.3, 0.5);
  }

  void onComboMilestone(int combo) {
    audio.play(AudioCue.comboMilestone);
    haptics.fire(HapticStrength.medium);
  }

  void onRewindStart() {
    audio.play(AudioCue.rewindStart);
    haptics.fire(HapticStrength.selection);
  }

  void onRewindEnd() => audio.play(AudioCue.rewindEnd);

  void _burst(
    double x,
    double y,
    Color color,
    int count,
    double speed,
    double life,
    double size,
  ) {
    if (settings.reducedMotion) {
      count = (count * 0.4).round();
      speed *= 0.6;
    }
    particles.burst(
      x: x,
      y: y,
      color: color,
      count: count,
      speed: speed,
      life: life,
      size: size,
    );
  }

  void update(double realDt, {required double rewindIntensity}) {
    particles.update(realDt);
    shake.update(realDt, reducedMotion: settings.reducedMotion);
    audio.setRewindIntensity(rewindIntensity);
  }

  void render(RenderContext ctx) => particles.render(ctx);

  void applySettings(GameSettings value) {
    settings = value;
    haptics.enabled = value.hapticsEnabled;
    audio.setMuted(!value.soundEnabled);
    audio.setSfxVolume(value.sfxVolume);
    audio.setAmbientVolume(value.ambientVolume);
  }

  void reset() {
    particles.clear();
    shake.reset();
  }
}
