import 'dart:math' as math;
import 'dart:ui';

import '../../core/deterministic_random.dart';
import '../../core/game_balance_config.dart';
import '../../render/render_context.dart';

class _Particle {
  double x = 0.0;
  double y = 0.0;
  double vx = 0.0;
  double vy = 0.0;
  double life = 0.0;
  double maxLife = 1.0;
  double size = 1.0;
  Color color = const Color(0xFFFFFFFF);
  bool alive = false;
}

/// Fixed-capacity, pooled particle field.
///
/// Particles are purely cosmetic and run on *real* time, not game time: they
/// keep moving while the simulation is frozen, which is a small but important
/// cue that the app is alive and the player is in control of the world, not
/// stuck.
class ParticleSystem {
  final GameBalanceConfig cfg;
  final List<_Particle> _particles;
  final DeterministicRandom _rng = DeterministicRandom(0xC0FFEE);

  int _cursor = 0;

  ParticleSystem(this.cfg)
      : _particles = List<_Particle>.generate(
          cfg.maxParticles,
          (_) => _Particle(),
          growable: false,
        );

  int get aliveCount {
    var count = 0;
    for (final p in _particles) {
      if (p.alive) count++;
    }
    return count;
  }

  void burst({
    required double x,
    required double y,
    required Color color,
    int count = 12,
    double speed = 26.0,
    double life = 0.55,
    double size = 0.9,
  }) {
    for (var i = 0; i < count; i++) {
      final p = _particles[_cursor];
      _cursor = (_cursor + 1) % _particles.length;

      final angle = _rng.range(0.0, math.pi * 2);
      final magnitude = speed * _rng.range(0.35, 1.0);
      p
        ..x = x
        ..y = y
        ..vx = math.cos(angle) * magnitude
        ..vy = math.sin(angle) * magnitude
        ..life = life * _rng.range(0.7, 1.15)
        ..size = size * _rng.range(0.6, 1.3)
        ..color = color
        ..alive = true;
      p.maxLife = p.life;
    }
  }

  void update(double realDt) {
    for (final p in _particles) {
      if (!p.alive) continue;
      p.life -= realDt;
      if (p.life <= 0) {
        p.alive = false;
        continue;
      }
      p.x += p.vx * realDt;
      p.y += p.vy * realDt;
      p.vx *= 0.94;
      p.vy *= 0.94;
    }
  }

  void render(RenderContext ctx) {
    for (final p in _particles) {
      if (!p.alive) continue;
      final t = (p.life / p.maxLife).clamp(0.0, 1.0);
      ctx.fill.color = p.color.withOpacity(t * 0.85);
      ctx.canvas.drawCircle(ctx.sp(p.x, p.y), ctx.sl(p.size * t), ctx.fill);
    }
  }

  void clear() {
    for (final p in _particles) {
      p.alive = false;
    }
  }
}
