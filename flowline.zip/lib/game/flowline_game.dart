import 'dart:math' as math;

import 'package:flutter/foundation.dart';

import '../analytics/analytics_service.dart';
import '../core/deterministic_random.dart';
import '../core/design_tokens.dart';
import '../core/feature_flags.dart';
import '../core/game_balance_config.dart';
import '../core/math_utils.dart';
import '../models/game_mode.dart';
import '../models/run_stats.dart';
import '../models/score_event.dart';
import '../settings/settings_model.dart';
import '../themes/game_theme.dart';
import '../themes/theme_catalog.dart';
import 'components/spark.dart';
import 'difficulty/adaptive_difficulty.dart';
import 'effects/effects_manager.dart';
import 'game_state.dart';
import 'generation/procedural_generator.dart';
import 'obstacles/domino_chain.dart';
import 'obstacles/obstacle.dart';
import 'obstacles/obstacle_factory.dart';
import 'obstacles/obstacle_family.dart';
import 'obstacles/orbit_release.dart';
import 'rewind/rewind_buffer.dart';
import 'rewind/rewindable.dart';
import 'segments/segment.dart';
import 'segments/segment_manager.dart';
import 'scoring/scoring_system.dart';
import 'time/time_controller.dart';

/// The orchestrator.
///
/// It owns no gameplay rules of its own: it sequences the systems, moves data
/// between them, and publishes two notifiers — one that ticks every frame for
/// the world, and one that changes rarely for the HUD.
class FlowlineGame {
  final GameBalanceConfig baseConfig;
  final FeatureFlags flags;
  final AnalyticsService analytics;
  final EffectsManager effects;

  late GameBalanceConfig cfg;
  late TimeController time;
  late RewindBuffer rewind;
  late Spark spark;
  late ObstacleFactory obstacleFactory;
  late ProceduralGenerator generator;
  late SegmentManager segments;
  late ScoringSystem scoring;
  late AdaptiveDifficulty difficulty;

  GameMode mode = GameMode.flow;
  GameStatus status = GameStatus.idle;
  GameTheme theme = ThemeCatalog.minimal;
  GameSettings settings = const GameSettings();

  /// Ticks once per rendered frame; the world painter listens to this.
  final ValueNotifier<int> frame = ValueNotifier<int>(0);

  /// Changes rarely; the HUD listens to this.
  final ValueNotifier<HudSnapshot> hud =
      ValueNotifier<HudSnapshot>(const HudSnapshot());

  final ValueNotifier<DebugSnapshot?> debug =
      ValueNotifier<DebugSnapshot?>(null);

  /// Set by the widget each frame so world logic knows how tall the view is.
  double visibleHeight = 200.0;

  int runSeed = 0;
  double runRealSeconds = 0.0;
  double? secondsRemaining;
  bool hasInteracted = false;

  double _graceTimer = 0.0;
  int _gradeToken = 0;
  int _lastComboMilestone = 0;
  bool _wasRewinding = false;
  double _fpsAccumulator = 0.0;
  int _fpsFrames = 0;
  double _fps = 0.0;
  double _lastFrameMs = 0.0;

  // Reused containers: the update loop must not allocate.
  final HazardSample _sample = HazardSample();
  final List<Rewindable> _rewindTargets = <Rewindable>[];
  final Map<int, Rewindable> _rewindTargetsById = <int, Rewindable>{};

  /// Debug overrides, only honoured when the debug panel flag is on.
  bool debugFreeze = false;
  bool debugShowCollision = false;
  ObstacleFamily? debugForcedFamily;
  int? debugForcedTier;

  FlowlineGame({
    required this.baseConfig,
    required this.flags,
    required this.analytics,
    required this.effects,
    double initialSkill = 0.35,
  }) {
    cfg = baseConfig;
    time = TimeController(cfg);
    rewind = RewindBuffer(cfg);
    spark = Spark(cfg);
    obstacleFactory = ObstacleFactory();
    scoring = ScoringSystem(cfg);
    difficulty = AdaptiveDifficulty(
      cfg,
      enabled: flags.enableAdaptiveDifficulty,
      initialSkill: initialSkill,
    );
    generator = ProceduralGenerator(
      cfg: cfg,
      factory: obstacleFactory,
      runSeed: 0,
    );
    segments = SegmentManager(
      cfg: cfg,
      generator: generator,
      obstacleFactory: obstacleFactory,
    );
    obstacleFactory.prewarm(2);
    segments.segmentPool.prewarm(6);
  }

  bool get isRunning => status == GameStatus.playing;

  DifficultySnapshot get difficultySnapshot {
    final snapshot = difficulty.snapshot();
    if (debugForcedTier == null) return snapshot;
    return DifficultySnapshot(
      tier: debugForcedTier!,
      toleranceMultiplier: snapshot.toleranceMultiplier,
      speedMultiplier: snapshot.speedMultiplier,
    );
  }

  // ------------------------------------------------------------------- setup
  void applySettings(GameSettings value) {
    settings = value;
    theme = ThemeCatalog.byId(value.themeId);
    effects.applySettings(value);
    if (value.generousTolerances) {
      cfg = _configForMode(mode).copyWith(
        collisionForgiveness: baseConfig.collisionForgiveness + 0.7,
        maxToleranceBoost: baseConfig.maxToleranceBoost + 0.25,
      );
    }
  }

  GameBalanceConfig _configForMode(GameMode value) =>
      value == GameMode.zen ? baseConfig.zen : baseConfig;

  /// Deterministic daily seed: the same date yields the same 60-second run for
  /// everyone, without a server.
  static int dailySeedFor(DateTime date) {
    final key = date.year * 10000 + date.month * 100 + date.day;
    return DeterministicRandom.hash2(key, 0x5EED);
  }

  void start({
    required GameMode mode,
    int? seed,
    double? initialSkill,
  }) {
    this.mode = mode;
    cfg = _configForMode(mode);

    // Systems that hold config by value are rebuilt; the rest are reset in
    // place so a mode switch allocates almost nothing.
    time = TimeController(cfg);
    rewind = RewindBuffer(cfg);
    spark = Spark(cfg);
    scoring = ScoringSystem(cfg);
    difficulty = AdaptiveDifficulty(
      cfg,
      enabled: flags.enableAdaptiveDifficulty && mode != GameMode.zen,
      initialSkill: initialSkill ?? difficulty.skill,
    );

    runSeed = seed ??
        (mode == GameMode.sixty
            ? dailySeedFor(DateTime.now())
            : DateTime.now().millisecondsSinceEpoch & 0x3FFFFFFF);

    // Return the previous run's obstacles and segments to their pools before
    // building the new manager, so a mode switch does not leak them.
    segments.reset(runSeed);

    generator = ProceduralGenerator(
      cfg: cfg,
      factory: obstacleFactory,
      runSeed: runSeed,
    );
    segments = SegmentManager(
      cfg: cfg,
      generator: generator,
      obstacleFactory: obstacleFactory,
      segmentPool: segments.segmentPool,
    );
    segments.reset(runSeed);

    effects.reset();
    spark.syncTo(0.0);

    runRealSeconds = 0.0;
    secondsRemaining = mode == GameMode.sixty ? 60.0 : null;
    hasInteracted = false;
    _graceTimer = 0.0;
    _lastComboMilestone = 0;
    _wasRewinding = false;
    status = GameStatus.playing;

    analytics.setSuperProperties({
      'mode': mode.id,
      'seed': runSeed,
    });
    analytics.track(AnalyticsEvents.sessionStart, {'mode': mode.id});
    if (mode == GameMode.sixty) {
      analytics.track(AnalyticsEvents.dailyStarted, {'seed': runSeed});
    } else if (mode == GameMode.zen) {
      analytics.track(AnalyticsEvents.zenStarted);
    }

    _publishHud(force: true);
  }

  void pause() {
    if (status != GameStatus.playing) return;
    status = GameStatus.paused;
    time.onPointerCancel();
    _publishHud(force: true);
  }

  void resume() {
    if (status != GameStatus.paused) return;
    status = GameStatus.playing;
    _publishHud(force: true);
  }

  void finish() {
    if (status == GameStatus.finished) return;
    status = GameStatus.finished;
    analytics.track(AnalyticsEvents.sessionEnd, buildStats().toJson());
    _publishHud(force: true);
  }

  RunStats buildStats() => RunStats(
        mode: mode,
        seed: runSeed,
        score: scoring.score,
        bestCombo: scoring.bestCombo,
        perfectCount: scoring.perfectCount,
        goodCount: scoring.goodCount,
        passCount: scoring.passCount,
        failCount: scoring.failCount,
        distance: time.maxFlowPosition,
        durationSeconds: runRealSeconds,
        skillTier: difficulty.tier,
      );

  // ------------------------------------------------------------------- input
  void onPointerDown() {
    if (!isRunning) return;
    if (!hasInteracted) {
      hasInteracted = true;
      analytics.track(AnalyticsEvents.firstInteraction);
    }
    time.onPointerDown();
  }

  void onPointerMove(double forwardDelta) {
    if (!isRunning) return;
    time.onPointerMove(forwardDelta);
  }

  void onPointerUp(double forwardVelocity) {
    if (!isRunning) return;
    time.onPointerUp(forwardVelocity);
  }

  void onPointerCancel() => time.onPointerCancel();

  // ------------------------------------------------------------------ update
  void update(double rawRealDt) {
    final realDt = clampd(rawRealDt, 0.0, cfg.maxRealDelta);
    _trackFps(rawRealDt);

    if (status != GameStatus.playing) {
      frame.value++;
      return;
    }

    runRealSeconds += realDt;
    if (secondsRemaining != null) {
      secondsRemaining = math.max(0.0, secondsRemaining! - realDt);
      if (secondsRemaining! <= 0.0) {
        finish();
        frame.value++;
        return;
      }
    }

    if (flags.enableDebugPanel) generator.forcedFamily = debugForcedFamily;

    if (!(flags.enableDebugPanel && debugFreeze)) {
      time.update(realDt);
    }

    _graceTimer = math.max(0.0, _graceTimer - realDt);

    final protectedY =
        rewind.flowPositionAt(time.rewindFloor) ?? time.flowPosition;
    segments.update(
      flowPosition: time.flowPosition,
      visibleHeight: visibleHeight,
      difficulty: difficultySnapshot,
      protectedY: protectedY,
    );

    if (time.isRewinding) {
      _updateRewinding();
    } else {
      _updateForward();
    }

    spark.update(realDt, rewinding: time.isRewinding);
    effects.update(
      realDt,
      rewindIntensity:
          time.isRewinding ? (-time.actualTimeScale / cfg.maxRewindRate) : 0.0,
    );

    _wasRewinding = time.isRewinding;
    _publishHud();
    if (flags.enableDebugHud) _publishDebug();
    frame.value++;
  }

  void _updateRewinding() {
    _collectRewindTargets();
    rewind.restoreTo(time.gameTime, _rewindTargetsById);
    final restoredFlow = rewind.flowPositionAt(time.gameTime);
    if (restoredFlow != null) time.setFlowPosition(restoredFlow);
    spark.syncTo(time.flowPosition);

    if (!_wasRewinding) {
      effects.onRewindStart();
      analytics.track(
        time.isAutoRewinding
            ? AnalyticsEvents.autoRewind
            : AnalyticsEvents.rewindStart,
        {'gameTime': time.gameTime},
      );
      if (!time.isAutoRewinding) difficulty.registerManualRewind();
    }
  }

  void _updateForward() {
    if (_wasRewinding) {
      // The future the player already lived is no longer the future they will
      // live; drop it so no stale snapshot can be restored into it.
      rewind.discardAfter(time.gameTime);
      effects.onRewindEnd();
      analytics.track(AnalyticsEvents.rewindEnd, {'gameTime': time.gameTime});
      _graceTimer = math.max(_graceTimer, cfg.postRewindGraceSeconds);
    }

    spark.syncTo(time.flowPosition);

    final gameTime = time.gameTime;
    final gameDelta = time.lastGameDelta;
    final low = spark.y - 90.0;
    final high = spark.y + 90.0;

    segments.forEachObstacleInRange(low, high, (segment, obstacle) {
      obstacle.update(gameTime, gameDelta);
    });

    _evaluate(gameTime);

    _collectRewindTargets();
    rewind.maybeCapture(gameTime, time.flowPosition, _rewindTargets);
  }

  void _evaluate(double gameTime) {
    Obstacle? collided;
    ScoreEvent? scoreEvent;
    Obstacle? scoredObstacle;

    segments.forEachObstacleInRange(
      spark.y - 60.0,
      spark.y + 60.0,
      (segment, obstacle) {
        // Trigger-based families arm themselves as the Spark crosses their line.
        if (obstacle is OrbitRelease && spark.y >= obstacle.triggerY) {
          obstacle.trigger(gameTime);
        } else if (obstacle is DominoChain && spark.y >= obstacle.triggerY) {
          obstacle.trigger(gameTime);
        }

        obstacle.sample(
          _sample,
          spark.x,
          spark.y,
          spark.collisionRadius,
          gameTime,
        );

        if (collided == null &&
            _sample.clearance < 0.0 &&
            _sample.engaged &&
            _graceTimer <= 0.0) {
          collided = obstacle;
          return;
        }

        if (!obstacle.scored && spark.y >= obstacle.evaluationY) {
          obstacle.scored = true;
          final grade = scoring.gradeFor(_sample.precision, collided: false);
          scoreEvent = scoring.register(
            grade: grade,
            family: obstacle.family,
            precision: _sample.precision,
            gameTime: gameTime,
          );
          scoredObstacle = obstacle;
        }
      },
    );

    if (collided != null) {
      _handleFailure(collided!);
      return;
    }

    final event = scoreEvent;
    if (event != null) _handleScore(event, scoredObstacle!);
  }

  void _handleScore(ScoreEvent event, Obstacle obstacle) {
    difficulty.registerResult(event.grade, event.precision, event.family);
    effects.onScore(event, theme, spark.x, spark.y);
    if (event.grade != Grade.pass) spark.triggerPulse();

    _gradeToken++;

    final milestone = event.comboAfter ~/ (cfg.comboStep * 2);
    if (milestone > _lastComboMilestone && event.comboAfter > 0) {
      _lastComboMilestone = milestone;
      effects.onComboMilestone(event.comboAfter);
      analytics.track(AnalyticsEvents.comboMilestone, {
        'combo': event.comboAfter,
      });
    }

    analytics.track(
      switch (event.grade) {
        Grade.perfect => AnalyticsEvents.segmentPerfect,
        Grade.good => AnalyticsEvents.segmentGood,
        Grade.pass => AnalyticsEvents.segmentPass,
        Grade.fail => AnalyticsEvents.segmentFail,
      },
      {
        'family': event.family.id,
        'precision': event.precision,
        'points': event.points,
        'combo': event.comboAfter,
        'tier': difficulty.tier,
      },
    );
  }

  void _handleFailure(Obstacle obstacle) {
    obstacle.scored = true;
    spark.triggerImpact();
    effects.onCollision(theme, spark.x, spark.y);

    // Zen has no meaningful failure: the Spark is nudged back and the run
    // continues without a combo break or a skill penalty.
    if (mode != GameMode.zen) {
      final hadCombo = scoring.combo > 0;
      scoring.register(
        grade: Grade.fail,
        family: obstacle.family,
        precision: 0.0,
        gameTime: time.gameTime,
      );
      difficulty.registerResult(Grade.fail, 0.0, obstacle.family);
      _lastComboMilestone = 0;
      if (hadCombo) analytics.track(AnalyticsEvents.comboBroken);
      analytics.track(AnalyticsEvents.segmentFail, {
        'family': obstacle.family.id,
        'tier': difficulty.tier,
      });
    }

    _gradeToken++;

    if (time.availableRewindSeconds > 0.15) {
      time.requestAutoRewind(cfg.autoRewindSeconds);
    } else {
      _restartCurrentSegment();
    }
    _graceTimer = cfg.postRewindGraceSeconds;
  }

  /// Fallback when there is no history to rewind into: drop the player back to
  /// the safe entry of the segment they are in. Never restarts the whole run.
  void _restartCurrentSegment() {
    final segment = segments.segmentContaining(spark.y) ??
        (segments.active.isNotEmpty ? segments.active.first : null);
    final target = segment == null ? 0.0 : segment.startY + 2.0;
    time.setFlowPosition(target);
    spark.syncTo(target);
    spark.reset();
    rewind.clear();
    for (final active in segments.active) {
      for (final obstacle in active.obstacles) {
        obstacle.resetRewindState();
      }
    }
  }

  void _collectRewindTargets() {
    _rewindTargets
      ..clear()
      ..add(scoring);
    _rewindTargetsById
      ..clear()
      ..[scoring.rewindId] = scoring;

    segments.forEachObstacle((segment, obstacle) {
      _rewindTargets.add(obstacle);
      _rewindTargetsById[obstacle.rewindId] = obstacle;
    });
  }

  // ------------------------------------------------------------------ output
  HintKind get _hint {
    if (settings.reducedMotion && hasInteracted) return HintKind.none;
    if (!hasInteracted) return HintKind.scrollUp;
    if (scoring.failCount > 0 && time.availableRewindSeconds > 0.5) {
      return HintKind.dragDownToRewind;
    }
    if (time.maxFlowPosition < 90.0 && time.isFrozen) {
      return HintKind.holdToFreeze;
    }
    return HintKind.none;
  }

  void _publishHud({bool force = false}) {
    final next = HudSnapshot(
      score: scoring.score,
      combo: scoring.combo,
      comboMultiplier: scoring.comboMultiplier,
      status: status,
      mode: mode,
      hint: _hint,
      lastGradeToken: _gradeToken,
      secondsRemaining: secondsRemaining,
    );
    if (force || !next.sameAs(hud.value)) hud.value = next;
  }

  void _trackFps(double realDt) {
    _lastFrameMs = realDt * 1000.0;
    _fpsAccumulator += realDt;
    _fpsFrames++;
    if (_fpsAccumulator >= 0.5) {
      _fps = _fpsFrames / _fpsAccumulator;
      _fpsAccumulator = 0.0;
      _fpsFrames = 0;
    }
  }

  void _publishDebug() {
    final segment = segments.segmentContaining(spark.y);
    debug.value = DebugSnapshot(
      fps: _fps,
      frameMs: _lastFrameMs,
      activeObstacles: segments.activeObstacleCount,
      activeSegments: segments.activeSegmentCount,
      pooledObstacles: obstacleFactory.pooledCount,
      pooledSegments: segments.segmentPool.pooledCount,
      aliveParticles: effects.particles.aliveCount,
      timeScale: time.actualTimeScale,
      targetTimeScale: time.targetTimeScale,
      scrollVelocity: time.scrollVelocity,
      gameTime: time.gameTime,
      flowPosition: time.flowPosition,
      rewindSeconds: rewind.bufferedSeconds,
      rewindSnapshots: rewind.count,
      segmentIndex: segment?.index ?? -1,
      segmentSeed: segment?.seed ?? 0,
      runSeed: runSeed,
      difficultyTier: difficulty.tier,
      skill: difficulty.skill,
    );
  }

  // ------------------------------------------------------------- debug tools
  void debugSkipSegment() {
    if (!flags.enableDebugPanel) return;
    final segment = segments.segmentContaining(spark.y);
    if (segment == null) return;
    final target = segment.endY + 2.0;
    time.setFlowPosition(target);
    spark.syncTo(target);
    rewind.clear();
  }

  void debugSetTimeScale(double scale) {
    if (!flags.enableDebugPanel) return;
    time.actualTimeScale = scale;
    time.targetTimeScale = scale;
  }

  void debugTriggerAutoRewind() {
    if (!flags.enableDebugPanel) return;
    time.requestAutoRewind(cfg.autoRewindSeconds);
  }

  void debugRegenerateAhead() {
    if (!flags.enableDebugPanel) return;
    segments.regenerateAhead(spark.y + 40.0, difficultySnapshot);
  }

  void dispose() {
    frame.dispose();
    hud.dispose();
    debug.dispose();
  }
}

/// Kept here so `Segment` is exported alongside the game for tooling.
typedef ActiveSegment = Segment;

/// Convenience for tests and the debug panel.
double worldVisibleHeightFor(double screenWidth, double screenHeight) {
  final ratio = screenHeight / math.max(screenWidth, 1.0);
  return clampd(
    WorldMetrics.width * ratio,
    WorldMetrics.minVisibleHeight,
    WorldMetrics.maxVisibleHeight,
  );
}
