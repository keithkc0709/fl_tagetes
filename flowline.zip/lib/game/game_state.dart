import 'package:flutter/foundation.dart';

import '../models/game_mode.dart';
import '../models/score_event.dart';

enum GameStatus { idle, playing, paused, finished }

/// Which wordless hint, if any, should currently be shown.
///
/// Hints are icons and motion, never paragraphs, and each one retires the
/// moment the player demonstrates the verb it teaches.
enum HintKind { none, scrollUp, holdToFreeze, dragDownToRewind }

/// Low-frequency UI state.
///
/// Deliberately separate from the render loop: the HUD rebuilds only when one
/// of these values actually changes, while the world repaints every frame.
@immutable
class HudSnapshot {
  final int score;
  final int combo;
  final double comboMultiplier;
  final GameStatus status;
  final GameMode mode;
  final HintKind hint;
  final Grade? lastGrade;
  final int lastGradeToken;
  final double? secondsRemaining;

  const HudSnapshot({
    this.score = 0,
    this.combo = 0,
    this.comboMultiplier = 1.0,
    this.status = GameStatus.idle,
    this.mode = GameMode.flow,
    this.hint = HintKind.none,
    this.lastGrade,
    this.lastGradeToken = 0,
    this.secondsRemaining,
  });

  HudSnapshot copyWith({
    int? score,
    int? combo,
    double? comboMultiplier,
    GameStatus? status,
    GameMode? mode,
    HintKind? hint,
    Grade? lastGrade,
    int? lastGradeToken,
    double? secondsRemaining,
    bool clearSecondsRemaining = false,
  }) {
    return HudSnapshot(
      score: score ?? this.score,
      combo: combo ?? this.combo,
      comboMultiplier: comboMultiplier ?? this.comboMultiplier,
      status: status ?? this.status,
      mode: mode ?? this.mode,
      hint: hint ?? this.hint,
      lastGrade: lastGrade ?? this.lastGrade,
      lastGradeToken: lastGradeToken ?? this.lastGradeToken,
      secondsRemaining: clearSecondsRemaining
          ? null
          : (secondsRemaining ?? this.secondsRemaining),
    );
  }

  bool sameAs(HudSnapshot other) {
    return score == other.score &&
        combo == other.combo &&
        comboMultiplier == other.comboMultiplier &&
        status == other.status &&
        mode == other.mode &&
        hint == other.hint &&
        lastGradeToken == other.lastGradeToken &&
        ((secondsRemaining == null) == (other.secondsRemaining == null)) &&
        (secondsRemaining == null ||
            secondsRemaining!.ceil() == other.secondsRemaining!.ceil());
  }
}

/// Snapshot consumed by the debug HUD. Built only when the HUD is enabled.
@immutable
class DebugSnapshot {
  final double fps;
  final double frameMs;
  final int activeObstacles;
  final int activeSegments;
  final int pooledObstacles;
  final int pooledSegments;
  final int aliveParticles;
  final double timeScale;
  final double targetTimeScale;
  final double scrollVelocity;
  final double gameTime;
  final double flowPosition;
  final double rewindSeconds;
  final int rewindSnapshots;
  final int segmentIndex;
  final int segmentSeed;
  final int runSeed;
  final int difficultyTier;
  final double skill;

  const DebugSnapshot({
    required this.fps,
    required this.frameMs,
    required this.activeObstacles,
    required this.activeSegments,
    required this.pooledObstacles,
    required this.pooledSegments,
    required this.aliveParticles,
    required this.timeScale,
    required this.targetTimeScale,
    required this.scrollVelocity,
    required this.gameTime,
    required this.flowPosition,
    required this.rewindSeconds,
    required this.rewindSnapshots,
    required this.segmentIndex,
    required this.segmentSeed,
    required this.runSeed,
    required this.difficultyTier,
    required this.skill,
  });
}
