import '../obstacles/obstacle_family.dart';

/// Static generation policy: which families may appear at which tier, how often
/// they may repeat, and how much recovery the player is guaranteed.
class GenerationRules {
  /// A family may not appear more than this many times in a row.
  final int maxConsecutiveSameFamily;

  /// Segments that must pass between two demanding families.
  final int demandingCooldown;

  /// At most this many segments before a low-intensity recovery beat.
  final int recoveryInterval;

  const GenerationRules({
    this.maxConsecutiveSameFamily = 2,
    this.demandingCooldown = 2,
    this.recoveryInterval = 5,
  });

  /// Weight table by tier. A weight of zero means "not yet unlocked", which is
  /// how the first sixty seconds are shaped without any scripted tutorial.
  static const Map<ObstacleFamily, List<double>> _weights = {
    //                        t0    t1    t2    t3    t4    t5
    ObstacleFamily.movingGate: [1.0, 0.55, 0.35, 0.22, 0.16, 0.12],
    ObstacleFamily.rotatingRing: [0.0, 0.35, 0.28, 0.20, 0.16, 0.14],
    ObstacleFamily.pendulum: [0.0, 0.10, 0.20, 0.18, 0.16, 0.14],
    ObstacleFamily.crusher: [0.0, 0.00, 0.17, 0.16, 0.14, 0.12],
    ObstacleFamily.bouncer: [0.0, 0.00, 0.00, 0.12, 0.14, 0.14],
    ObstacleFamily.orbitRelease: [0.0, 0.00, 0.00, 0.06, 0.12, 0.14],
    ObstacleFamily.synchronizer: [0.0, 0.00, 0.00, 0.04, 0.10, 0.10],
    ObstacleFamily.dominoChain: [0.0, 0.00, 0.00, 0.02, 0.02, 0.10],
  };

  double weightFor(ObstacleFamily family, int tier) {
    final row = _weights[family];
    if (row == null) return 0.0;
    final index = tier.clamp(0, row.length - 1);
    return row[index];
  }

  /// Families with non-zero weight at [tier].
  List<ObstacleFamily> availableAt(int tier) {
    final result = <ObstacleFamily>[];
    for (final family in ObstacleFamily.values) {
      if (weightFor(family, tier) > 0.0) result.add(family);
    }
    return result;
  }

  /// Two obstacles in one segment only once the player is comfortable.
  int maxObstaclesPerSegment(int tier) => tier >= 4 ? 2 : 1;
}
