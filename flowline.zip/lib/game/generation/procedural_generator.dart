import 'dart:math' as math;

import '../../core/deterministic_random.dart';
import '../../core/game_balance_config.dart';
import '../../core/math_utils.dart';
import '../difficulty/adaptive_difficulty.dart';
import '../obstacles/obstacle.dart';
import '../obstacles/obstacle_factory.dart';
import '../obstacles/obstacle_family.dart';
import '../segments/segment.dart';
import 'generation_rules.dart';

/// Deterministic, difficulty-aware segment generator.
///
/// Determinism contract: for a given `(runSeed, segmentIndex, tier)` the
/// generator produces identical geometry on every device and every build with
/// the same [version]. Generation must proceed sequentially from index 0
/// because repeat-avoidance and cooldowns are history dependent; the history
/// itself is fully deterministic, so replaying from 0 always reproduces a run.
class ProceduralGenerator {
  static const int version = 1;

  final GameBalanceConfig cfg;
  final GenerationRules rules;
  final ObstacleFactory factory;

  int runSeed;

  /// Debug-only override. When set, every generated obstacle uses this family.
  /// Ignored entirely in release because the debug panel cannot be reached.
  ObstacleFamily? forcedFamily;

  final List<ObstacleFamily> _recentFamilies = <ObstacleFamily>[];
  int _segmentsSinceDemanding = 99;
  int _segmentsSinceRecovery = 0;

  ProceduralGenerator({
    required this.cfg,
    required this.factory,
    required this.runSeed,
    this.rules = const GenerationRules(),
  });

  static const double entryPadding = 26.0;
  static const double interObstacleGap = 34.0;
  static const double exitPadding = 48.0;

  void reset(int seed) {
    runSeed = seed;
    _recentFamilies.clear();
    _segmentsSinceDemanding = 99;
    _segmentsSinceRecovery = 0;
  }

  Segment generate(
    Segment into,
    int index,
    double startY,
    DifficultySnapshot difficulty,
  ) {
    into.reset();
    into.index = index;
    into.seed = DeterministicRandom.hash2(
      DeterministicRandom.hash2(runSeed, version),
      index,
    );
    into.startY = startY;
    into.tier = difficulty.tier;

    final rng = DeterministicRandom(into.seed);
    final forceRecovery = _segmentsSinceRecovery >= rules.recoveryInterval;

    final count = _obstacleCount(rng, difficulty.tier, forceRecovery);
    var y = startY + entryPadding;

    for (var i = 0; i < count; i++) {
      final family = _pickFamily(rng, difficulty.tier, forceRecovery && i == 0);
      final obstacle = factory.obtain(family);
      obstacle.activate(y);
      _configure(obstacle, rng, difficulty);
      into.obstacles.add(obstacle);
      _noteFamily(family);
      y += obstacle.bandHeight + interObstacleGap;
    }

    into.length = math.max(
      (y - startY) + exitPadding - interObstacleGap,
      cfg.segmentLength * 0.6,
    );

    _segmentsSinceRecovery = forceRecovery ? 0 : _segmentsSinceRecovery + 1;
    return into;
  }

  int _obstacleCount(DeterministicRandom rng, int tier, bool forceRecovery) {
    if (forceRecovery) return 1;
    final max = rules.maxObstaclesPerSegment(tier);
    if (max <= 1) return 1;
    return rng.chance(0.35) ? 2 : 1;
  }

  ObstacleFamily _pickFamily(
    DeterministicRandom rng,
    int tier,
    bool preferRecovery,
  ) {
    final forced = forcedFamily;
    if (forced != null) return forced;

    final candidates = <ObstacleFamily>[];
    final weights = <double>[];
    var total = 0.0;

    for (final family in ObstacleFamily.values) {
      final weight = rules.weightFor(family, tier);
      if (weight <= 0.0) continue;
      if (_wouldExceedRepeatLimit(family)) continue;
      if (family.isDemanding &&
          _segmentsSinceDemanding < rules.demandingCooldown) {
        continue;
      }
      // A recovery beat is a guarantee, not a nudge: the player is owed a
      // breather at a known cadence, so the candidate set is restricted rather
      // than merely reweighted.
      if (preferRecovery && !family.isRecovery) continue;

      candidates.add(family);
      weights.add(weight);
      total += weight;
    }

    if (candidates.isEmpty) return ObstacleFamily.movingGate;

    var roll = rng.nextDouble() * total;
    for (var i = 0; i < candidates.length; i++) {
      roll -= weights[i];
      if (roll <= 0) return candidates[i];
    }
    return candidates.last;
  }

  bool _wouldExceedRepeatLimit(ObstacleFamily family) {
    if (_recentFamilies.length < rules.maxConsecutiveSameFamily) return false;
    for (var i = 0; i < rules.maxConsecutiveSameFamily; i++) {
      if (_recentFamilies[_recentFamilies.length - 1 - i] != family) {
        return false;
      }
    }
    return true;
  }

  void _noteFamily(ObstacleFamily family) {
    _recentFamilies.add(family);
    if (_recentFamilies.length > 8) _recentFamilies.removeAt(0);
    _segmentsSinceDemanding =
        family.isDemanding ? 0 : _segmentsSinceDemanding + 1;
  }

  /// Maps a difficulty tier onto per-family parameters.
  ///
  /// Every value is clamped so no combination of tier, tolerance and random
  /// roll can produce impossible geometry — the minimum opening is always wider
  /// than the Spark plus a real margin.
  void _configure(
    Obstacle obstacle,
    DeterministicRandom rng,
    DifficultySnapshot difficulty,
  ) {
    final k = clampd(difficulty.tier / 5.0, 0.0, 1.0);
    final tolerance = difficulty.toleranceMultiplier;
    final minimumOpening = cfg.sparkRadius * 2.0 + 6.5;
    final params = obstacle.params;

    params.phase = rng.range(0.0, tau);
    params.direction = rng.sign().toDouble();
    params.speedScale = difficulty.speedMultiplier;
    params.thickness = 4.4;
    params.period = lerpd(3.4, 1.5, k) * rng.range(0.9, 1.15);
    params.amplitude = lerpd(15.0, 30.0, k);
    params.openingWidth = clampd(
      lerpd(42.0, 21.0, k) * tolerance * rng.range(0.94, 1.06),
      minimumOpening,
      60.0,
    );
    params.radius = lerpd(30.0, 22.0, k);

    switch (obstacle.family) {
      case ObstacleFamily.movingGate:
        obstacle.bandHeight = 44.0;
      case ObstacleFamily.rotatingRing:
        obstacle.bandHeight = 66.0;
        params.radius = clampd(lerpd(30.0, 23.0, k), 18.0, 34.0);
        params.openingWidth = clampd(
          params.openingWidth * 1.1,
          minimumOpening * 1.2,
          60.0,
        );
      case ObstacleFamily.pendulum:
        obstacle.bandHeight = 62.0;
        params.radius = lerpd(26.0, 36.0, k);
        params.amplitude = lerpd(16.0, 34.0, k);
      case ObstacleFamily.crusher:
        obstacle.bandHeight = 46.0;
        params.openingWidth =
            clampd(lerpd(48.0, 28.0, k) * tolerance, minimumOpening + 6.0, 66.0);
        params.extra = clampd(
          lerpd(11.0, 3.5, k) / math.max(tolerance, 0.5),
          2.0,
          params.openingWidth - 6.0,
        );
      case ObstacleFamily.bouncer:
        obstacle.bandHeight = 50.0;
        params.period = lerpd(3.0, 1.4, k) * rng.range(0.9, 1.1);
        params.thickness = clampd(5.0 / math.max(tolerance, 0.7), 3.0, 6.0);
      case ObstacleFamily.orbitRelease:
        obstacle.bandHeight = 68.0;
        params.radius = clampd(lerpd(20.0, 28.0, k), 16.0, 32.0);
        params.period = lerpd(2.8, 1.5, k);
        params.thickness = clampd(4.6 / math.max(tolerance, 0.7), 3.0, 5.6);
      case ObstacleFamily.synchronizer:
        obstacle.bandHeight = 72.0;
        params.openingWidth = clampd(
          lerpd(40.0, 24.0, k) * tolerance,
          minimumOpening + 4.0,
          58.0,
        );
        params.extra = rng.range(0.14, 0.38);
      case ObstacleFamily.dominoChain:
        obstacle.bandHeight = 58.0;
        params.count = rng.rangeInt(4, 6);
        params.period = lerpd(3.2, 1.8, k);
        params.radius = 26.0;
        params.thickness = 3.4;
    }
  }
}
