import 'dart:math' as math;
import 'dart:ui';

import '../../core/design_tokens.dart';
import '../../core/math_utils.dart';
import '../../render/render_context.dart';
import 'obstacle.dart';
import 'obstacle_family.dart';

/// E. BOUNCER — a puck rebounding between two sprung walls across the corridor.
///
/// Unlike the gate families the hazard here is the *object*, not the gap, and
/// it moves at constant speed with a hard rebound. That inversion is what makes
/// it feel distinct even though it lives in the same 44-unit band.
class Bouncer extends Obstacle {
  @override
  ObstacleFamily get family => ObstacleFamily.bouncer;

  double get trackY => anchorY + bandHeight * 0.5;
  double get puckRadius => params.thickness * 1.5;

  double get wallInset => 8.0;

  @override
  double get evaluationY => trackY;

  double puckX(double gameTime) {
    final t = gameTime * params.speedScale / math.max(params.period, 0.05);
    final travel = WorldMetrics.width - wallInset * 2.0 - puckRadius * 2.0;
    return wallInset + puckRadius + travel * triangle01(t + params.phase / tau);
  }

  /// How compressed the near wall's spring is, purely cosmetic.
  double _springCompression(double gameTime, bool leftWall) {
    final x = puckX(gameTime);
    final d = leftWall
        ? x - (wallInset + puckRadius)
        : (WorldMetrics.width - wallInset - puckRadius) - x;
    return clampd(1.0 - d / 12.0, 0.0, 1.0);
  }

  @override
  void sample(
    HazardSample out,
    double x,
    double y,
    double radius,
    double gameTime,
  ) {
    out.reset();
    final px = puckX(gameTime);
    final toPuck = distance(x, y, px, trackY) - (puckRadius + radius);

    final dy = (y - trackY).abs();
    final wallReach = params.thickness * 2.4 + radius;
    var toWall = double.infinity;
    if (dy < wallReach) {
      final leftEdge = wallInset - x - radius;
      final rightEdge = x - (WorldMetrics.width - wallInset) - radius;
      toWall = -math.max(leftEdge, rightEdge);
    }

    out.clearance = math.min(toPuck, toWall);
    out.engaged = y >= anchorY && y <= anchorY + bandHeight;
    out.precision = clampd(toPuck / (WorldMetrics.width * 0.28), 0.0, 1.0);
  }

  @override
  void render(RenderContext ctx, double gameTime) {
    final theme = ctx.theme;
    final h = params.thickness * 4.8;
    final top = ctx.sy(trackY + h * 0.5);
    final bottom = ctx.sy(trackY - h * 0.5);

    ctx.fill.color = theme.hazardFill;
    ctx.stroke
      ..color = theme.hazardEdge
      ..strokeWidth = 1.4;

    for (var i = 0; i < 2; i++) {
      final leftWall = i == 0;
      final compression = _springCompression(gameTime, leftWall) * 2.2;
      final rect = leftWall
          ? Rect.fromLTRB(
              ctx.sx(-4), top, ctx.sx(wallInset - compression), bottom)
          : Rect.fromLTRB(
              ctx.sx(WorldMetrics.width - wallInset + compression),
              top,
              ctx.sx(WorldMetrics.width + 4),
              bottom,
            );
      final rr = RRect.fromRectAndRadius(rect, Radius.circular(ctx.sl(1.4)));
      ctx.canvas.drawRRect(rr, ctx.fill);
      ctx.canvas.drawRRect(rr, ctx.stroke);
    }

    ctx.stroke
      ..color = theme.hazardEdge.withOpacity(0.25)
      ..strokeWidth = ctx.sl(0.5);
    ctx.canvas.drawLine(
      ctx.sp(wallInset, trackY),
      ctx.sp(WorldMetrics.width - wallInset, trackY),
      ctx.stroke,
    );

    final px = puckX(gameTime);
    ctx.fill.color = theme.hazardEdge;
    ctx.canvas.drawCircle(ctx.sp(px, trackY), ctx.sl(puckRadius), ctx.fill);
    ctx.drawGlow(px, trackY, puckRadius * 1.6, theme.hazardEdge, intensity: 0.6);
  }
}
