import 'dart:math' as math;
import 'dart:ui';

import '../../core/design_tokens.dart';
import '../../core/math_utils.dart';
import '../../render/render_context.dart';
import 'obstacle.dart';
import 'obstacle_family.dart';

/// D. CRUSHER — two blocks that close toward the centre on a triangle wave.
///
/// A triangle wave (rather than a sine) is deliberate: constant approach speed
/// with a hard turnaround reads as machinery and makes the safe moment legible
/// at a glance.
class Crusher extends Obstacle {
  @override
  ObstacleFamily get family => ObstacleFamily.crusher;

  double get barY => anchorY + bandHeight * 0.5;

  @override
  double get evaluationY => barY;

  double get minGap => math.max(params.extra, 2.0);
  double get maxGap => params.openingWidth;

  double gapAt(double gameTime) {
    final t = gameTime * params.speedScale / math.max(params.period, 0.05);
    return minGap + (maxGap - minGap) * triangle01(t + params.phase / tau);
  }

  @override
  void sample(
    HazardSample out,
    double x,
    double y,
    double radius,
    double gameTime,
  ) {
    out.reset();
    final dy = (y - barY).abs();
    final reach = params.thickness * 1.6 + radius;
    final half = gapAt(gameTime) * 0.5;
    final lateral = (x - laneCenterX).abs();

    // Precision here is "how open was it", i.e. did you wait for the apex.
    out.precision = clampd(
      (gapAt(gameTime) - minGap) / math.max(maxGap - minGap, 0.001),
      0.0,
      1.0,
    );

    if (dy >= reach) {
      out.clearance = dy - reach;
      out.engaged = false;
      return;
    }
    out.engaged = true;
    out.clearance = half - lateral - radius;
  }

  @override
  void render(RenderContext ctx, double gameTime) {
    final theme = ctx.theme;
    final half = gapAt(gameTime) * 0.5;
    final h = params.thickness * 3.2;
    final top = ctx.sy(barY + h * 0.5);
    final bottom = ctx.sy(barY - h * 0.5);
    final radius = Radius.circular(ctx.sl(1.6));

    ctx.fill.color = theme.hazardFill;
    ctx.stroke
      ..color = theme.hazardEdge
      ..strokeWidth = 1.4;

    final left = RRect.fromRectAndRadius(
      Rect.fromLTRB(ctx.sx(-4), top, ctx.sx(laneCenterX - half), bottom),
      radius,
    );
    final right = RRect.fromRectAndRadius(
      Rect.fromLTRB(
        ctx.sx(laneCenterX + half),
        top,
        ctx.sx(WorldMetrics.width + 4),
        bottom,
      ),
      radius,
    );
    for (final rr in [left, right]) {
      ctx.canvas.drawRRect(rr, ctx.fill);
      ctx.canvas.drawRRect(rr, ctx.stroke);
    }

    ctx.drawGlow(laneCenterX, barY, half, theme.safeGlow, intensity: 0.45);
  }
}
