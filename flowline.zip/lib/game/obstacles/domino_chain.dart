import 'dart:math' as math;
import 'dart:ui';

import '../../core/design_tokens.dart';
import '../../core/math_utils.dart';
import '../../render/render_context.dart';
import '../rewind/snapshot.dart';
import 'obstacle.dart';
import 'obstacle_family.dart';

/// H. DOMINO CHAIN — standing tiles that topple in sequence once triggered.
///
/// Teaches the "slow drag" verb better than anything else in the set: you must
/// cross the trigger line and then advance *time* without advancing much
/// *distance*, which is only possible with a slow controlled drag.
class DominoChain extends Obstacle {
  @override
  ObstacleFamily get family => ObstacleFamily.dominoChain;

  double _triggerTime = -1.0;

  double get baseY => anchorY + bandHeight * 0.34;
  double get triggerY => anchorY + 3.0;
  double get tileHeight => params.radius * 0.55;
  double get tileStagger => math.max(params.period * 0.22, 0.05);
  double get fallDuration => math.max(params.period * 0.4, 0.08);

  @override
  double get evaluationY => baseY + tileHeight * 0.6;

  bool get triggered => _triggerTime >= 0.0;

  @override
  void onActivate() {
    _triggerTime = -1.0;
  }

  void trigger(double gameTime) {
    if (triggered) return;
    _triggerTime = gameTime;
  }

  double tileX(int index) {
    final spacing = (WorldMetrics.width - 16.0) / (params.count - 1);
    return 8.0 + spacing * index;
  }

  /// 0 = fully upright, 1 = flat on the floor.
  double fallProgress(int index, double gameTime) {
    if (!triggered) return 0.0;
    final order = params.direction >= 0 ? index : (params.count - 1 - index);
    final start = _triggerTime + order * tileStagger;
    if (gameTime <= start) return 0.0;
    return clampd((gameTime - start) / fallDuration, 0.0, 1.0);
  }

  double _tipX(int index, double gameTime) {
    final p = fallProgress(index, gameTime);
    return tileX(index) +
        math.sin(p * math.pi * 0.5) * tileHeight * params.direction.sign;
  }

  double _tipY(int index, double gameTime) {
    final p = fallProgress(index, gameTime);
    return baseY + math.cos(p * math.pi * 0.5) * tileHeight;
  }

  @override
  void sample(
    HazardSample out,
    double x,
    double y,
    double radius,
    double gameTime,
  ) {
    out.reset();
    var minClearance = double.infinity;
    var minProgress = 1.0;

    for (var i = 0; i < params.count; i++) {
      final bx = tileX(i);
      final d = distancePointSegment(
            x,
            y,
            bx,
            baseY,
            _tipX(i, gameTime),
            _tipY(i, gameTime),
          ) -
          (params.thickness * 0.5 + radius);
      if (d < minClearance) minClearance = d;
      final p = fallProgress(i, gameTime);
      if (p < minProgress) minProgress = p;
    }

    out.clearance = minClearance;
    out.engaged = y >= anchorY && y <= anchorY + bandHeight;
    out.precision = clampd(minProgress, 0.0, 1.0);
  }

  @override
  void render(RenderContext ctx, double gameTime) {
    final theme = ctx.theme;

    ctx.stroke
      ..color = theme.safeGlow.withOpacity(triggered ? 0.12 : 0.55)
      ..strokeWidth = ctx.sl(0.6);
    ctx.canvas.drawLine(ctx.sp(6, triggerY), ctx.sp(94, triggerY), ctx.stroke);

    ctx.stroke
      ..color = theme.hazardEdge.withOpacity(0.2)
      ..strokeWidth = ctx.sl(0.5);
    ctx.canvas.drawLine(ctx.sp(4, baseY), ctx.sp(96, baseY), ctx.stroke);

    for (var i = 0; i < params.count; i++) {
      final p = fallProgress(i, gameTime);
      ctx.stroke
        ..color = Color.lerp(theme.hazardEdge, theme.safeGlow, p * 0.7)!
        ..strokeWidth = ctx.sl(params.thickness);
      ctx.canvas.drawLine(
        ctx.sp(tileX(i), baseY),
        ctx.sp(_tipX(i, gameTime), _tipY(i, gameTime)),
        ctx.stroke,
      );
    }
  }

  @override
  void captureState(SnapshotWriter writer) {
    super.captureState(writer);
    writer.writeDouble(_triggerTime);
  }

  @override
  void restoreState(SnapshotReader reader) {
    super.restoreState(reader);
    _triggerTime = reader.readDouble();
  }

  @override
  void resetRewindState() {
    super.resetRewindState();
    _triggerTime = -1.0;
  }
}
