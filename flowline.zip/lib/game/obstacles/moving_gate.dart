import 'dart:math' as math;
import 'dart:ui';

import '../../core/design_tokens.dart';
import '../../core/math_utils.dart';
import '../../render/render_context.dart';
import 'obstacle.dart';
import 'obstacle_family.dart';

/// A. MOVING GATE — a horizontal barrier with a laterally oscillating opening.
///
/// The teaching obstacle. It shows, without a word of text, that the world
/// moves when you scroll and stops when you stop.
class MovingGate extends Obstacle {
  @override
  ObstacleFamily get family => ObstacleFamily.movingGate;

  double get barY => anchorY + bandHeight * 0.5;

  @override
  double get evaluationY => barY;

  /// Opening centre at [gameTime]. Clamped so the gap never leaves the lane.
  double openingCenter(double gameTime) {
    final halfOpening = params.openingWidth * 0.5;
    final travel = math.min(
      params.amplitude,
      WorldMetrics.centerX - halfOpening - 3.0,
    );
    final t = gameTime * params.speedScale / math.max(params.period, 0.05);
    final wave = math.sin(tau * t + params.phase) * params.direction;
    return WorldMetrics.centerX + travel * wave;
  }

  @override
  void sample(
    HazardSample out,
    double x,
    double y,
    double radius,
    double gameTime,
  ) {
    out.reset();
    final dy = (y - barY).abs();
    final reach = params.thickness * 0.5 + radius;
    final half = params.openingWidth * 0.5;
    final lateral = (x - openingCenter(gameTime)).abs();

    out.precision = clampd(1.0 - lateral / math.max(half, 0.001), 0.0, 1.0);

    if (dy >= reach) {
      out.clearance = dy - reach;
      out.engaged = false;
      return;
    }
    out.engaged = true;
    out.clearance = half - lateral - radius;
  }

  @override
  void render(RenderContext ctx, double gameTime) {
    final cx = openingCenter(gameTime);
    final half = params.openingWidth * 0.5;
    final t = params.thickness;
    final theme = ctx.theme;

    final top = ctx.sy(barY + t * 0.5);
    final bottom = ctx.sy(barY - t * 0.5);

    ctx.fill.color = theme.hazardFill;
    ctx.stroke
      ..color = theme.hazardEdge
      ..strokeWidth = 1.4;

    final left = Rect.fromLTRB(ctx.sx(-2), top, ctx.sx(cx - half), bottom);
    final right =
        Rect.fromLTRB(ctx.sx(cx + half), top, ctx.sx(WorldMetrics.width + 2), bottom);
    final r = Radius.circular(ctx.sl(t * 0.35));

    for (final rect in [left, right]) {
      if (rect.width <= 0) continue;
      final rrect = RRect.fromRectAndRadius(rect, r);
      ctx.canvas.drawRRect(rrect, ctx.fill);
      ctx.canvas.drawRRect(rrect, ctx.stroke);
    }

    // Safe-window indicator: a soft rail across the opening.
    ctx.stroke
      ..color = theme.safeGlow.withOpacity(0.55)
      ..strokeWidth = ctx.sl(0.7);
    ctx.canvas.drawLine(
      ctx.sp(cx - half + 1.0, barY),
      ctx.sp(cx + half - 1.0, barY),
      ctx.stroke,
    );
    ctx.drawGlow(cx, barY, half * 0.5, theme.safeGlow, intensity: 0.5);
  }
}
