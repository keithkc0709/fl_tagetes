import '../../core/design_tokens.dart';
import '../../render/render_context.dart';
import '../rewind/rewindable.dart';
import '../rewind/snapshot.dart';
import 'obstacle_family.dart';

/// Result of probing an obstacle with the Spark's circle.
///
/// Reused as a scratch object; never allocate one inside the update loop.
class HazardSample {
  /// World units of clearance. Negative means the Spark is overlapping a
  /// hazard.
  double clearance = 0.0;

  /// 0..1, where 1 is the dead centre of the safe window. This is what grades
  /// Perfect/Good/Pass — it measures *how well timed* the pass was, not merely
  /// whether it happened.
  double precision = 0.0;

  /// True while the Spark is inside the obstacle's active band.
  bool engaged = false;

  void reset() {
    clearance = double.infinity;
    precision = 0.0;
    engaged = false;
  }
}

/// Tunable parameters, interpreted per family.
///
/// One flat struct rather than per-family classes keeps the generator, the
/// pool and the debug panel simple, and keeps every obstacle allocation-free
/// on recycle.
class ObstacleParams {
  double period = 2.0;
  double phase = 0.0;
  double amplitude = 24.0;
  double openingWidth = 30.0;
  double radius = 26.0;
  double thickness = 4.4;
  double direction = 1.0;
  double speedScale = 1.0;
  double extra = 0.0;
  int count = 5;

  void reset() {
    period = 2.0;
    phase = 0.0;
    amplitude = 24.0;
    openingWidth = 30.0;
    radius = 26.0;
    thickness = 4.4;
    direction = 1.0;
    speedScale = 1.0;
    extra = 0.0;
    count = 5;
  }
}

/// Base class for every hazard.
///
/// The contract is deliberately narrow: given a game time and a circle, report
/// clearance and precision, and draw yourself. Obstacles own no scoring, no
/// audio and no difficulty logic.
abstract class Obstacle implements Rewindable {
  static int _idCounter = 1000;

  int _rewindId = 0;

  @override
  int get rewindId => _rewindId;

  ObstacleFamily get family;

  double anchorY = 0.0;
  double bandHeight = 44.0;
  final ObstacleParams params = ObstacleParams();

  /// True once this obstacle has produced a score event this pass.
  bool scored = false;

  /// World Y at which timing is graded.
  double get evaluationY => anchorY + bandHeight * 0.5;

  double get influenceStart => anchorY - 8.0;
  double get influenceEnd => anchorY + bandHeight + 8.0;

  double get laneCenterX => WorldMetrics.centerX;

  /// Called when the object is taken from the pool. Assigns a fresh rewind id
  /// so a stale snapshot can never leak into a recycled obstacle.
  void activate(double anchorY) {
    this.anchorY = anchorY;
    _rewindId = _idCounter++;
    scored = false;
    onActivate();
  }

  void onActivate() {}

  /// Optional per-frame integration for families with real state.
  void update(double gameTime, double gameDelta) {}

  void sample(HazardSample out, double x, double y, double radius, double gameTime);

  void render(RenderContext ctx, double gameTime);

  /// Debug overlay: safe zone and timing window visualisation.
  void renderDebug(RenderContext ctx, double gameTime) {}

  @override
  void captureState(SnapshotWriter writer) {
    writer.writeBool(scored);
  }

  @override
  void restoreState(SnapshotReader reader) {
    scored = reader.readBool();
  }

  @override
  void resetRewindState() {
    scored = false;
  }

  void recycle() {
    params.reset();
    scored = false;
    _rewindId = 0;
  }
}
