import 'bouncer.dart';
import 'crusher.dart';
import 'domino_chain.dart';
import 'moving_gate.dart';
import 'obstacle.dart';
import 'obstacle_family.dart';
import 'orbit_release.dart';
import 'pendulum.dart';
import 'rotating_ring.dart';
import 'synchronizer.dart';

/// Pooled construction of obstacles.
///
/// Steady-state gameplay allocates zero obstacles: the handful in flight are
/// recycled behind the player and re-parameterised ahead of it. This is the
/// difference between a clean frame graph and a saw-tooth of GC pauses.
class ObstacleFactory {
  final Map<ObstacleFamily, List<Obstacle>> _pools =
      <ObstacleFamily, List<Obstacle>>{};

  int _created = 0;

  int get createdCount => _created;

  int get pooledCount {
    var total = 0;
    for (final pool in _pools.values) {
      total += pool.length;
    }
    return total;
  }

  Obstacle obtain(ObstacleFamily family) {
    final pool = _pools.putIfAbsent(family, () => <Obstacle>[]);
    if (pool.isNotEmpty) return pool.removeLast();
    _created++;
    return _construct(family);
  }

  void release(Obstacle obstacle) {
    obstacle.recycle();
    _pools.putIfAbsent(obstacle.family, () => <Obstacle>[]).add(obstacle);
  }

  /// Pre-warms the pool so the first seconds of play never construct anything.
  void prewarm(int perFamily) {
    for (final family in ObstacleFamily.values) {
      final pool = _pools.putIfAbsent(family, () => <Obstacle>[]);
      while (pool.length < perFamily) {
        _created++;
        pool.add(_construct(family));
      }
    }
  }

  Obstacle _construct(ObstacleFamily family) => switch (family) {
        ObstacleFamily.movingGate => MovingGate(),
        ObstacleFamily.rotatingRing => RotatingRing(),
        ObstacleFamily.pendulum => Pendulum(),
        ObstacleFamily.crusher => Crusher(),
        ObstacleFamily.bouncer => Bouncer(),
        ObstacleFamily.orbitRelease => OrbitRelease(),
        ObstacleFamily.synchronizer => Synchronizer(),
        ObstacleFamily.dominoChain => DominoChain(),
      };

  void clear() => _pools.clear();
}
