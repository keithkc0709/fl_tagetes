/// The obstacle vocabulary.
///
/// Adding a family means: add an enum value, implement [Obstacle], register it
/// in `ObstacleFactory`, and give it a weight in `GenerationRules`. No other
/// system needs to change.
enum ObstacleFamily {
  movingGate,
  rotatingRing,
  pendulum,
  crusher,
  bouncer,
  orbitRelease,
  synchronizer,
  dominoChain;

  String get id => name;

  /// Families that demand precise multi-step timing. The generator enforces a
  /// cooldown between these so a run never stacks two brain-melters back to
  /// back.
  bool get isDemanding =>
      this == ObstacleFamily.synchronizer ||
      this == ObstacleFamily.dominoChain ||
      this == ObstacleFamily.orbitRelease;

  /// Families gentle enough to serve as recovery beats.
  bool get isRecovery =>
      this == ObstacleFamily.movingGate || this == ObstacleFamily.crusher;
}
