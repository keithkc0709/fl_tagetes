import 'dart:math' as math;
import 'dart:ui';

import '../../core/math_utils.dart';
import '../../render/render_context.dart';
import '../rewind/snapshot.dart';
import 'obstacle.dart';
import 'obstacle_family.dart';

/// F. ORBIT RELEASE — a satellite orbits a hub until the Spark crosses the
/// trigger line, at which point it is flung along its tangent.
///
/// One of only three families with genuine state (`_releaseTime`,
/// `_releaseAngle`), and therefore one of the few that writes anything to a
/// rewind snapshot.
class OrbitRelease extends Obstacle {
  @override
  ObstacleFamily get family => ObstacleFamily.orbitRelease;

  double _releaseTime = -1.0;
  double _releaseAngle = 0.0;

  double get hubY => anchorY + bandHeight * 0.55;
  double get triggerY => anchorY + 4.0;
  double get satelliteRadius => params.thickness * 1.35;
  double get flingSpeed => params.radius * 1.9 * params.speedScale;

  @override
  double get evaluationY => triggerY;

  bool get released => _releaseTime >= 0.0;

  @override
  void onActivate() {
    _releaseTime = -1.0;
    _releaseAngle = 0.0;
  }

  double orbitAngle(double gameTime) {
    final rate = tau * params.speedScale / math.max(params.period, 0.05);
    return wrapAngle(params.phase + params.direction * rate * gameTime);
  }

  /// Records the release. Idempotent: calling it twice on the same pass (which
  /// can happen after a rewind) cannot double-trigger.
  void trigger(double gameTime) {
    if (released) return;
    _releaseTime = gameTime;
    _releaseAngle = orbitAngle(gameTime);
  }

  void _position(double gameTime, List<double> out) {
    if (!released || gameTime < _releaseTime) {
      final a = released ? _releaseAngle : orbitAngle(gameTime);
      out[0] = laneCenterX + math.cos(a) * params.radius;
      out[1] = hubY + math.sin(a) * params.radius;
      return;
    }
    final elapsed = gameTime - _releaseTime;
    final tangentX = -math.sin(_releaseAngle) * params.direction;
    final tangentY = math.cos(_releaseAngle) * params.direction;
    out[0] = laneCenterX +
        math.cos(_releaseAngle) * params.radius +
        tangentX * flingSpeed * elapsed;
    out[1] = hubY +
        math.sin(_releaseAngle) * params.radius +
        tangentY * flingSpeed * elapsed;
  }

  final List<double> _scratch = <double>[0.0, 0.0];

  @override
  void sample(
    HazardSample out,
    double x,
    double y,
    double radius,
    double gameTime,
  ) {
    out.reset();
    _position(gameTime, _scratch);
    out.clearance =
        distance(x, y, _scratch[0], _scratch[1]) - (satelliteRadius + radius);
    out.engaged = y >= anchorY && y <= anchorY + bandHeight;

    // Best timing releases the satellite while it is far off the centre line,
    // so it has the whole band to travel away from the corridor.
    final offset = (_scratch[0] - laneCenterX).abs();
    out.precision = clampd(offset / math.max(params.radius, 1.0), 0.0, 1.0);
  }

  @override
  void render(RenderContext ctx, double gameTime) {
    final theme = ctx.theme;

    ctx.stroke
      ..color = theme.hazardEdge.withOpacity(0.22)
      ..strokeWidth = ctx.sl(0.6);
    ctx.canvas.drawCircle(
      ctx.sp(laneCenterX, hubY),
      ctx.sl(params.radius),
      ctx.stroke,
    );

    ctx.fill.color = theme.hazardEdge.withOpacity(0.7);
    ctx.canvas.drawCircle(ctx.sp(laneCenterX, hubY), ctx.sl(1.8), ctx.fill);

    ctx.stroke
      ..color = theme.safeGlow.withOpacity(released ? 0.15 : 0.6)
      ..strokeWidth = ctx.sl(0.6);
    ctx.canvas.drawLine(
      ctx.sp(6, triggerY),
      ctx.sp(94, triggerY),
      ctx.stroke,
    );

    _position(gameTime, _scratch);
    ctx.fill.color = theme.hazardFill;
    ctx.canvas.drawCircle(
      ctx.sp(_scratch[0], _scratch[1]),
      ctx.sl(satelliteRadius),
      ctx.fill,
    );
    ctx.stroke
      ..color = theme.hazardEdge
      ..strokeWidth = 1.6;
    ctx.canvas.drawCircle(
      ctx.sp(_scratch[0], _scratch[1]),
      ctx.sl(satelliteRadius),
      ctx.stroke,
    );
    ctx.drawGlow(
      _scratch[0],
      _scratch[1],
      satelliteRadius * 1.8,
      released ? theme.hazardEdge : theme.accent,
      intensity: 0.7,
    );
  }

  @override
  void captureState(SnapshotWriter writer) {
    super.captureState(writer);
    writer.writeDouble(_releaseTime);
    writer.writeDouble(_releaseAngle);
  }

  @override
  void restoreState(SnapshotReader reader) {
    super.restoreState(reader);
    _releaseTime = reader.readDouble();
    _releaseAngle = reader.readDouble();
  }

  @override
  void resetRewindState() {
    super.resetRewindState();
    _releaseTime = -1.0;
    _releaseAngle = 0.0;
  }
}
