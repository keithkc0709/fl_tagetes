import 'dart:math' as math;
import 'dart:ui';

import '../../core/math_utils.dart';
import '../../render/render_context.dart';
import 'obstacle.dart';
import 'obstacle_family.dart';

/// C. PENDULUM — a swinging bob and rod that sweep across the corridor.
class Pendulum extends Obstacle {
  @override
  ObstacleFamily get family => ObstacleFamily.pendulum;

  double get pivotY => anchorY + bandHeight;
  double get rodLength => params.radius;
  double get bobRadius => params.thickness * 1.6;

  @override
  double get evaluationY => anchorY + bandHeight * 0.45;

  double swingAngle(double gameTime) {
    final t = gameTime * params.speedScale / math.max(params.period, 0.05);
    // amplitude is stored in world units for other families; here it is mapped
    // to radians so a single generator knob drives every family.
    final amplitudeRadians = clampd(params.amplitude / 30.0, 0.15, 1.25);
    return amplitudeRadians * math.sin(tau * t + params.phase) * params.direction;
  }

  double bobX(double gameTime) =>
      laneCenterX + math.sin(swingAngle(gameTime)) * rodLength;

  double bobY(double gameTime) =>
      pivotY - math.cos(swingAngle(gameTime)) * rodLength;

  @override
  void sample(
    HazardSample out,
    double x,
    double y,
    double radius,
    double gameTime,
  ) {
    out.reset();
    final bx = bobX(gameTime);
    final by = bobY(gameTime);

    final toBob = distance(x, y, bx, by) - (bobRadius + radius);
    final toRod = distancePointSegment(x, y, laneCenterX, pivotY, bx, by) -
        (params.thickness * 0.35 + radius);

    out.clearance = math.min(toBob, toRod);
    out.engaged = y >= anchorY && y <= anchorY + bandHeight;
    // Precision rewards passing with real daylight between Spark and bob.
    out.precision = clampd(out.clearance / (rodLength * 0.55), 0.0, 1.0);
  }

  @override
  void render(RenderContext ctx, double gameTime) {
    final theme = ctx.theme;
    final bx = bobX(gameTime);
    final by = bobY(gameTime);

    ctx.stroke
      ..color = theme.hazardEdge.withOpacity(0.75)
      ..strokeWidth = ctx.sl(params.thickness * 0.7);
    ctx.canvas.drawLine(ctx.sp(laneCenterX, pivotY), ctx.sp(bx, by), ctx.stroke);

    ctx.fill.color = theme.hazardEdge;
    ctx.canvas.drawCircle(ctx.sp(laneCenterX, pivotY), ctx.sl(1.4), ctx.fill);

    ctx.fill.color = theme.hazardFill;
    ctx.canvas.drawCircle(ctx.sp(bx, by), ctx.sl(bobRadius), ctx.fill);
    ctx.stroke
      ..color = theme.hazardEdge
      ..strokeWidth = 1.6;
    ctx.canvas.drawCircle(ctx.sp(bx, by), ctx.sl(bobRadius), ctx.stroke);
    ctx.drawGlow(bx, by, bobRadius * 1.4, theme.hazardEdge, intensity: 0.5);
  }
}
