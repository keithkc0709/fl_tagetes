import 'dart:math' as math;
import 'dart:ui';

import '../../core/design_tokens.dart';
import '../../core/math_utils.dart';
import '../../render/render_context.dart';
import 'obstacle.dart';
import 'obstacle_family.dart';

/// B. ROTATING RING — an annulus with a single rotating gap.
class RotatingRing extends Obstacle {
  @override
  ObstacleFamily get family => ObstacleFamily.rotatingRing;

  double get centerY => anchorY + bandHeight * 0.5;

  @override
  double get evaluationY => centerY;

  /// Half-angle of the opening, derived from the configured opening width at
  /// the ring radius so difficulty scaling reads identically to a gate.
  double get openingHalfAngle => clampd(
        (params.openingWidth * 0.5) / math.max(params.radius, 1.0),
        0.12,
        1.35,
      );

  double openingAngle(double gameTime) {
    final rate = tau * params.speedScale / math.max(params.period, 0.05);
    return wrapAngle(params.phase + params.direction * rate * gameTime);
  }

  @override
  void sample(
    HazardSample out,
    double x,
    double y,
    double radius,
    double gameTime,
  ) {
    out.reset();
    final cx = laneCenterX;
    final d = distance(x, y, cx, centerY);
    final radial = (d - params.radius).abs();
    final reach = params.thickness * 0.5 + radius;

    final theta = math.atan2(y - centerY, x - cx);
    final angularOffset = angularDistance(theta, openingAngle(gameTime));
    out.precision =
        clampd(1.0 - angularOffset / openingHalfAngle, 0.0, 1.0);

    if (radial >= reach) {
      out.clearance = radial - reach;
      out.engaged = false;
      return;
    }
    out.engaged = true;
    // Convert the angular gap to an arc length so clearance stays in world units.
    out.clearance =
        (openingHalfAngle - angularOffset) * params.radius - radius;
  }

  @override
  void render(RenderContext ctx, double gameTime) {
    final theme = ctx.theme;
    final center = ctx.sp(laneCenterX, centerY);
    final rPx = ctx.sl(params.radius);
    final gap = openingHalfAngle;
    final start = openingAngle(gameTime) + gap;
    final sweep = tau - gap * 2.0;

    // Canvas angles grow clockwise in screen space while world Y grows upward,
    // so the arc is mirrored vertically to match the sampled geometry.
    final rect = Rect.fromCircle(center: center, radius: rPx);

    ctx.canvas.save();
    ctx.canvas.translate(center.dx, center.dy);
    ctx.canvas.scale(1.0, -1.0);
    ctx.canvas.translate(-center.dx, -center.dy);

    ctx.stroke
      ..color = theme.hazardEdge
      ..strokeWidth = ctx.sl(params.thickness)
      ..strokeCap = StrokeCap.round;
    ctx.canvas.drawArc(rect, start, sweep, false, ctx.stroke);

    ctx.stroke
      ..color = theme.hazardFill
      ..strokeWidth = ctx.sl(params.thickness * 0.55);
    ctx.canvas.drawArc(rect, start, sweep, false, ctx.stroke);

    ctx.canvas.restore();

    final ax = laneCenterX + math.cos(openingAngle(gameTime)) * params.radius;
    final ay = centerY + math.sin(openingAngle(gameTime)) * params.radius;
    ctx.drawGlow(ax, ay, params.thickness * 1.6, theme.safeGlow, intensity: 0.8);
  }
}
