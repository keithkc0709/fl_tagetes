import 'dart:math' as math;
import 'dart:ui';

import '../../core/design_tokens.dart';
import '../../core/math_utils.dart';
import '../../render/render_context.dart';
import 'obstacle.dart';
import 'obstacle_family.dart';

/// G. SYNCHRONIZER — two independent gates whose openings must line up.
///
/// The periods are intentionally close but not equal, so the alignment window
/// drifts and the player has to *hunt* for it with scroll speed rather than
/// memorise a rhythm.
class Synchronizer extends Obstacle {
  @override
  ObstacleFamily get family => ObstacleFamily.synchronizer;

  double get lowerY => anchorY + bandHeight * 0.32;
  double get upperY => anchorY + bandHeight * 0.72;

  double get secondPeriod => math.max(params.period * (1.0 + params.extra), 0.05);

  @override
  double get evaluationY => upperY;

  double _center(double gameTime, double period, double phase, double dir) {
    final halfOpening = params.openingWidth * 0.5;
    final travel = math.min(
      params.amplitude,
      WorldMetrics.centerX - halfOpening - 3.0,
    );
    final t = gameTime * params.speedScale / period;
    return WorldMetrics.centerX + travel * math.sin(tau * t + phase) * dir;
  }

  double lowerCenter(double gameTime) => _center(
        gameTime,
        math.max(params.period, 0.05),
        params.phase,
        params.direction,
      );

  double upperCenter(double gameTime) => _center(
        gameTime,
        secondPeriod,
        params.phase + math.pi * 0.5,
        -params.direction,
      );

  void _sampleOne(
    HazardSample out,
    double x,
    double y,
    double radius,
    double barY,
    double centerX,
  ) {
    final dy = (y - barY).abs();
    final reach = params.thickness * 0.5 + radius;
    final half = params.openingWidth * 0.5;
    final lateral = (x - centerX).abs();

    final precision = clampd(1.0 - lateral / math.max(half, 0.001), 0.0, 1.0);
    out.precision = math.min(out.precision, precision);

    if (dy >= reach) {
      out.clearance = math.min(out.clearance, dy - reach);
      return;
    }
    out.engaged = true;
    out.clearance = math.min(out.clearance, half - lateral - radius);
  }

  @override
  void sample(
    HazardSample out,
    double x,
    double y,
    double radius,
    double gameTime,
  ) {
    out.reset();
    out.precision = 1.0;
    _sampleOne(out, x, y, radius, lowerY, lowerCenter(gameTime));
    _sampleOne(out, x, y, radius, upperY, upperCenter(gameTime));
  }

  void _renderBar(RenderContext ctx, double barY, double cx) {
    final theme = ctx.theme;
    final half = params.openingWidth * 0.5;
    final t = params.thickness;
    final top = ctx.sy(barY + t * 0.5);
    final bottom = ctx.sy(barY - t * 0.5);
    final r = Radius.circular(ctx.sl(t * 0.35));

    ctx.fill.color = theme.hazardFill;
    ctx.stroke
      ..color = theme.hazardEdge
      ..strokeWidth = 1.4;

    final left = Rect.fromLTRB(ctx.sx(-2), top, ctx.sx(cx - half), bottom);
    final right = Rect.fromLTRB(
        ctx.sx(cx + half), top, ctx.sx(WorldMetrics.width + 2), bottom);
    for (final rect in [left, right]) {
      if (rect.width <= 0) continue;
      final rr = RRect.fromRectAndRadius(rect, r);
      ctx.canvas.drawRRect(rr, ctx.fill);
      ctx.canvas.drawRRect(rr, ctx.stroke);
    }
  }

  @override
  void render(RenderContext ctx, double gameTime) {
    final lower = lowerCenter(gameTime);
    final upper = upperCenter(gameTime);
    _renderBar(ctx, lowerY, lower);
    _renderBar(ctx, upperY, upper);

    // Alignment ribbon: brightens as the two openings converge, which is the
    // entire tell for this family and needs no words.
    final alignment =
        clampd(1.0 - (lower - upper).abs() / params.openingWidth, 0.0, 1.0);
    ctx.stroke
      ..color = ctx.theme.safeGlow.withOpacity(0.15 + 0.6 * alignment)
      ..strokeWidth = ctx.sl(0.6 + 1.4 * alignment);
    ctx.canvas.drawLine(
      ctx.sp(lower, lowerY),
      ctx.sp(upper, upperY),
      ctx.stroke,
    );
    if (alignment > 0.75) {
      ctx.drawGlow(
        (lower + upper) * 0.5,
        (lowerY + upperY) * 0.5,
        params.openingWidth * 0.4,
        ctx.theme.safeGlow,
        intensity: alignment,
      );
    }
  }
}
