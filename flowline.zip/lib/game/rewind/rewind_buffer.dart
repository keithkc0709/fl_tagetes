import '../../core/game_balance_config.dart';
import 'rewindable.dart';
import 'snapshot.dart';

/// Fixed-capacity circular buffer of world snapshots.
///
/// Snapshots are captured on a fixed *game-time* grid, not a real-time grid, so
/// history density is identical whether the player crawled or flicked through
/// a segment.
class RewindBuffer {
  final GameBalanceConfig cfg;
  final int capacity;

  final List<StateSnapshot> _slots;
  final SnapshotReader _reader = SnapshotReader();

  int _start = 0;
  int _count = 0;
  double _lastCaptureTime = double.negativeInfinity;

  RewindBuffer(this.cfg)
      : capacity = (cfg.maxRewindSeconds / cfg.snapshotInterval).ceil() + 4,
        _slots = List<StateSnapshot>.generate(
          (cfg.maxRewindSeconds / cfg.snapshotInterval).ceil() + 4,
          (_) => StateSnapshot(),
          growable: false,
        );

  int get count => _count;
  bool get isEmpty => _count == 0;

  double get oldestTime => _count == 0 ? 0.0 : _at(0).gameTime;
  double get newestTime => _count == 0 ? 0.0 : _at(_count - 1).gameTime;
  double get bufferedSeconds => _count == 0 ? 0.0 : newestTime - oldestTime;

  StateSnapshot _at(int index) => _slots[(_start + index) % capacity];

  /// Captures a snapshot if enough game-time has elapsed since the last one.
  /// Returns true if a capture occurred.
  bool maybeCapture(
    double gameTime,
    double flowPosition,
    List<Rewindable> targets,
  ) {
    if (gameTime < _lastCaptureTime + cfg.snapshotInterval) return false;
    capture(gameTime, flowPosition, targets);
    return true;
  }

  void capture(
    double gameTime,
    double flowPosition,
    List<Rewindable> targets,
  ) {
    final slot = _pushSlot();
    slot.begin(gameTime, flowPosition);
    final writer = slot.writer;

    for (var i = 0; i < targets.length; i++) {
      final target = targets[i];
      writer.writeInt(target.rewindId);
      final countIndex = writer.length;
      writer.writeDouble(0.0); // placeholder for payload length
      target.captureState(writer);
      writer.patch(countIndex, (writer.length - countIndex - 1).toDouble());
    }

    _lastCaptureTime = gameTime;
    _trimOlderThan(gameTime - cfg.maxRewindSeconds);
  }

  StateSnapshot _pushSlot() {
    if (_count < capacity) {
      final slot = _at(_count);
      _count++;
      return slot;
    }
    // Overwrite the oldest.
    final slot = _slots[_start];
    _start = (_start + 1) % capacity;
    return slot;
  }

  void _trimOlderThan(double cutoff) {
    while (_count > 1 && _at(0).gameTime < cutoff) {
      _start = (_start + 1) % capacity;
      _count--;
    }
  }

  /// Drops every snapshot newer than [gameTime]. Called when the player resumes
  /// forward motion after a rewind: the future they previously played is no
  /// longer the future they are about to play.
  void discardAfter(double gameTime) {
    while (_count > 0 && _at(_count - 1).gameTime > gameTime) {
      _count--;
    }
    _lastCaptureTime = _count == 0 ? double.negativeInfinity : newestTime;
  }

  /// Index of the newest snapshot at or before [gameTime], or -1.
  int _indexAtOrBefore(double gameTime) {
    var lo = 0;
    var hi = _count - 1;
    var result = -1;
    while (lo <= hi) {
      final mid = (lo + hi) >> 1;
      if (_at(mid).gameTime <= gameTime) {
        result = mid;
        lo = mid + 1;
      } else {
        hi = mid - 1;
      }
    }
    return result;
  }

  /// Interpolated flow position at [gameTime], or null if out of range.
  ///
  /// Interpolating position (rather than snapping to the nearest snapshot)
  /// keeps the Spark's reverse motion perfectly smooth at 30Hz capture.
  double? flowPositionAt(double gameTime) {
    if (_count == 0) return null;
    final index = _indexAtOrBefore(gameTime);
    if (index < 0) return _at(0).flowPosition;
    if (index >= _count - 1) return _at(_count - 1).flowPosition;

    final a = _at(index);
    final b = _at(index + 1);
    final span = b.gameTime - a.gameTime;
    if (span <= 1e-9) return a.flowPosition;
    final t = (gameTime - a.gameTime) / span;
    return a.flowPosition + (b.flowPosition - a.flowPosition) * t;
  }

  /// Restores discrete state to the newest snapshot at or before [gameTime].
  ///
  /// Discrete state is snapped rather than interpolated on purpose: a domino
  /// chain that is half-restored between two trigger times would produce
  /// duplicate collision and scoring events on resume.
  bool restoreTo(double gameTime, Map<int, Rewindable> targetsById) {
    if (_count == 0) return false;
    final index = _indexAtOrBefore(gameTime);
    final slot = _at(index < 0 ? 0 : index);

    final restored = <int>{};
    final data = slot.writer.data;
    final length = slot.writer.length;
    var cursor = 0;

    while (cursor + 1 < length) {
      final id = data[cursor].round();
      final payloadLength = data[cursor + 1].round();
      final payloadStart = cursor + 2;
      final payloadEnd = payloadStart + payloadLength;
      final target = targetsById[id];
      if (target != null) {
        _reader.bind(data, payloadStart, payloadEnd);
        target.restoreState(_reader);
        restored.add(id);
      }
      cursor = payloadEnd;
    }

    for (final entry in targetsById.entries) {
      if (!restored.contains(entry.key)) entry.value.resetRewindState();
    }
    return true;
  }

  void clear() {
    _start = 0;
    _count = 0;
    _lastCaptureTime = double.negativeInfinity;
  }
}
