import 'snapshot.dart';

/// Anything whose state is not a pure function of `gameTime`.
///
/// Most FLOWLINE obstacles are analytic — a gate's position is
/// `f(gameTime, params)` — so they capture almost nothing and rewind for free.
/// Only genuinely stateful entities (a released orbiter, a triggered domino
/// chain, the scoring system) need real snapshots, which is why the buffer
/// stays small enough to sample at 30Hz for four seconds without pressure on
/// the garbage collector.
abstract class Rewindable {
  /// Stable identity across a run. Recycled objects must be given a fresh id so
  /// a stale snapshot cannot restore state into the wrong obstacle.
  int get rewindId;

  void captureState(SnapshotWriter writer);

  void restoreState(SnapshotReader reader);

  /// Called when this object has no entry in the snapshot being restored,
  /// i.e. it did not exist at that point in time.
  void resetRewindState();
}
