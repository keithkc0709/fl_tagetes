import 'dart:typed_data';

/// Append-only writer over a growable `Float64List`.
///
/// Doubles are the only primitive: ints and bools are encoded as doubles so a
/// snapshot is one flat, cache-friendly, allocation-free buffer.
class SnapshotWriter {
  Float64List _data = Float64List(64);
  int _length = 0;

  int get length => _length;
  Float64List get data => _data;

  void reset() => _length = 0;

  void writeDouble(double value) {
    if (_length == _data.length) _grow();
    _data[_length++] = value;
  }

  void writeInt(int value) => writeDouble(value.toDouble());

  void writeBool(bool value) => writeDouble(value ? 1.0 : 0.0);

  void patch(int index, double value) => _data[index] = value;

  void _grow() {
    final grown = Float64List(_data.length * 2);
    grown.setRange(0, _data.length, _data);
    _data = grown;
  }
}

/// Cursor-based reader over a snapshot slice.
class SnapshotReader {
  Float64List _data = Float64List(0);
  int _cursor = 0;
  int _end = 0;

  void bind(Float64List data, int start, int end) {
    _data = data;
    _cursor = start;
    _end = end;
  }

  bool get hasMore => _cursor < _end;

  double readDouble() => _cursor < _end ? _data[_cursor++] : 0.0;

  int readInt() => readDouble().round();

  bool readBool() => readDouble() >= 0.5;
}

/// One captured world state at a given game time.
class StateSnapshot {
  double gameTime = 0.0;
  double flowPosition = 0.0;
  final SnapshotWriter writer = SnapshotWriter();

  void begin(double gameTime, double flowPosition) {
    this.gameTime = gameTime;
    this.flowPosition = flowPosition;
    writer.reset();
  }
}
