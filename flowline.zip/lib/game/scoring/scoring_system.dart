import 'dart:math' as math;

import '../../core/game_balance_config.dart';
import '../../models/score_event.dart';
import '../obstacles/obstacle_family.dart';
import '../rewind/rewindable.dart';
import '../rewind/snapshot.dart';

/// Score, combo and run tallies.
///
/// Implements [Rewindable] with a reserved id so a rewind un-awards points and
/// un-breaks combos exactly as it un-moves obstacles. Without this, scrubbing
/// backwards and forwards over one gate would farm points.
class ScoringSystem implements Rewindable {
  static const int reservedRewindId = 1;

  final GameBalanceConfig cfg;

  ScoringSystem(this.cfg);

  int score = 0;
  int combo = 0;
  int bestCombo = 0;
  int perfectCount = 0;
  int goodCount = 0;
  int passCount = 0;
  int failCount = 0;

  @override
  int get rewindId => reservedRewindId;

  double get comboMultiplier {
    final steps = combo ~/ cfg.comboStep;
    return math.min(
      cfg.maxComboMultiplier,
      1.0 + steps * cfg.comboMultiplierStep,
    );
  }

  /// Grades a pass from its precision, or returns [Grade.fail] on collision.
  Grade gradeFor(double precision, {required bool collided}) {
    if (collided) return Grade.fail;
    if (precision >= cfg.perfectThreshold) return Grade.perfect;
    if (precision >= cfg.goodThreshold) return Grade.good;
    return Grade.pass;
  }

  ScoreEvent register({
    required Grade grade,
    required ObstacleFamily family,
    required double precision,
    required double gameTime,
  }) {
    var points = 0;

    switch (grade) {
      case Grade.perfect:
        perfectCount++;
        combo++;
        points = (cfg.basePoints * cfg.perfectMultiplier * comboMultiplier)
            .round();
      case Grade.good:
        goodCount++;
        combo++;
        points =
            (cfg.basePoints * cfg.goodMultiplier * comboMultiplier).round();
      case Grade.pass:
        passCount++;
        // A scrappy pass keeps the run alive but does not build the combo.
        points = (cfg.basePoints * comboMultiplier).round();
      case Grade.fail:
        failCount++;
        combo = 0;
        points = 0;
    }

    score += points;
    if (combo > bestCombo) bestCombo = combo;

    return ScoreEvent(
      grade: grade,
      family: family,
      points: points,
      comboAfter: combo,
      precision: precision,
      gameTime: gameTime,
    );
  }

  void reset() {
    score = 0;
    combo = 0;
    bestCombo = 0;
    perfectCount = 0;
    goodCount = 0;
    passCount = 0;
    failCount = 0;
  }

  @override
  void captureState(SnapshotWriter writer) {
    writer
      ..writeInt(score)
      ..writeInt(combo)
      ..writeInt(bestCombo)
      ..writeInt(perfectCount)
      ..writeInt(goodCount)
      ..writeInt(passCount)
      ..writeInt(failCount);
  }

  @override
  void restoreState(SnapshotReader reader) {
    score = reader.readInt();
    combo = reader.readInt();
    bestCombo = reader.readInt();
    perfectCount = reader.readInt();
    goodCount = reader.readInt();
    passCount = reader.readInt();
    failCount = reader.readInt();
  }

  @override
  void resetRewindState() {
    // The scoring system always exists; nothing to do.
  }
}
