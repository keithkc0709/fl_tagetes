import '../obstacles/obstacle.dart';

/// A recycled slice of world.
///
/// Segments exist for generation and recycling bookkeeping only; the player is
/// never shown a seam, and nothing about the visual presentation is
/// segment-aware.
class Segment {
  int index = 0;
  int seed = 0;
  double startY = 0.0;
  double length = 0.0;
  int tier = 0;

  final List<Obstacle> obstacles = <Obstacle>[];

  double get endY => startY + length;

  /// The vertical band, at the start of the segment, guaranteed free of
  /// hazards. The player always enters a segment in a survivable state.
  double get safeEntryEnd => obstacles.isEmpty ? endY : obstacles.first.anchorY;

  bool contains(double y) => y >= startY && y < endY;

  void reset() {
    index = 0;
    seed = 0;
    startY = 0.0;
    length = 0.0;
    tier = 0;
    obstacles.clear();
  }
}
