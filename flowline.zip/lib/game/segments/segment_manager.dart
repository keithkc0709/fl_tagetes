import 'dart:math' as math;

import '../../core/game_balance_config.dart';
import '../difficulty/adaptive_difficulty.dart';
import '../generation/procedural_generator.dart';
import '../obstacles/obstacle.dart';
import '../obstacles/obstacle_factory.dart';
import 'segment.dart';
import 'segment_pool.dart';

/// Keeps a window of generated world around the player.
///
/// Generation always happens beyond the top of the viewport and recycling
/// always happens below the reach of the rewind buffer, so the player never
/// witnesses either.
class SegmentManager {
  final GameBalanceConfig cfg;
  final ProceduralGenerator generator;
  final ObstacleFactory obstacleFactory;
  final SegmentPool segmentPool;

  /// Ordered by ascending [Segment.startY].
  final List<Segment> active = <Segment>[];

  int _nextIndex = 0;
  double _nextStartY = 0.0;

  /// Extra runway before the first hazard so the very first upward scroll is
  /// consequence-free.
  static const double introRunway = 34.0;

  SegmentManager({
    required this.cfg,
    required this.generator,
    required this.obstacleFactory,
    SegmentPool? segmentPool,
  }) : segmentPool = segmentPool ?? SegmentPool();

  int get activeSegmentCount => active.length;

  int get activeObstacleCount {
    var total = 0;
    for (final segment in active) {
      total += segment.obstacles.length;
    }
    return total;
  }

  void reset(int seed) {
    for (final segment in active) {
      _releaseSegment(segment);
    }
    active.clear();
    generator.reset(seed);
    _nextIndex = 0;
    _nextStartY = introRunway;
  }

  void _releaseSegment(Segment segment) {
    for (final obstacle in segment.obstacles) {
      obstacleFactory.release(obstacle);
    }
    segmentPool.release(segment);
  }

  /// [protectedY] is the oldest world position still reachable by a rewind;
  /// nothing at or above it may be recycled.
  void update({
    required double flowPosition,
    required double visibleHeight,
    required DifficultySnapshot difficulty,
    required double protectedY,
  }) {
    final generateUntil = flowPosition + visibleHeight * cfg.lookaheadScreens;
    var guard = 0;
    while (_nextStartY < generateUntil && guard < 32) {
      final segment = generator.generate(
        segmentPool.obtain(),
        _nextIndex,
        _nextStartY,
        difficulty,
      );
      active.add(segment);
      _nextIndex++;
      _nextStartY = segment.endY;
      guard++;
    }

    final recycleBelow = math.min(
      flowPosition - visibleHeight * cfg.trailingScreens,
      protectedY - visibleHeight * 0.5,
    );
    while (active.isNotEmpty && active.first.endY < recycleBelow) {
      _releaseSegment(active.removeAt(0));
    }
  }

  /// Visits every obstacle overlapping the vertical range, in world order.
  void forEachObstacleInRange(
    double fromY,
    double toY,
    void Function(Segment segment, Obstacle obstacle) visit,
  ) {
    for (final segment in active) {
      if (segment.endY < fromY || segment.startY > toY) continue;
      for (final obstacle in segment.obstacles) {
        if (obstacle.influenceEnd < fromY || obstacle.influenceStart > toY) {
          continue;
        }
        visit(segment, obstacle);
      }
    }
  }

  void forEachObstacle(void Function(Segment segment, Obstacle obstacle) visit) {
    for (final segment in active) {
      for (final obstacle in segment.obstacles) {
        visit(segment, obstacle);
      }
    }
  }

  Segment? segmentContaining(double y) {
    for (final segment in active) {
      if (segment.contains(y)) return segment;
    }
    return null;
  }

  /// Debug tool: drops everything ahead and regenerates from [fromY].
  void regenerateAhead(double fromY, DifficultySnapshot difficulty) {
    while (active.isNotEmpty && active.last.startY >= fromY) {
      _releaseSegment(active.removeLast());
    }
    _nextIndex = active.isEmpty ? 0 : active.last.index + 1;
    _nextStartY = active.isEmpty ? fromY : active.last.endY;
  }
}
