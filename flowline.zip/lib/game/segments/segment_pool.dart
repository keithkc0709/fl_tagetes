import 'segment.dart';

/// Trivial free-list for [Segment] shells.
class SegmentPool {
  final List<Segment> _free = <Segment>[];
  int _created = 0;

  int get pooledCount => _free.length;
  int get createdCount => _created;

  Segment obtain() {
    if (_free.isNotEmpty) return _free.removeLast();
    _created++;
    return Segment();
  }

  void release(Segment segment) {
    segment.reset();
    _free.add(segment);
  }

  void prewarm(int count) {
    while (_free.length < count) {
      _created++;
      _free.add(Segment());
    }
  }
}
