import '../../core/game_balance_config.dart';
import '../../core/math_utils.dart';

/// Accumulates raw pointer deltas and produces a smoothed forward-positive
/// velocity plus a per-frame displacement.
///
/// Kept separate from [TimeController] so that gesture handling can be unit
/// tested and replayed without a Flutter widget tree.
class ScrollTracker {
  final GameBalanceConfig cfg;

  ScrollTracker(this.cfg);

  double _pendingDelta = 0.0;
  double _inertialVelocity = 0.0;
  bool _pointerDown = false;

  /// Smoothed velocity in logical px/s. Positive = forward (dragging upward).
  double smoothedVelocity = 0.0;

  /// Displacement applied during the most recent [consume], in logical px.
  double lastDisplacement = 0.0;

  bool get pointerDown => _pointerDown;
  double get inertialVelocity => _inertialVelocity;

  void onPointerDown() {
    _pointerDown = true;
    _inertialVelocity = 0.0;
    _pendingDelta = 0.0;
  }

  /// [forwardDelta] is already sign-corrected: positive means the thumb moved
  /// up the screen (which is "forward" in a feed).
  void onPointerMove(double forwardDelta) {
    _pendingDelta += forwardDelta;
  }

  void onPointerUp(double forwardFlingVelocity) {
    _pointerDown = false;
    _pendingDelta = 0.0;
    _inertialVelocity = clampd(
      forwardFlingVelocity,
      -cfg.maxFlingVelocity,
      cfg.maxFlingVelocity,
    );
  }

  void onPointerCancel() => onPointerUp(0.0);

  /// Advances the tracker by [dt] real seconds and returns the displacement to
  /// apply this frame.
  double consume(double dt) {
    double rawVelocity;
    double displacement;

    if (_pointerDown) {
      // While the thumb is on glass, displacement is 1:1 with the gesture.
      // Anything else introduces perceptible lag.
      displacement = _pendingDelta;
      rawVelocity = dt > 1e-5 ? _pendingDelta / dt : smoothedVelocity;
      _pendingDelta = 0.0;
    } else {
      _inertialVelocity *= _decayFactor(dt);
      if (_inertialVelocity.abs() < cfg.flingCutoff) _inertialVelocity = 0.0;
      displacement = _inertialVelocity * dt;
      rawVelocity = _inertialVelocity;
    }

    smoothedVelocity =
        approach(smoothedVelocity, rawVelocity, cfg.velocitySmoothing, dt);
    lastDisplacement = displacement;
    return displacement;
  }

  double _decayFactor(double dt) {
    // exp(-k*dt) without importing dart:math at the call site.
    return approach(1.0, 0.0, cfg.flingDecay, dt);
  }

  void reset() {
    _pendingDelta = 0.0;
    _inertialVelocity = 0.0;
    _pointerDown = false;
    smoothedVelocity = 0.0;
    lastDisplacement = 0.0;
  }
}
