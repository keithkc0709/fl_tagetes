import 'dart:math' as math;

import '../../core/game_balance_config.dart';
import '../../core/math_utils.dart';
import 'scroll_input.dart';

enum TimeFlowState { frozen, forward, rewinding, autoRewinding }

/// The heart of FLOWLINE.
///
/// ## Two clocks, one thumb
///
/// The controller maintains two independently advanced quantities:
///
/// * [gameTime] — drives every obstacle mechanism. Advanced by
///   `actualTimeScale * realDt`, where `actualTimeScale` is a *smoothed,
///   clamped, non-linear* function of scroll **velocity**.
/// * [flowPosition] — the Spark's progress along the world, in world units.
///   Advanced directly by scroll **displacement**.
///
/// Both freeze together when the thumb stops and both reverse together on a
/// downward drag, so the player experiences a single unified "time" they are
/// dragging. But because velocity→timeScale is clamped and smoothed while
/// displacement→position is linear, the *ratio* between them is under player
/// control. That ratio is the entire game: a slow controlled drag lets a gate
/// cycle several times while you barely advance; a flick shoots you through
/// before the gate can close.
///
/// This distinction matters. If the Spark's position were also a pure function
/// of `gameTime`, a uniform time scale would scale the player and the obstacles
/// equally, every outcome would be predetermined at segment entry, and no
/// amount of scrolling could change it. The two-clock model is what makes the
/// mechanic an actual game rather than a scrubber over a fixed animation.
class TimeController {
  final GameBalanceConfig cfg;
  final ScrollTracker tracker;

  TimeController(this.cfg) : tracker = ScrollTracker(cfg);

  // ------------------------------------------------------------------ state
  double gameTime = 0.0;
  double flowPosition = 0.0;

  /// Furthest point ever reached. Rewind can never go past
  /// `maxGameTime - cfg.maxRewindSeconds`.
  double maxGameTime = 0.0;
  double maxFlowPosition = 0.0;

  double targetTimeScale = 0.0;
  double actualTimeScale = 0.0;

  /// Game-seconds advanced during the most recent [update].
  double lastGameDelta = 0.0;

  TimeFlowState state = TimeFlowState.frozen;

  double? _autoRewindTarget;

  double get scrollVelocity => tracker.smoothedVelocity;
  bool get isFrozen =>
      state == TimeFlowState.frozen ||
      (actualTimeScale.abs() < cfg.freezeEpsilon && !isRewinding);
  bool get isRewinding =>
      state == TimeFlowState.rewinding || state == TimeFlowState.autoRewinding;
  bool get isAutoRewinding => state == TimeFlowState.autoRewinding;

  /// Oldest game-time the player is allowed to scrub back to.
  double get rewindFloor => math.max(0.0, maxGameTime - cfg.maxRewindSeconds);

  /// Seconds of history currently available behind the playhead.
  double get availableRewindSeconds => gameTime - rewindFloor;

  // ------------------------------------------------------------------ input
  void onPointerDown() {
    tracker.onPointerDown();
  }

  void onPointerMove(double forwardDelta) {
    tracker.onPointerMove(forwardDelta);
  }

  void onPointerUp(double forwardFlingVelocity) {
    tracker.onPointerUp(forwardFlingVelocity);
  }

  void onPointerCancel() => tracker.onPointerCancel();

  /// Scripted rewind used by the failure system. Overrides gesture input until
  /// it completes, so a collision always resolves even if the thumb is still.
  void requestAutoRewind(double seconds) {
    final target = math.max(rewindFloor, gameTime - seconds);
    _autoRewindTarget = target;
    state = TimeFlowState.autoRewinding;
    tracker.onPointerCancel();
  }

  void cancelAutoRewind() {
    _autoRewindTarget = null;
    if (state == TimeFlowState.autoRewinding) state = TimeFlowState.frozen;
  }

  // ----------------------------------------------------------------- update
  void update(double rawRealDt) {
    final dt = clampd(rawRealDt, 0.0, cfg.maxRealDelta);
    final previousGameTime = gameTime;

    // The tracker is always consumed, even while a scripted rewind owns the
    // clock. Letting gesture deltas queue up during an auto-rewind would make
    // the simulation lurch forward the instant it finished.
    final displacement = tracker.consume(dt);
    final velocity = tracker.smoothedVelocity;

    if (_autoRewindTarget != null) {
      _updateAutoRewind(dt);
    } else if (velocity < -cfg.rewindActivationSpeed &&
        availableRewindSeconds > 0) {
      _updateRewind(dt, -velocity);
    } else {
      _updateForward(dt, velocity, displacement);
    }

    lastGameDelta = gameTime - previousGameTime;
    if (gameTime > maxGameTime) maxGameTime = gameTime;
    if (flowPosition > maxFlowPosition) maxFlowPosition = flowPosition;
  }

  void _updateForward(double dt, double velocity, double displacement) {
    targetTimeScale = _timeScaleForSpeed(math.max(velocity, 0.0));

    final rate =
        targetTimeScale > actualTimeScale ? cfg.timeAccelRate : cfg.timeDecelRate;
    actualTimeScale = approach(actualTimeScale, targetTimeScale, rate, dt);
    if (actualTimeScale.abs() < cfg.freezeEpsilon) actualTimeScale = 0.0;

    gameTime += actualTimeScale * dt;
    if (displacement > 0) flowPosition += displacement * cfg.scrollSensitivity;

    state = actualTimeScale <= 0.0 ? TimeFlowState.frozen : TimeFlowState.forward;
  }

  void _updateRewind(double dt, double downwardSpeed) {
    final rate = clampd(
      downwardSpeed * cfg.rewindSensitivity,
      0.0,
      cfg.maxRewindRate,
    );
    targetTimeScale = -rate;
    actualTimeScale = approach(actualTimeScale, -rate, cfg.timeAccelRate, dt);

    gameTime = math.max(rewindFloor, gameTime + actualTimeScale * dt);
    state = TimeFlowState.rewinding;
  }

  void _updateAutoRewind(double dt) {
    final target = _autoRewindTarget!;
    targetTimeScale = -cfg.autoRewindRate;
    actualTimeScale = -cfg.autoRewindRate;
    gameTime = math.max(target, gameTime - cfg.autoRewindRate * dt);

    if (gameTime <= target + 1e-6) {
      gameTime = target;
      _autoRewindTarget = null;
      actualTimeScale = 0.0;
      targetTimeScale = 0.0;
      state = TimeFlowState.frozen;
    } else {
      state = TimeFlowState.autoRewinding;
    }
  }

  /// Non-linear mapping from scroll speed to simulation speed.
  ///
  /// Below the dead zone the simulation freezes outright — this is what makes
  /// "stop to think" a first-class verb. Above it, speed is normalised against
  /// [GameBalanceConfig.referenceScrollSpeed], curved, and clamped. The upper
  /// clamp is lower for ordinary scrolls than for deliberate flicks, so the
  /// 2-4x range has to be *earned* and cannot be reached by accident.
  double _timeScaleForSpeed(double speed) {
    if (speed <= cfg.deadZoneSpeed) return 0.0;
    final normalised = speed / cfg.referenceScrollSpeed;
    final curved = math.pow(normalised, cfg.speedCurveExponent).toDouble();
    final ceiling = speed >= cfg.flickThresholdSpeed
        ? cfg.maxForwardTimeScale
        : cfg.normalMaxTimeScale;
    return clampd(curved, cfg.minForwardTimeScale, ceiling);
  }

  /// Used by the rewind buffer to snap [flowPosition] onto the recorded path.
  void setFlowPosition(double value) => flowPosition = value;

  void reset() {
    gameTime = 0.0;
    flowPosition = 0.0;
    maxGameTime = 0.0;
    maxFlowPosition = 0.0;
    targetTimeScale = 0.0;
    actualTimeScale = 0.0;
    lastGameDelta = 0.0;
    _autoRewindTarget = null;
    state = TimeFlowState.frozen;
    tracker.reset();
  }
}
