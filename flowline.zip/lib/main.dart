import 'package:flutter/services.dart';
import 'package:flutter/widgets.dart';

import 'app.dart';

/// Entry point.
///
/// Orientation and system UI are locked before the first frame so the game
/// never renders a landscape layout it does not support, and gameplay is on
/// screen as soon as the widget tree is built — there is no splash, no lobby
/// and no loading step between launch and control.
Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  await SystemChrome.setPreferredOrientations(<DeviceOrientation>[
    DeviceOrientation.portraitUp,
    DeviceOrientation.portraitDown,
  ]);

  await SystemChrome.setEnabledSystemUIMode(
    SystemUiMode.edgeToEdge,
    overlays: <SystemUiOverlay>[],
  );

  SystemChrome.setSystemUIOverlayStyle(
    const SystemUiOverlayStyle(
      statusBarColor: Color(0x00000000),
      systemNavigationBarColor: Color(0x00000000),
      statusBarIconBrightness: Brightness.light,
      statusBarBrightness: Brightness.dark,
    ),
  );

  runApp(FlowlineApp.production());
}
