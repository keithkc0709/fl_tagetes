enum GameMode {
  flow,
  sixty,
  zen;

  String get id => name;

  static GameMode fromId(String? id) => GameMode.values.firstWhere(
        (m) => m.id == id,
        orElse: () => GameMode.flow,
      );
}
