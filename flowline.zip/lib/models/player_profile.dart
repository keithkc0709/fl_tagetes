import 'package:flutter/foundation.dart';

import '../settings/settings_model.dart';

@immutable
class PlayerProfile {
  /// Locally generated, non-identifying install ID. Never a device identifier.
  final String installationId;
  final int highScore;
  final double longestDistance;
  final int bestCombo;
  final int totalSessions;
  final int totalPerfects;
  final int totalRuns;
  final double totalPlaySeconds;
  final List<String> unlockedThemes;
  final GameSettings settings;
  final bool tutorialComplete;
  final double skillScore;
  final String? lastDailyDate;
  final int lastDailyScore;

  const PlayerProfile({
    required this.installationId,
    this.highScore = 0,
    this.longestDistance = 0,
    this.bestCombo = 0,
    this.totalSessions = 0,
    this.totalPerfects = 0,
    this.totalRuns = 0,
    this.totalPlaySeconds = 0,
    this.unlockedThemes = const ['minimal', 'glass', 'neon'],
    this.settings = const GameSettings(),
    this.tutorialComplete = false,
    this.skillScore = 0.35,
    this.lastDailyDate,
    this.lastDailyScore = 0,
  });

  PlayerProfile copyWith({
    String? installationId,
    int? highScore,
    double? longestDistance,
    int? bestCombo,
    int? totalSessions,
    int? totalPerfects,
    int? totalRuns,
    double? totalPlaySeconds,
    List<String>? unlockedThemes,
    GameSettings? settings,
    bool? tutorialComplete,
    double? skillScore,
    String? lastDailyDate,
    int? lastDailyScore,
  }) {
    return PlayerProfile(
      installationId: installationId ?? this.installationId,
      highScore: highScore ?? this.highScore,
      longestDistance: longestDistance ?? this.longestDistance,
      bestCombo: bestCombo ?? this.bestCombo,
      totalSessions: totalSessions ?? this.totalSessions,
      totalPerfects: totalPerfects ?? this.totalPerfects,
      totalRuns: totalRuns ?? this.totalRuns,
      totalPlaySeconds: totalPlaySeconds ?? this.totalPlaySeconds,
      unlockedThemes: unlockedThemes ?? this.unlockedThemes,
      settings: settings ?? this.settings,
      tutorialComplete: tutorialComplete ?? this.tutorialComplete,
      skillScore: skillScore ?? this.skillScore,
      lastDailyDate: lastDailyDate ?? this.lastDailyDate,
      lastDailyScore: lastDailyScore ?? this.lastDailyScore,
    );
  }

  Map<String, Object?> toJson() => {
        'installationId': installationId,
        'highScore': highScore,
        'longestDistance': longestDistance,
        'bestCombo': bestCombo,
        'totalSessions': totalSessions,
        'totalPerfects': totalPerfects,
        'totalRuns': totalRuns,
        'totalPlaySeconds': totalPlaySeconds,
        'unlockedThemes': unlockedThemes,
        'settings': settings.toJson(),
        'tutorialComplete': tutorialComplete,
        'skillScore': skillScore,
        'lastDailyDate': lastDailyDate,
        'lastDailyScore': lastDailyScore,
      };

  static PlayerProfile fromJson(Map<String, Object?> json) => PlayerProfile(
        installationId: json['installationId'] as String? ?? 'unknown',
        highScore: (json['highScore'] as num?)?.toInt() ?? 0,
        longestDistance: (json['longestDistance'] as num?)?.toDouble() ?? 0,
        bestCombo: (json['bestCombo'] as num?)?.toInt() ?? 0,
        totalSessions: (json['totalSessions'] as num?)?.toInt() ?? 0,
        totalPerfects: (json['totalPerfects'] as num?)?.toInt() ?? 0,
        totalRuns: (json['totalRuns'] as num?)?.toInt() ?? 0,
        totalPlaySeconds: (json['totalPlaySeconds'] as num?)?.toDouble() ?? 0,
        unlockedThemes:
            (json['unlockedThemes'] as List?)?.cast<String>() ??
                const ['minimal', 'glass', 'neon'],
        settings: GameSettings.fromJson(
            (json['settings'] as Map?)?.cast<String, Object?>() ?? const {}),
        tutorialComplete: json['tutorialComplete'] as bool? ?? false,
        skillScore: (json['skillScore'] as num?)?.toDouble() ?? 0.35,
        lastDailyDate: json['lastDailyDate'] as String?,
        lastDailyScore: (json['lastDailyScore'] as num?)?.toInt() ?? 0,
      );
}
