import 'package:flutter/foundation.dart';

import 'game_mode.dart';

/// A single recorded gesture sample. A run is fully reproducible from
/// `(version, seed, mode, inputs)` because every system downstream of input is
/// deterministic and driven by clamped real delta-time.
@immutable
class ReplayInput {
  /// Seconds since run start.
  final double t;

  /// Forward-positive drag delta in logical pixels for this frame.
  final double delta;

  /// Whether the pointer was down during this sample.
  final bool pointerDown;

  const ReplayInput(this.t, this.delta, this.pointerDown);

  List<Object?> toJson() => [t, delta, pointerDown];

  static ReplayInput fromJson(List<Object?> json) => ReplayInput(
        (json[0] as num).toDouble(),
        (json[1] as num).toDouble(),
        json[2] as bool,
      );
}

@immutable
class Replay {
  final String gameVersion;
  final GameMode mode;
  final int seed;
  final List<ReplayInput> inputs;
  final int finalScore;

  const Replay({
    required this.gameVersion,
    required this.mode,
    required this.seed,
    required this.inputs,
    required this.finalScore,
  });

  Map<String, Object?> toJson() => {
        'gameVersion': gameVersion,
        'mode': mode.id,
        'seed': seed,
        'finalScore': finalScore,
        'inputs': inputs.map((i) => i.toJson()).toList(growable: false),
      };

  static Replay fromJson(Map<String, Object?> json) => Replay(
        gameVersion: json['gameVersion'] as String? ?? '0',
        mode: GameMode.fromId(json['mode'] as String?),
        seed: (json['seed'] as num?)?.toInt() ?? 0,
        finalScore: (json['finalScore'] as num?)?.toInt() ?? 0,
        inputs: ((json['inputs'] as List?) ?? const [])
            .map((e) => ReplayInput.fromJson((e as List).cast<Object?>()))
            .toList(growable: false),
      );
}

/// Recording is behind a feature flag; the recorder exists so the data shape is
/// fixed now, but nothing in the gameplay loop depends on it.
class ReplayRecorder {
  final List<ReplayInput> _inputs = <ReplayInput>[];
  bool enabled = false;

  void record(double t, double delta, bool pointerDown) {
    if (!enabled) return;
    _inputs.add(ReplayInput(t, delta, pointerDown));
  }

  void clear() => _inputs.clear();

  Replay build({
    required String gameVersion,
    required GameMode mode,
    required int seed,
    required int finalScore,
  }) {
    return Replay(
      gameVersion: gameVersion,
      mode: mode,
      seed: seed,
      inputs: List<ReplayInput>.unmodifiable(_inputs),
      finalScore: finalScore,
    );
  }
}
