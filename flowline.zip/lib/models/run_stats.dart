import 'package:flutter/foundation.dart';

import 'game_mode.dart';

@immutable
class RunStats {
  final GameMode mode;
  final int seed;
  final int score;
  final int bestCombo;
  final int perfectCount;
  final int goodCount;
  final int passCount;
  final int failCount;
  final double distance;
  final double durationSeconds;
  final int skillTier;

  const RunStats({
    required this.mode,
    required this.seed,
    this.score = 0,
    this.bestCombo = 0,
    this.perfectCount = 0,
    this.goodCount = 0,
    this.passCount = 0,
    this.failCount = 0,
    this.distance = 0,
    this.durationSeconds = 0,
    this.skillTier = 0,
  });

  Map<String, Object?> toJson() => {
        'mode': mode.id,
        'seed': seed,
        'score': score,
        'bestCombo': bestCombo,
        'perfectCount': perfectCount,
        'goodCount': goodCount,
        'passCount': passCount,
        'failCount': failCount,
        'distance': distance,
        'durationSeconds': durationSeconds,
        'skillTier': skillTier,
      };

  static RunStats fromJson(Map<String, Object?> json) => RunStats(
        mode: GameMode.fromId(json['mode'] as String?),
        seed: (json['seed'] as num?)?.toInt() ?? 0,
        score: (json['score'] as num?)?.toInt() ?? 0,
        bestCombo: (json['bestCombo'] as num?)?.toInt() ?? 0,
        perfectCount: (json['perfectCount'] as num?)?.toInt() ?? 0,
        goodCount: (json['goodCount'] as num?)?.toInt() ?? 0,
        passCount: (json['passCount'] as num?)?.toInt() ?? 0,
        failCount: (json['failCount'] as num?)?.toInt() ?? 0,
        distance: (json['distance'] as num?)?.toDouble() ?? 0,
        durationSeconds: (json['durationSeconds'] as num?)?.toDouble() ?? 0,
        skillTier: (json['skillTier'] as num?)?.toInt() ?? 0,
      );
}
