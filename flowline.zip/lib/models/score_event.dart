import 'package:flutter/foundation.dart';

import '../game/obstacles/obstacle_family.dart';

enum Grade { perfect, good, pass, fail }

extension GradeInfo on Grade {
  String get id => name;
  bool get isSuccess => this != Grade.fail;
}

@immutable
class ScoreEvent {
  final Grade grade;
  final ObstacleFamily family;
  final int points;
  final int comboAfter;
  final double precision;
  final double gameTime;

  const ScoreEvent({
    required this.grade,
    required this.family,
    required this.points,
    required this.comboAfter,
    required this.precision,
    required this.gameTime,
  });
}
