import 'dart:ui';

import '../core/design_tokens.dart';
import '../settings/settings_model.dart';
import '../themes/game_theme.dart';

/// Shared drawing state handed to every renderable.
///
/// Paint objects are owned by the context and mutated in place. Allocating a
/// `Paint` per obstacle per frame is the single easiest way to lose 60 FPS on a
/// mid-range Android device, so nothing downstream is permitted to construct
/// one during a frame.
class RenderContext {
  late Canvas canvas;
  late Size size;
  late GameTheme theme;
  late GameSettings settings;

  /// Pixels per world unit.
  double scale = 1.0;

  /// World Y currently drawn at the bottom edge of the screen.
  double camBottom = 0.0;

  /// Visible world height in world units.
  double visibleHeight = 0.0;

  /// Effective bloom after accessibility settings.
  double glow = 0.0;

  final Paint fill = Paint()..isAntiAlias = true;
  final Paint stroke = Paint()
    ..isAntiAlias = true
    ..style = PaintingStyle.stroke
    ..strokeCap = StrokeCap.round
    ..strokeJoin = StrokeJoin.round;
  final Paint bloom = Paint()..isAntiAlias = true;

  void begin({
    required Canvas canvas,
    required Size size,
    required GameTheme theme,
    required GameSettings settings,
    required double camBottom,
    required double visibleHeight,
  }) {
    this.canvas = canvas;
    this.size = size;
    this.theme = settings.highContrast ? theme.toHighContrast() : theme;
    this.settings = settings;
    this.camBottom = camBottom;
    this.visibleHeight = visibleHeight;
    scale = size.width / WorldMetrics.width;
    glow = settings.reducedMotion
        ? this.theme.glowStrength * 0.35
        : this.theme.glowStrength;
  }

  double sx(double worldX) => worldX * scale;

  double sy(double worldY) => size.height - (worldY - camBottom) * scale;

  double sl(double worldLength) => worldLength * scale;

  Offset sp(double worldX, double worldY) => Offset(sx(worldX), sy(worldY));

  bool isVisible(double worldYStart, double worldYEnd) {
    return worldYEnd >= camBottom - 12.0 &&
        worldYStart <= camBottom + visibleHeight + 12.0;
  }

  /// Soft additive halo. Skipped entirely when bloom is off, which keeps the
  /// high-contrast and reduced-motion paths cheap as well as legible.
  void drawGlow(double worldX, double worldY, double worldRadius, Color color,
      {double intensity = 1.0}) {
    final effective = glow * intensity;
    if (effective <= 0.01) return;
    bloom
      ..color = color.withOpacity((0.28 * effective).clamp(0.0, 1.0))
      ..maskFilter = MaskFilter.blur(
        BlurStyle.normal,
        sl(worldRadius) * 0.55 + 2.0,
      );
    canvas.drawCircle(sp(worldX, worldY), sl(worldRadius), bloom);
    bloom.maskFilter = null;
  }
}
