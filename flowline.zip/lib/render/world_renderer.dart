import 'dart:math' as math;
import 'dart:ui' as ui;

import 'package:flutter/rendering.dart';

import '../core/design_tokens.dart';
import '../core/math_utils.dart';
import '../game/flowline_game.dart';
import '../game/time/time_controller.dart';
import 'render_context.dart';

/// Paints the world.
///
/// Repaints are driven by `game.frame`, not by widget rebuilds, so a frame
/// costs one `paint` call and zero element-tree work.
class WorldPainter extends CustomPainter {
  final FlowlineGame game;

  final RenderContext _ctx = RenderContext();
  Paint? _backgroundPaint;
  Size _backgroundSize = Size.zero;
  Color _backgroundKey = const Color(0x00000000);

  WorldPainter(this.game) : super(repaint: game.frame);

  @override
  void paint(Canvas canvas, Size size) {
    final visibleHeight = worldVisibleHeightFor(size.width, size.height);
    game.visibleHeight = visibleHeight;

    final camBottom =
        game.spark.y - visibleHeight * WorldMetrics.sparkScreenAnchor;

    _ctx.begin(
      canvas: canvas,
      size: size,
      theme: game.theme,
      settings: game.settings,
      camBottom: camBottom,
      visibleHeight: visibleHeight,
    );

    _paintBackground(canvas, size);

    canvas.save();
    canvas.translate(game.effects.shake.offsetX, game.effects.shake.offsetY);

    _paintRails();
    _paintObstacles();
    game.effects.render(_ctx);
    game.spark.render(_ctx);

    canvas.restore();

    _paintTimeStateOverlay(canvas, size);
  }

  void _paintBackground(Canvas canvas, Size size) {
    final theme = _ctx.theme;
    if (_backgroundPaint == null ||
        _backgroundSize != size ||
        _backgroundKey != theme.backgroundTop) {
      _backgroundSize = size;
      _backgroundKey = theme.backgroundTop;
      _backgroundPaint = Paint()
        ..shader = ui.Gradient.linear(
          Offset(0, 0),
          Offset(0, size.height),
          <Color>[theme.backgroundTop, theme.backgroundBottom],
        );
    }
    canvas.drawRect(Offset.zero & size, _backgroundPaint!);
  }

  /// Faint side rails plus world-locked tick marks. The ticks are the only
  /// element that conveys raw scroll displacement, which keeps the sense of
  /// "I am dragging the world" alive even when every mechanism is frozen.
  void _paintRails() {
    final theme = _ctx.theme;
    final opacity = theme.railOpacity;
    if (opacity <= 0.001) return;

    _ctx.stroke
      ..color = theme.hudForeground.withOpacity(opacity)
      ..strokeWidth = 1.0;

    _ctx.canvas.drawLine(
      Offset(_ctx.sx(4), 0),
      Offset(_ctx.sx(4), _ctx.size.height),
      _ctx.stroke,
    );
    _ctx.canvas.drawLine(
      Offset(_ctx.sx(WorldMetrics.width - 4), 0),
      Offset(_ctx.sx(WorldMetrics.width - 4), _ctx.size.height),
      _ctx.stroke,
    );

    const tickSpacing = 20.0;
    final firstTick =
        (_ctx.camBottom / tickSpacing).floorToDouble() * tickSpacing;
    for (var y = firstTick;
        y < _ctx.camBottom + _ctx.visibleHeight + tickSpacing;
        y += tickSpacing) {
      final sy = _ctx.sy(y);
      _ctx.canvas.drawLine(
        Offset(_ctx.sx(4), sy),
        Offset(_ctx.sx(7.5), sy),
        _ctx.stroke,
      );
      _ctx.canvas.drawLine(
        Offset(_ctx.sx(WorldMetrics.width - 7.5), sy),
        Offset(_ctx.sx(WorldMetrics.width - 4), sy),
        _ctx.stroke,
      );
    }
  }

  void _paintObstacles() {
    final gameTime = game.time.gameTime;
    final low = _ctx.camBottom - 20.0;
    final high = _ctx.camBottom + _ctx.visibleHeight + 20.0;

    game.segments.forEachObstacleInRange(low, high, (segment, obstacle) {
      obstacle.render(_ctx, gameTime);
      if (game.flags.enableDebugPanel && game.debugShowCollision) {
        obstacle.renderDebug(_ctx, gameTime);
      }
    });
  }

  /// Rewind and freeze are communicated through the frame itself rather than
  /// with words: horizontal scan bands while reversing, a still vignette while
  /// frozen.
  void _paintTimeStateOverlay(Canvas canvas, Size size) {
    final theme = _ctx.theme;

    if (game.time.isRewinding) {
      final intensity = clampd(
        (-game.time.actualTimeScale) / math.max(game.cfg.maxRewindRate, 0.01),
        0.0,
        1.0,
      );
      _ctx.fill.color = theme.accent.withOpacity(0.05 + 0.05 * intensity);
      canvas.drawRect(Offset.zero & size, _ctx.fill);

      if (!game.settings.reducedMotion) {
        _ctx.stroke
          ..color = theme.accent.withOpacity(0.08 + 0.10 * intensity)
          ..strokeWidth = 1.0;
        final offset = (game.time.gameTime * 240.0) % 8.0;
        for (var y = -offset; y < size.height; y += 8.0) {
          canvas.drawLine(Offset(0, y), Offset(size.width, y), _ctx.stroke);
        }
      }
      return;
    }

    if (game.time.state == TimeFlowState.frozen && game.hasInteracted) {
      _ctx.stroke
        ..color = theme.hudForeground.withOpacity(0.10)
        ..strokeWidth = 1.0;
      final y = _ctx.sy(game.spark.y);
      canvas.drawLine(Offset(0, y), Offset(_ctx.sx(38), y), _ctx.stroke);
      canvas.drawLine(
        Offset(_ctx.sx(WorldMetrics.width - 38), y),
        Offset(size.width, y),
        _ctx.stroke,
      );
    }
  }

  @override
  bool shouldRepaint(covariant WorldPainter oldDelegate) => false;
}
