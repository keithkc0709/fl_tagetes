import 'dart:convert';

import 'package:shared_preferences/shared_preferences.dart';

import '../core/deterministic_random.dart';
import '../models/player_profile.dart';

/// Storage abstraction for the single locally persisted document.
///
/// No account, no sign-in, no server. The only identifier is a random string
/// generated on first launch, which exists solely so local analytics can group
/// events from one install.
abstract class ProfileRepository {
  Future<PlayerProfile> load();
  Future<void> save(PlayerProfile profile);
  Future<void> clear();
}

String generateInstallationId() {
  final rng = DeterministicRandom(DateTime.now().microsecondsSinceEpoch);
  const alphabet = 'abcdefghijklmnopqrstuvwxyz0123456789';
  final buffer = StringBuffer();
  for (var i = 0; i < 16; i++) {
    buffer.write(alphabet[rng.nextIntBelow(alphabet.length)]);
  }
  return buffer.toString();
}

class SharedPreferencesProfileRepository implements ProfileRepository {
  static const String storageKey = 'flowline.profile.v1';

  SharedPreferences? _prefs;

  Future<SharedPreferences> get _instance async =>
      _prefs ??= await SharedPreferences.getInstance();

  @override
  Future<PlayerProfile> load() async {
    final prefs = await _instance;
    final raw = prefs.getString(storageKey);
    if (raw == null) {
      final fresh = PlayerProfile(installationId: generateInstallationId());
      await save(fresh);
      return fresh;
    }
    try {
      final decoded = jsonDecode(raw);
      if (decoded is! Map) throw const FormatException('profile is not a map');
      return PlayerProfile.fromJson(decoded.cast<String, Object?>());
    } on FormatException {
      // A corrupt profile must never brick the app. Start clean instead.
      final fresh = PlayerProfile(installationId: generateInstallationId());
      await save(fresh);
      return fresh;
    }
  }

  @override
  Future<void> save(PlayerProfile profile) async {
    final prefs = await _instance;
    await prefs.setString(storageKey, jsonEncode(profile.toJson()));
  }

  @override
  Future<void> clear() async {
    final prefs = await _instance;
    await prefs.remove(storageKey);
  }
}

/// Used by tests and by the very first frame, before async storage resolves.
class InMemoryProfileRepository implements ProfileRepository {
  PlayerProfile? _profile;

  InMemoryProfileRepository([PlayerProfile? initial]) : _profile = initial;

  @override
  Future<PlayerProfile> load() async =>
      _profile ??= PlayerProfile(installationId: generateInstallationId());

  @override
  Future<void> save(PlayerProfile profile) async => _profile = profile;

  @override
  Future<void> clear() async => _profile = null;
}
