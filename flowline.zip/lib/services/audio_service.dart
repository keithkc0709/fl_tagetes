import 'dart:async';

import 'package:flutter/foundation.dart';

enum AudioCue {
  perfect,
  good,
  pass,
  collision,
  rewindStart,
  rewindLoop,
  rewindEnd,
  comboMilestone,
  menuOpen,
  menuSelect,
}

/// Audio abstraction.
///
/// The MVP ships a silent implementation so a clean checkout builds and runs
/// with zero third-party audio dependencies and zero binary assets. Swapping in
/// a real backend (`audioplayers`, `soloud`, or a platform channel) means
/// implementing this one interface — no gameplay code changes.
abstract class AudioService {
  Future<void> initialize();

  void play(AudioCue cue, {double volumeScale = 1.0});

  /// Rewind is pitched down continuously rather than played as a one-shot, so
  /// the audio tracks the player's thumb speed.
  void setRewindIntensity(double intensity);

  void startAmbient();

  void stopAmbient();

  void setSfxVolume(double volume);

  void setAmbientVolume(double volume);

  void setMuted(bool muted);

  Future<void> dispose();
}

/// Silent, allocation-free default. Logs in debug so cue wiring is verifiable
/// without shipping sound files.
class SilentAudioService implements AudioService {
  bool _muted = false;
  double _sfxVolume = 1.0;
  double _ambientVolume = 1.0;
  double rewindIntensity = 0.0;
  bool ambientPlaying = false;

  final List<AudioCue> playedCues = <AudioCue>[];

  @override
  Future<void> initialize() async {}

  @override
  void play(AudioCue cue, {double volumeScale = 1.0}) {
    if (_muted || _sfxVolume <= 0) return;
    playedCues.add(cue);
    if (playedCues.length > 64) playedCues.removeAt(0);
    assert(() {
      debugPrint('[audio] cue=${cue.name} vol=${_sfxVolume * volumeScale}');
      return true;
    }());
  }

  @override
  void setRewindIntensity(double intensity) => rewindIntensity = intensity;

  @override
  void startAmbient() => ambientPlaying = true;

  @override
  void stopAmbient() => ambientPlaying = false;

  @override
  void setSfxVolume(double volume) => _sfxVolume = volume;

  @override
  void setAmbientVolume(double volume) => _ambientVolume = volume;

  double get ambientVolume => _ambientVolume;

  @override
  void setMuted(bool muted) => _muted = muted;

  @override
  Future<void> dispose() async {}
}
