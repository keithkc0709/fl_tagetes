import 'package:flutter/services.dart';

enum HapticStrength { light, medium, heavy, selection }

/// Thin wrapper so haptics can be globally disabled and unit tested.
abstract class HapticService {
  bool get enabled;
  set enabled(bool value);
  void fire(HapticStrength strength);
}

class SystemHapticService implements HapticService {
  @override
  bool enabled;

  SystemHapticService({this.enabled = true});

  @override
  void fire(HapticStrength strength) {
    if (!enabled) return;
    switch (strength) {
      case HapticStrength.light:
        HapticFeedback.lightImpact();
      case HapticStrength.medium:
        HapticFeedback.mediumImpact();
      case HapticStrength.heavy:
        HapticFeedback.heavyImpact();
      case HapticStrength.selection:
        HapticFeedback.selectionClick();
    }
  }
}

class RecordingHapticService implements HapticService {
  @override
  bool enabled = true;

  final List<HapticStrength> fired = <HapticStrength>[];

  @override
  void fire(HapticStrength strength) {
    if (!enabled) return;
    fired.add(strength);
  }
}
