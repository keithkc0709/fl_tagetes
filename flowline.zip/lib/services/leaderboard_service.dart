import 'package:flutter/foundation.dart';

import '../models/game_mode.dart';

@immutable
class LeaderboardEntry {
  final String displayName;
  final int score;
  final int rank;
  final bool isLocalPlayer;

  const LeaderboardEntry({
    required this.displayName,
    required this.score,
    required this.rank,
    this.isLocalPlayer = false,
  });
}

/// Leaderboards are behind a feature flag for the MVP. The interface exists so
/// the daily-challenge UI can be built against it now and pointed at a backend
/// later without touching the UI.
abstract class LeaderboardService {
  Future<void> submit({
    required GameMode mode,
    required String boardId,
    required int score,
  });

  Future<List<LeaderboardEntry>> top({
    required GameMode mode,
    required String boardId,
    int limit = 20,
  });

  /// 0..100; null when unknown. Rendered as a placeholder until a backend
  /// exists, never as a fabricated number.
  Future<double?> percentileFor({
    required GameMode mode,
    required String boardId,
    required int score,
  });
}

/// Local-only implementation. Stores nothing off-device and invents nothing:
/// [percentileFor] returns null rather than a made-up placement.
class LocalLeaderboardService implements LeaderboardService {
  final Map<String, List<int>> _scores = <String, List<int>>{};

  String _key(GameMode mode, String boardId) => '${mode.id}:$boardId';

  @override
  Future<void> submit({
    required GameMode mode,
    required String boardId,
    required int score,
  }) async {
    final list = _scores.putIfAbsent(_key(mode, boardId), () => <int>[]);
    list.add(score);
    list.sort((a, b) => b.compareTo(a));
    if (list.length > 100) list.removeRange(100, list.length);
  }

  @override
  Future<List<LeaderboardEntry>> top({
    required GameMode mode,
    required String boardId,
    int limit = 20,
  }) async {
    final list = _scores[_key(mode, boardId)] ?? const <int>[];
    return <LeaderboardEntry>[
      for (var i = 0; i < list.length && i < limit; i++)
        LeaderboardEntry(
          displayName: 'YOU',
          score: list[i],
          rank: i + 1,
          isLocalPlayer: true,
        ),
    ];
  }

  @override
  Future<double?> percentileFor({
    required GameMode mode,
    required String boardId,
    required int score,
  }) async =>
      null;
}
