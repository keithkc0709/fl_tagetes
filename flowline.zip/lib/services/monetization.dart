import 'package:flutter/foundation.dart';

/// Monetization is architecture only in the MVP.
///
/// No ads interrupt gameplay, there are no loot boxes, no random paid rewards,
/// no energy and no wheels. These interfaces exist so that a future cosmetic
/// store can be added without reshaping the game loop, and they are wired to
/// disabled implementations behind feature flags.
enum RewardedAdResult { unavailable, dismissed, rewarded, failed }

abstract class RewardedAdService {
  bool get available;
  Future<void> preload();
  Future<RewardedAdResult> show({required String placement});
}

class DisabledRewardedAdService implements RewardedAdService {
  @override
  bool get available => false;

  @override
  Future<void> preload() async {}

  @override
  Future<RewardedAdResult> show({required String placement}) async =>
      RewardedAdResult.unavailable;
}

@immutable
class StoreProduct {
  final String id;
  final String title;
  final String description;
  final String displayPrice;

  const StoreProduct({
    required this.id,
    required this.title,
    required this.description,
    required this.displayPrice,
  });
}

enum PurchaseResult { unavailable, cancelled, purchased, restored, failed }

abstract class PurchaseService {
  bool get available;
  Future<List<StoreProduct>> products();
  Future<PurchaseResult> purchase(String productId);
  Future<PurchaseResult> restore();
  Future<Set<String>> ownedProductIds();
}

class DisabledPurchaseService implements PurchaseService {
  @override
  bool get available => false;

  @override
  Future<List<StoreProduct>> products() async => const <StoreProduct>[];

  @override
  Future<PurchaseResult> purchase(String productId) async =>
      PurchaseResult.unavailable;

  @override
  Future<PurchaseResult> restore() async => PurchaseResult.unavailable;

  @override
  Future<Set<String>> ownedProductIds() async => const <String>{};
}
