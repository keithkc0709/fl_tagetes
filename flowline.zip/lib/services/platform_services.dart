/// Apple Game Center / Google Play Games Services abstraction.
///
/// Sign-in is never mandatory: every mode is fully playable signed out, and the
/// MVP ships the no-op implementation.
abstract class PlatformGameServices {
  bool get signedIn;
  Future<bool> signIn();
  Future<void> submitScore({required String boardId, required int score});
  Future<void> unlockAchievement(String achievementId);
  Future<void> showLeaderboardUi(String boardId);
}

class NoopPlatformGameServices implements PlatformGameServices {
  @override
  bool get signedIn => false;

  @override
  Future<bool> signIn() async => false;

  @override
  Future<void> submitScore({required String boardId, required int score}) async {}

  @override
  Future<void> unlockAchievement(String achievementId) async {}

  @override
  Future<void> showLeaderboardUi(String boardId) async {}
}
