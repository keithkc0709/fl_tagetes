import 'package:flutter/foundation.dart';

@immutable
class GameSettings {
  final bool soundEnabled;
  final double sfxVolume;
  final double ambientVolume;
  final bool hapticsEnabled;
  final bool reducedMotion;
  final bool highContrast;
  final bool generousTolerances;
  final String themeId;

  const GameSettings({
    this.soundEnabled = true,
    this.sfxVolume = 0.8,
    this.ambientVolume = 0.4,
    this.hapticsEnabled = true,
    this.reducedMotion = false,
    this.highContrast = false,
    this.generousTolerances = false,
    this.themeId = 'minimal',
  });

  GameSettings copyWith({
    bool? soundEnabled,
    double? sfxVolume,
    double? ambientVolume,
    bool? hapticsEnabled,
    bool? reducedMotion,
    bool? highContrast,
    bool? generousTolerances,
    String? themeId,
  }) {
    return GameSettings(
      soundEnabled: soundEnabled ?? this.soundEnabled,
      sfxVolume: sfxVolume ?? this.sfxVolume,
      ambientVolume: ambientVolume ?? this.ambientVolume,
      hapticsEnabled: hapticsEnabled ?? this.hapticsEnabled,
      reducedMotion: reducedMotion ?? this.reducedMotion,
      highContrast: highContrast ?? this.highContrast,
      generousTolerances: generousTolerances ?? this.generousTolerances,
      themeId: themeId ?? this.themeId,
    );
  }

  Map<String, Object?> toJson() => {
        'soundEnabled': soundEnabled,
        'sfxVolume': sfxVolume,
        'ambientVolume': ambientVolume,
        'hapticsEnabled': hapticsEnabled,
        'reducedMotion': reducedMotion,
        'highContrast': highContrast,
        'generousTolerances': generousTolerances,
        'themeId': themeId,
      };

  static GameSettings fromJson(Map<String, Object?> json) => GameSettings(
        soundEnabled: json['soundEnabled'] as bool? ?? true,
        sfxVolume: (json['sfxVolume'] as num?)?.toDouble() ?? 0.8,
        ambientVolume: (json['ambientVolume'] as num?)?.toDouble() ?? 0.4,
        hapticsEnabled: json['hapticsEnabled'] as bool? ?? true,
        reducedMotion: json['reducedMotion'] as bool? ?? false,
        highContrast: json['highContrast'] as bool? ?? false,
        generousTolerances: json['generousTolerances'] as bool? ?? false,
        themeId: json['themeId'] as String? ?? 'minimal',
      );
}
