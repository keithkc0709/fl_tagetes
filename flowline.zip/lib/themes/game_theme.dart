import 'dart:ui';

import 'package:flutter/foundation.dart';

/// A theme controls presentation only. Gameplay geometry, hitboxes and timing
/// windows are identical across themes — readability is never traded for style.
@immutable
class GameTheme {
  final String id;
  final String displayName;

  final Color backgroundTop;
  final Color backgroundBottom;

  final Color hazardFill;
  final Color hazardEdge;

  /// Tint of the safe opening indicator.
  final Color safeGlow;

  final Color sparkCore;
  final Color sparkHalo;
  final Color accent;
  final Color particle;
  final Color hudForeground;

  /// 0 = flat, 1 = maximum bloom. Reduced-motion and high-contrast settings
  /// scale this down at render time.
  final double glowStrength;

  /// Opacity of the faint vertical rails that communicate motion.
  final double railOpacity;

  const GameTheme({
    required this.id,
    required this.displayName,
    required this.backgroundTop,
    required this.backgroundBottom,
    required this.hazardFill,
    required this.hazardEdge,
    required this.safeGlow,
    required this.sparkCore,
    required this.sparkHalo,
    required this.accent,
    required this.particle,
    required this.hudForeground,
    this.glowStrength = 0.6,
    this.railOpacity = 0.06,
  });

  /// High-contrast variant: opaque hazards, brighter edges, no bloom.
  GameTheme toHighContrast() => GameTheme(
        id: id,
        displayName: displayName,
        backgroundTop: const Color(0xFF000000),
        backgroundBottom: const Color(0xFF000000),
        hazardFill: const Color(0xFF3A3F47),
        hazardEdge: const Color(0xFFFFFFFF),
        safeGlow: const Color(0xFF00FF9C),
        sparkCore: const Color(0xFFFFFFFF),
        sparkHalo: const Color(0xFFFFFFFF),
        accent: const Color(0xFF00FF9C),
        particle: const Color(0xFFFFFFFF),
        hudForeground: const Color(0xFFFFFFFF),
        glowStrength: 0.0,
        railOpacity: 0.12,
      );
}
