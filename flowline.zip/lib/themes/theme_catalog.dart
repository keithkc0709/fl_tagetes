import 'dart:ui';

import 'game_theme.dart';

/// The three MVP themes.
///
/// To add a theme: define it here, add its id to the default unlock list in
/// `PlayerProfile`, and nothing else needs to change.
class ThemeCatalog {
  const ThemeCatalog._();

  static const GameTheme minimal = GameTheme(
    id: 'minimal',
    displayName: 'MINIMAL',
    backgroundTop: Color(0xFF0E1013),
    backgroundBottom: Color(0xFF15191F),
    hazardFill: Color(0xFF262C34),
    hazardEdge: Color(0xFF525C69),
    safeGlow: Color(0xFF7DD3FC),
    sparkCore: Color(0xFFFFFFFF),
    sparkHalo: Color(0xFFBFE9FF),
    accent: Color(0xFF7DD3FC),
    particle: Color(0xFFD6F1FF),
    hudForeground: Color(0xFFE6EAF0),
    glowStrength: 0.45,
    railOpacity: 0.05,
  );

  static const GameTheme glass = GameTheme(
    id: 'glass',
    displayName: 'GLASS',
    backgroundTop: Color(0xFF0C1420),
    backgroundBottom: Color(0xFF16283A),
    hazardFill: Color(0x2EDCF3FF),
    hazardEdge: Color(0xB3CDEBFF),
    safeGlow: Color(0xFFA5F3FC),
    sparkCore: Color(0xFFF2FBFF),
    sparkHalo: Color(0xFF9BE7FF),
    accent: Color(0xFFA5F3FC),
    particle: Color(0xFFE4F8FF),
    hudForeground: Color(0xFFEAF6FF),
    glowStrength: 0.7,
    railOpacity: 0.09,
  );

  static const GameTheme neon = GameTheme(
    id: 'neon',
    displayName: 'NEON',
    backgroundTop: Color(0xFF04050A),
    backgroundBottom: Color(0xFF0B0718),
    hazardFill: Color(0xFF16091F),
    hazardEdge: Color(0xFFFF2D95),
    safeGlow: Color(0xFF00E5FF),
    sparkCore: Color(0xFFFFF7C2),
    sparkHalo: Color(0xFFFFC24D),
    accent: Color(0xFF00E5FF),
    particle: Color(0xFFFF7AC4),
    hudForeground: Color(0xFFF3E9FF),
    glowStrength: 1.0,
    railOpacity: 0.12,
  );

  static const List<GameTheme> all = <GameTheme>[minimal, glass, neon];

  static GameTheme byId(String id) => all.firstWhere(
        (t) => t.id == id,
        orElse: () => minimal,
      );
}
