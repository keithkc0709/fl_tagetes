import 'package:flutter/widgets.dart';

import '../core/design_tokens.dart';
import '../game/flowline_game.dart';
import '../game/game_state.dart';

/// Performance and simulation readout. Debug builds only — the widget is not
/// even constructed when `FeatureFlags.enableDebugHud` is false, and that flag
/// is forced off outside `kDebugMode`.
class DebugHud extends StatelessWidget {
  final FlowlineGame game;

  const DebugHud({super.key, required this.game});

  @override
  Widget build(BuildContext context) {
    if (!game.flags.enableDebugHud) return const SizedBox.shrink();
    return ValueListenableBuilder<DebugSnapshot?>(
      valueListenable: game.debug,
      builder: (context, snapshot, _) {
        if (snapshot == null) return const SizedBox.shrink();
        final lines = <String>[
          'fps      ${snapshot.fps.toStringAsFixed(1)}  (${snapshot.frameMs.toStringAsFixed(1)} ms)',
          'scale    ${snapshot.timeScale.toStringAsFixed(2)} -> ${snapshot.targetTimeScale.toStringAsFixed(2)}',
          'scrollV  ${snapshot.scrollVelocity.toStringAsFixed(0)} px/s',
          'gameT    ${snapshot.gameTime.toStringAsFixed(2)}',
          'flow     ${snapshot.flowPosition.toStringAsFixed(1)}',
          'rewind   ${snapshot.rewindSeconds.toStringAsFixed(2)}s / ${snapshot.rewindSnapshots}',
          'obstacle ${snapshot.activeObstacles} active, ${snapshot.pooledObstacles} pooled',
          'segment  ${snapshot.activeSegments} active, ${snapshot.pooledSegments} pooled',
          'particle ${snapshot.aliveParticles}',
          'seg#     ${snapshot.segmentIndex}  seed ${snapshot.segmentSeed}',
          'run seed ${snapshot.runSeed}',
          'tier     ${snapshot.difficultyTier}  skill ${snapshot.skill.toStringAsFixed(2)}',
        ];
        return IgnorePointer(
          child: Padding(
            padding: const EdgeInsets.all(Spacing.sm),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                for (final line in lines)
                  Text(
                    line,
                    style: Typo.debug.copyWith(
                      color: const Color(0xCC7CFFB2),
                    ),
                  ),
              ],
            ),
          ),
        );
      },
    );
  }
}
