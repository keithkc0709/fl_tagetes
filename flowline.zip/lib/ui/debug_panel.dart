import 'package:flutter/material.dart';

import '../core/design_tokens.dart';
import '../game/flowline_game.dart';
import '../game/obstacles/obstacle_family.dart';
import '../models/game_mode.dart';

/// Tuning controls. Debug builds only.
///
/// These exist because feel cannot be reasoned about in the abstract — it has
/// to be dialled in on a device, one parameter at a time, with the game
/// running.
class DebugPanel extends StatefulWidget {
  final FlowlineGame game;

  const DebugPanel({super.key, required this.game});

  @override
  State<DebugPanel> createState() => _DebugPanelState();
}

class _DebugPanelState extends State<DebugPanel> {
  @override
  Widget build(BuildContext context) {
    final game = widget.game;
    if (!game.flags.enableDebugPanel) return const SizedBox.shrink();

    return SafeArea(
      child: SingleChildScrollView(
        padding: const EdgeInsets.all(Spacing.md),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text('DEBUG', style: Typo.menuItem),
            const SizedBox(height: Spacing.md),
            Wrap(
              spacing: Spacing.sm,
              runSpacing: Spacing.sm,
              children: [
                _button('skip segment', game.debugSkipSegment),
                _button('auto rewind', game.debugTriggerAutoRewind),
                _button('regen ahead', game.debugRegenerateAhead),
                _button(
                  game.debugFreeze ? 'unfreeze' : 'freeze',
                  () => setState(() => game.debugFreeze = !game.debugFreeze),
                ),
                _button(
                  game.debugShowCollision ? 'hide shapes' : 'show shapes',
                  () => setState(
                    () => game.debugShowCollision = !game.debugShowCollision,
                  ),
                ),
                _button('restart seed', () {
                  game.start(mode: game.mode, seed: game.runSeed);
                  setState(() {});
                }),
              ],
            ),
            const SizedBox(height: Spacing.md),
            Text('time scale ${game.time.actualTimeScale.toStringAsFixed(2)}',
                style: Typo.label),
            Slider(
              min: 0.0,
              max: 4.0,
              value: game.time.actualTimeScale.clamp(0.0, 4.0),
              onChanged: (value) => setState(() => game.debugSetTimeScale(value)),
            ),
            Text('forced tier ${game.debugForcedTier ?? "auto"}',
                style: Typo.label),
            Slider(
              min: -1,
              max: 5,
              divisions: 6,
              value: (game.debugForcedTier ?? -1).toDouble(),
              onChanged: (value) => setState(() {
                game.debugForcedTier = value < 0 ? null : value.round();
              }),
            ),
            const SizedBox(height: Spacing.sm),
            Text('forced family ${game.debugForcedFamily?.id ?? "auto"}',
                style: Typo.label),
            Wrap(
              spacing: Spacing.xs,
              children: [
                _button('auto', () {
                  setState(() => game.debugForcedFamily = null);
                }),
                for (final family in ObstacleFamily.values)
                  _button(family.id, () {
                    setState(() => game.debugForcedFamily = family);
                  }),
              ],
            ),
            const SizedBox(height: Spacing.md),
            Wrap(
              spacing: Spacing.sm,
              children: [
                for (final mode in GameMode.values)
                  _button('mode ${mode.id}', () {
                    game.start(mode: mode);
                    setState(() {});
                  }),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _button(String label, VoidCallback onPressed) => OutlinedButton(
        onPressed: onPressed,
        child: Text(label, style: Typo.label),
      );
}
