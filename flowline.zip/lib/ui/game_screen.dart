import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';

import '../analytics/analytics_service.dart';
import '../core/design_tokens.dart';
import '../core/feature_flags.dart';
import '../core/game_balance_config.dart';
import '../game/effects/effects_manager.dart';
import '../game/flowline_game.dart';
import '../game/game_state.dart';
import '../models/game_mode.dart';
import '../models/player_profile.dart';
import '../render/world_renderer.dart';
import '../repositories/profile_repository.dart';
import '../services/audio_service.dart';
import '../services/haptic_service.dart';
import '../settings/settings_model.dart';
import 'debug_hud.dart';
import 'debug_panel.dart';
import 'gesture_layer.dart';
import 'hud_overlay.dart';
import 'menu_sheet.dart';
import 'onboarding_hints.dart';

/// Hosts the game loop and everything drawn over it.
///
/// The screen starts a FLOW run on its very first frame and loads the saved
/// profile in the background, so time-to-playable is bounded by widget
/// construction rather than by disk I/O.
class GameScreen extends StatefulWidget {
  final ProfileRepository profileRepository;
  final FeatureFlags flags;
  final GameBalanceConfig balance;
  final AnalyticsService analytics;
  final AudioService audio;
  final HapticService haptics;

  const GameScreen({
    super.key,
    required this.profileRepository,
    required this.flags,
    required this.balance,
    required this.analytics,
    required this.audio,
    required this.haptics,
  });

  @override
  State<GameScreen> createState() => _GameScreenState();
}

class _GameScreenState extends State<GameScreen>
    with SingleTickerProviderStateMixin, WidgetsBindingObserver {
  late final EffectsManager _effects;
  late final FlowlineGame _game;
  late final Ticker _ticker;

  Duration _lastTick = Duration.zero;
  PlayerProfile? _profile;
  bool _menuOpen = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);

    _effects = EffectsManager(
      cfg: widget.balance,
      audio: widget.audio,
      haptics: widget.haptics,
      settings: const GameSettings(),
    );
    _game = FlowlineGame(
      baseConfig: widget.balance,
      flags: widget.flags,
      analytics: widget.analytics,
      effects: _effects,
    );

    widget.analytics.track(AnalyticsEvents.appOpen);
    _game.start(mode: GameMode.flow);

    _ticker = createTicker(_onTick)..start();
    _loadProfile();
  }

  Future<void> _loadProfile() async {
    final profile = await widget.profileRepository.load();
    if (!mounted) return;
    setState(() => _profile = profile);
    _game.applySettings(profile.settings);
    _game.difficulty.reset(skill: profile.skillScore);
    widget.audio.startAmbient();
  }

  void _onTick(Duration elapsed) {
    final dt = _lastTick == Duration.zero
        ? 1 / 60
        : (elapsed - _lastTick).inMicroseconds / 1e6;
    _lastTick = elapsed;
    _game.update(dt);
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) {
      _lastTick = Duration.zero;
    } else {
      _game.pause();
      _persist();
    }
  }

  Future<void> _persist() async {
    final profile = _profile;
    if (profile == null) return;
    final stats = _game.buildStats();
    final updated = profile.copyWith(
      highScore: stats.score > profile.highScore ? stats.score : null,
      bestCombo: stats.bestCombo > profile.bestCombo ? stats.bestCombo : null,
      longestDistance: stats.distance > profile.longestDistance
          ? stats.distance
          : null,
      totalPerfects: profile.totalPerfects + stats.perfectCount,
      totalRuns: profile.totalRuns + 1,
      totalPlaySeconds: profile.totalPlaySeconds + stats.durationSeconds,
      skillScore: _game.difficulty.skill,
      tutorialComplete: profile.tutorialComplete || stats.perfectCount > 0,
    );
    setState(() => _profile = updated);
    await widget.profileRepository.save(updated);
  }

  void _openMenu() {
    if (_menuOpen) return;
    _menuOpen = true;
    _game.pause();
    widget.audio.play(AudioCue.menuOpen);
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => MenuSheet(
        profile: _profile ??
            PlayerProfile(installationId: generateInstallationId()),
        currentMode: _game.mode,
        flags: widget.flags,
        debugPanel:
            widget.flags.enableDebugPanel ? DebugPanel(game: _game) : null,
        onSelectMode: (mode) {
          Navigator.of(context).pop();
          _game.start(mode: mode, initialSkill: _profile?.skillScore);
        },
        onSettingsChanged: (settings) {
          _game.applySettings(settings);
          final profile = _profile;
          if (profile != null) {
            final updated = profile.copyWith(settings: settings);
            setState(() => _profile = updated);
            widget.profileRepository.save(updated);
            widget.analytics.track(AnalyticsEvents.settingsChanged);
          }
        },
        onClose: () => Navigator.of(context).pop(),
      ),
    ).whenComplete(() {
      _menuOpen = false;
      _lastTick = Duration.zero;
      _game.resume();
    });
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _ticker.dispose();
    _game.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _game.theme.backgroundTop,
      body: GestureLayer(
        game: _game,
        child: Stack(
          fit: StackFit.expand,
          children: [
            RepaintBoundary(
              child: CustomPaint(
                painter: WorldPainter(_game),
                isComplex: true,
                willChange: true,
              ),
            ),
            SafeArea(
              child: Stack(
                children: [
                  HudOverlay(game: _game),
                  GradeFlash(game: _game),
                  OnboardingHints(game: _game),
                  if (widget.flags.enableDebugHud)
                    Align(
                      alignment: Alignment.centerLeft,
                      child: DebugHud(game: _game),
                    ),
                  Align(
                    alignment: Alignment.topRight,
                    child: Padding(
                      padding: const EdgeInsets.all(Spacing.sm),
                      child: _MenuButton(
                        color: _game.theme.hudForeground,
                        onPressed: _openMenu,
                      ),
                    ),
                  ),
                  _FinishedOverlay(game: _game, onRestart: _restart),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _restart() {
    _persist();
    _game.start(mode: _game.mode, initialSkill: _profile?.skillScore);
  }
}

class _MenuButton extends StatelessWidget {
  final Color color;
  final VoidCallback onPressed;

  const _MenuButton({required this.color, required this.onPressed});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onPressed,
      behavior: HitTestBehavior.opaque,
      child: Container(
        width: 44,
        height: 44,
        alignment: Alignment.center,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: List<Widget>.generate(
            3,
            (_) => Container(
              width: 14,
              height: 1.6,
              margin: const EdgeInsets.symmetric(vertical: 2),
              color: color.withOpacity(0.5),
            ),
          ),
        ),
      ),
    );
  }
}

/// Shown only when a 60-second run ends. FLOW and ZEN never interrupt.
class _FinishedOverlay extends StatelessWidget {
  final FlowlineGame game;
  final VoidCallback onRestart;

  const _FinishedOverlay({required this.game, required this.onRestart});

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<HudSnapshot>(
      valueListenable: game.hud,
      builder: (context, hud, _) {
        if (hud.status != GameStatus.finished) {
          return const SizedBox.shrink();
        }
        final stats = game.buildStats();
        final color = game.theme.hudForeground;
        return Container(
          color: game.theme.backgroundBottom.withOpacity(0.88),
          alignment: Alignment.center,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text('${stats.score}',
                  style: Typo.score.copyWith(color: color, fontSize: 52)),
              const SizedBox(height: Spacing.md),
              Text('PERFECT ${stats.perfectCount}',
                  style: Typo.label.copyWith(color: color.withOpacity(0.7))),
              Text('BEST COMBO ${stats.bestCombo}',
                  style: Typo.label.copyWith(color: color.withOpacity(0.7))),
              Text('PERCENTILE —',
                  style: Typo.label.copyWith(color: color.withOpacity(0.35))),
              const SizedBox(height: Spacing.lg),
              TextButton(
                onPressed: onRestart,
                child: Text('AGAIN',
                    style: Typo.menuItem.copyWith(color: game.theme.accent)),
              ),
            ],
          ),
        );
      },
    );
  }
}
