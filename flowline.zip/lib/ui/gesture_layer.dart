import 'package:flutter/gestures.dart';
import 'package:flutter/widgets.dart';

import '../game/flowline_game.dart';

/// Raw pointer capture.
///
/// A `Listener` is used rather than a gesture recogniser on purpose: gesture
/// arenas add a frame or more of latency while they decide who wins, and this
/// game is entirely about the thumb feeling directly connected to the world.
class GestureLayer extends StatefulWidget {
  final FlowlineGame game;
  final Widget child;

  const GestureLayer({super.key, required this.game, required this.child});

  @override
  State<GestureLayer> createState() => _GestureLayerState();
}

class _GestureLayerState extends State<GestureLayer> {
  VelocityTracker? _tracker;

  @override
  Widget build(BuildContext context) {
    return Listener(
      behavior: HitTestBehavior.opaque,
      onPointerDown: (event) {
        _tracker = VelocityTracker.withKind(event.kind)
          ..addPosition(event.timeStamp, event.position);
        widget.game.onPointerDown();
      },
      onPointerMove: (event) {
        _tracker?.addPosition(event.timeStamp, event.position);
        // Screen Y grows downward; forward (feed-style) motion is upward.
        widget.game.onPointerMove(-event.delta.dy);
      },
      onPointerUp: (event) {
        _tracker?.addPosition(event.timeStamp, event.position);
        final velocity = _tracker?.getVelocity().pixelsPerSecond.dy ?? 0.0;
        widget.game.onPointerUp(-velocity);
        _tracker = null;
      },
      onPointerCancel: (_) {
        widget.game.onPointerCancel();
        _tracker = null;
      },
      child: widget.child,
    );
  }
}
