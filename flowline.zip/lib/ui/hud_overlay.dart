import 'package:flutter/widgets.dart';

import '../core/design_tokens.dart';
import '../game/flowline_game.dart';
import '../game/game_state.dart';
import '../models/score_event.dart';

/// Score, combo and (in 60 mode) the clock.
///
/// Rebuilt only when [HudSnapshot] genuinely changes, and kept deliberately
/// quiet: the world is the interface, the HUD is a footnote.
class HudOverlay extends StatelessWidget {
  final FlowlineGame game;

  const HudOverlay({super.key, required this.game});

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<HudSnapshot>(
      valueListenable: game.hud,
      builder: (context, hud, _) {
        final color = game.theme.hudForeground;
        return IgnorePointer(
          child: Padding(
            padding: const EdgeInsets.symmetric(
              horizontal: Spacing.lg,
              vertical: Spacing.md,
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Expanded(
                      child: Text(
                        '${hud.score}',
                        style: Typo.score.copyWith(
                          color: color.withOpacity(0.85),
                        ),
                      ),
                    ),
                    if (hud.secondsRemaining != null)
                      Padding(
                        padding: const EdgeInsets.only(right: Spacing.xl),
                        child: Text(
                          hud.secondsRemaining!.ceil().toString().padLeft(2, '0'),
                          style: Typo.score.copyWith(
                            color: color.withOpacity(0.55),
                            fontSize: 22,
                          ),
                        ),
                      ),
                  ],
                ),
                const SizedBox(height: Spacing.xs),
                AnimatedOpacity(
                  duration: Motion.quick,
                  opacity: hud.combo >= 2 ? 1.0 : 0.0,
                  child: Text(
                    '×${hud.comboMultiplier.toStringAsFixed(2)}  ${hud.combo}',
                    style: Typo.combo.copyWith(
                      color: game.theme.accent.withOpacity(0.9),
                    ),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}

/// A single glyph that flashes on grade changes. No numbers fly across the
/// screen; the pulse on the Spark carries most of the feedback.
class GradeFlash extends StatelessWidget {
  final FlowlineGame game;

  const GradeFlash({super.key, required this.game});

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<HudSnapshot>(
      valueListenable: game.hud,
      builder: (context, hud, _) {
        final grade = hud.lastGrade;
        if (grade == null || grade == Grade.pass) {
          return const SizedBox.shrink();
        }
        return IgnorePointer(
          child: Center(
            child: AnimatedSwitcher(
              duration: Motion.instant,
              child: Text(
                grade == Grade.perfect ? '◆' : '◇',
                key: ValueKey<int>(hud.lastGradeToken),
                style: Typo.score.copyWith(
                  color: game.theme.accent.withOpacity(0.35),
                ),
              ),
            ),
          ),
        );
      },
    );
  }
}
