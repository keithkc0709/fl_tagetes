import 'package:flutter/material.dart';

import '../core/design_tokens.dart';
import '../core/feature_flags.dart';
import '../models/game_mode.dart';
import '../models/player_profile.dart';
import '../settings/settings_model.dart';
import '../themes/theme_catalog.dart';

/// The entire out-of-game surface.
///
/// There is no lobby. This sheet is reachable from one small floating control
/// and closes straight back into play.
class MenuSheet extends StatefulWidget {
  final PlayerProfile profile;
  final GameMode currentMode;
  final FeatureFlags flags;
  final ValueChanged<GameMode> onSelectMode;
  final ValueChanged<GameSettings> onSettingsChanged;
  final VoidCallback onClose;
  final Widget? debugPanel;

  const MenuSheet({
    super.key,
    required this.profile,
    required this.currentMode,
    required this.flags,
    required this.onSelectMode,
    required this.onSettingsChanged,
    required this.onClose,
    this.debugPanel,
  });

  @override
  State<MenuSheet> createState() => _MenuSheetState();
}

class _MenuSheetState extends State<MenuSheet> {
  late GameSettings _settings = widget.profile.settings;

  void _update(GameSettings next) {
    setState(() => _settings = next);
    widget.onSettingsChanged(next);
  }

  @override
  Widget build(BuildContext context) {
    final theme = ThemeCatalog.byId(_settings.themeId);
    final profile = widget.profile;

    return Container(
      decoration: BoxDecoration(
        color: theme.backgroundBottom,
        borderRadius: const BorderRadius.vertical(top: Radius.circular(Radii.lg)),
      ),
      child: SafeArea(
        top: false,
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(Spacing.lg),
          child: DefaultTextStyle(
            style: Typo.label.copyWith(color: theme.hudForeground),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                Center(
                  child: Container(
                    width: 44,
                    height: 4,
                    decoration: BoxDecoration(
                      color: theme.hudForeground.withOpacity(0.25),
                      borderRadius: BorderRadius.circular(Radii.sm),
                    ),
                  ),
                ),
                const SizedBox(height: Spacing.lg),
                _section('MODE'),
                Wrap(
                  spacing: Spacing.sm,
                  children: [
                    _modeChip(GameMode.flow, 'FLOW', true),
                    _modeChip(GameMode.sixty, '60', widget.flags.enableDailyMode),
                    _modeChip(GameMode.zen, 'ZEN', widget.flags.enableZenMode),
                  ],
                ),
                const SizedBox(height: Spacing.lg),
                _section('THEME'),
                Wrap(
                  spacing: Spacing.sm,
                  children: [
                    for (final candidate in ThemeCatalog.all)
                      ChoiceChip(
                        selected: _settings.themeId == candidate.id,
                        label: Text(candidate.displayName, style: Typo.label),
                        onSelected: profile.unlockedThemes.contains(candidate.id)
                            ? (_) => _update(
                                  _settings.copyWith(themeId: candidate.id),
                                )
                            : null,
                      ),
                  ],
                ),
                const SizedBox(height: Spacing.lg),
                _section('SETTINGS'),
                _toggle('Sound', _settings.soundEnabled,
                    (v) => _update(_settings.copyWith(soundEnabled: v))),
                _toggle('Haptics', _settings.hapticsEnabled,
                    (v) => _update(_settings.copyWith(hapticsEnabled: v))),
                _toggle('Reduced motion', _settings.reducedMotion,
                    (v) => _update(_settings.copyWith(reducedMotion: v))),
                _toggle('High contrast', _settings.highContrast,
                    (v) => _update(_settings.copyWith(highContrast: v))),
                _toggle('Generous timing', _settings.generousTolerances,
                    (v) => _update(_settings.copyWith(generousTolerances: v))),
                const SizedBox(height: Spacing.lg),
                _section('STATISTICS'),
                _stat('Best score', '${profile.highScore}'),
                _stat('Best combo', '${profile.bestCombo}'),
                _stat('Perfects', '${profile.totalPerfects}'),
                _stat('Runs', '${profile.totalRuns}'),
                _stat(
                  'Distance',
                  profile.longestDistance.toStringAsFixed(0),
                ),
                if (widget.debugPanel != null) ...[
                  const SizedBox(height: Spacing.lg),
                  widget.debugPanel!,
                ],
                const SizedBox(height: Spacing.lg),
                Center(
                  child: TextButton(
                    onPressed: widget.onClose,
                    child: Text('RESUME', style: Typo.menuItem),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _section(String title) => Padding(
        padding: const EdgeInsets.only(bottom: Spacing.sm),
        child: Text(title, style: Typo.label.copyWith(letterSpacing: 3)),
      );

  Widget _modeChip(GameMode mode, String label, bool enabled) => ChoiceChip(
        selected: widget.currentMode == mode,
        label: Text(label, style: Typo.menuItem),
        onSelected: enabled ? (_) => widget.onSelectMode(mode) : null,
      );

  Widget _toggle(String label, bool value, ValueChanged<bool> onChanged) => Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label),
          Switch(value: value, onChanged: onChanged),
        ],
      );

  Widget _stat(String label, String value) => Padding(
        padding: const EdgeInsets.symmetric(vertical: Spacing.xs),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [Text(label), Text(value)],
        ),
      );
}
