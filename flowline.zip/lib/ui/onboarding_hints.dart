import 'package:flutter/widgets.dart';

import '../core/design_tokens.dart';
import '../game/flowline_game.dart';
import '../game/game_state.dart';

/// Wordless onboarding.
///
/// Three hints, each a shape in motion: a thumb sliding up, a thumb holding
/// still, a thumb sliding down. Every one disappears the instant the player
/// performs the verb, and none of them ever blocks input.
class OnboardingHints extends StatefulWidget {
  final FlowlineGame game;

  const OnboardingHints({super.key, required this.game});

  @override
  State<OnboardingHints> createState() => _OnboardingHintsState();
}

class _OnboardingHintsState extends State<OnboardingHints>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller = AnimationController(
    vsync: this,
    duration: Motion.hintCycle,
  )..repeat();

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<HudSnapshot>(
      valueListenable: widget.game.hud,
      builder: (context, hud, _) {
        if (hud.hint == HintKind.none || hud.status != GameStatus.playing) {
          return const SizedBox.shrink();
        }
        return IgnorePointer(
          child: AnimatedBuilder(
            animation: _controller,
            builder: (context, _) => CustomPaint(
              painter: _HintPainter(
                kind: hud.hint,
                progress: _controller.value,
                color: widget.game.theme.hudForeground,
                accent: widget.game.theme.accent,
              ),
              size: Size.infinite,
            ),
          ),
        );
      },
    );
  }
}

class _HintPainter extends CustomPainter {
  final HintKind kind;
  final double progress;
  final Color color;
  final Color accent;

  _HintPainter({
    required this.kind,
    required this.progress,
    required this.color,
    required this.accent,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final centerX = size.width * 0.5;
    final baseY = size.height * 0.74;
    final travel = size.height * 0.16;

    final eased = Curves.easeInOut.transform(
      progress < 0.65 ? progress / 0.65 : 1.0,
    );
    final fade = progress < 0.75 ? 1.0 : 1.0 - (progress - 0.75) / 0.25;

    double thumbY;
    switch (kind) {
      case HintKind.scrollUp:
        thumbY = baseY - travel * eased;
      case HintKind.dragDownToRewind:
        thumbY = baseY - travel + travel * eased;
      case HintKind.holdToFreeze:
        thumbY = baseY - travel * 0.5;
      case HintKind.none:
        return;
    }

    final paint = Paint()
      ..color = color.withOpacity(0.22 * fade)
      ..style = PaintingStyle.fill;
    final ring = Paint()
      ..color = accent.withOpacity(0.35 * fade)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.6;

    // Trail showing the direction of travel.
    if (kind != HintKind.holdToFreeze) {
      final trailPaint = Paint()
        ..color = accent.withOpacity(0.14 * fade)
        ..strokeWidth = 2.0
        ..strokeCap = StrokeCap.round;
      canvas.drawLine(
        Offset(centerX, baseY),
        Offset(centerX, baseY - travel),
        trailPaint,
      );
    }

    canvas.drawCircle(Offset(centerX, thumbY), 26.0, paint);
    canvas.drawCircle(Offset(centerX, thumbY), 26.0, ring);

    if (kind == HintKind.holdToFreeze) {
      final pulse = 26.0 + 10.0 * (0.5 + 0.5 * (progress * 2 - 1).abs());
      canvas.drawCircle(
        Offset(centerX, thumbY),
        pulse,
        Paint()
          ..color = accent.withOpacity(0.12 * fade)
          ..style = PaintingStyle.stroke
          ..strokeWidth = 1.2,
      );
    }
  }

  @override
  bool shouldRepaint(covariant _HintPainter oldDelegate) =>
      oldDelegate.progress != progress || oldDelegate.kind != kind;
}
