#!/usr/bin/env bash
# Produces an optimised static web build in build/web.
set -euo pipefail

cd "$(dirname "$0")/.."

flutter config --no-analytics --enable-web >/dev/null 2>&1 || true

if [ ! -f web/index.html ]; then
  echo "==> web/ scaffold missing, generating it"
  flutter create --platforms=web --project-name flowline .
fi

echo "==> flutter pub get"
flutter pub get

echo "==> flutter build web --release"
# CanvasKit gives consistent 60 fps CustomPainter output across browsers.
# The HTML renderer is smaller but drops frames on the particle and glow work.
flutter build web --release --web-renderer canvaskit --base-href /

echo "==> build/web is ready"
