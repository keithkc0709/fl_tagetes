#!/usr/bin/env bash
# Entry point used by the Replit Run button.
#
#   MODE=dev  -> flutter run on a web-server device (hot restart, slower frames)
#   MODE=prod -> release build served statically (smooth, no hot restart)
#
# Default is prod: FLOWLINE is a 60 fps game, and the debug web build's frame
# times are misleading enough that tuning against them is actively harmful.
set -euo pipefail

cd "$(dirname "$0")/.."

MODE="${MODE:-prod}"
PORT="${PORT:-8080}"

if ! command -v flutter >/dev/null 2>&1; then
  cat <<'MSG'
Flutter is not on PATH.

Replit installs it from replit.nix. If you see this message:
  1. Confirm replit.nix exists at the repo root and lists pkgs.flutter
  2. Open the Shell and run:  kill 1     (this reloads the Nix environment)
  3. Press Run again
MSG
  exit 1
fi

flutter config --no-analytics --enable-web >/dev/null 2>&1 || true

if [ ! -f web/index.html ]; then
  echo "==> web/ scaffold missing, generating it"
  flutter create --platforms=web --project-name flowline .
fi

echo "==> flutter pub get"
flutter pub get

if [ "$MODE" = "dev" ]; then
  echo "==> starting dev server on 0.0.0.0:${PORT} (hot restart with 'R')"
  exec flutter run -d web-server \
    --web-hostname 0.0.0.0 \
    --web-port "${PORT}" \
    --web-renderer canvaskit
fi

echo "==> building release bundle (first run takes a few minutes)"
flutter build web --release --web-renderer canvaskit --base-href /

echo "==> serving build/web on 0.0.0.0:${PORT}"
cd build/web
exec python3 -m http.server "${PORT}" --bind 0.0.0.0
