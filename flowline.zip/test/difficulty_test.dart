import 'package:flowline/core/game_balance_config.dart';
import 'package:flowline/game/difficulty/adaptive_difficulty.dart';
import 'package:flowline/game/obstacles/obstacle_family.dart';
import 'package:flowline/models/score_event.dart';
import 'package:flutter_test/flutter_test.dart';

const GameBalanceConfig cfg = GameBalanceConfig();
const ObstacleFamily gate = ObstacleFamily.movingGate;
const ObstacleFamily ring = ObstacleFamily.rotatingRing;

void main() {
  test('clean play raises skill, and raises it slowly', () {
    final difficulty = AdaptiveDifficulty(cfg, initialSkill: 0.3);
    final before = difficulty.skill;

    difficulty.registerResult(Grade.perfect, 1.0, gate);

    expect(difficulty.skill, greaterThan(before));
    expect(difficulty.skill - before, lessThanOrEqualTo(cfg.skillRiseRate));
  });

  test('failure lowers skill faster than success raises it', () {
    final rising = AdaptiveDifficulty(cfg, initialSkill: 0.5)
      ..registerResult(Grade.perfect, 1.0, gate);
    final falling = AdaptiveDifficulty(cfg, initialSkill: 0.5)
      ..registerResult(Grade.fail, 0.0, gate);

    expect(rising.skill - 0.5, lessThan(0.5 - falling.skill));
  });

  test('repeated failures compound', () {
    final difficulty = AdaptiveDifficulty(cfg, initialSkill: 1.0);
    difficulty.registerResult(Grade.fail, 0.0, gate);
    final firstDrop = 1.0 - difficulty.skill;
    final beforeSecond = difficulty.skill;
    difficulty.registerResult(Grade.fail, 0.0, gate);
    final secondDrop = beforeSecond - difficulty.skill;

    expect(secondDrop, greaterThan(firstDrop));
    expect(difficulty.consecutiveFailures, 2);
  });

  test('tiers span the full configured range', () {
    expect(AdaptiveDifficulty(cfg, initialSkill: 0.0).tier, 0);
    expect(AdaptiveDifficulty(cfg, initialSkill: 0.5).tier, 3);
    expect(AdaptiveDifficulty(cfg, initialSkill: 1.0).tier, 5);
  });

  test('tier is monotonic in skill', () {
    var previous = -1;
    for (var skill = 0.0; skill <= 1.0; skill += 0.01) {
      final tier = AdaptiveDifficulty(cfg, initialSkill: skill).tier;
      expect(tier, greaterThanOrEqualTo(previous));
      previous = tier;
    }
  });

  test('struggling widens tolerances and slows mechanisms', () {
    final struggling = AdaptiveDifficulty(cfg, initialSkill: 0.0);
    final expert = AdaptiveDifficulty(cfg, initialSkill: 1.0);

    expect(
      struggling.toleranceMultiplier,
      greaterThan(expert.toleranceMultiplier),
    );
    expect(struggling.speedMultiplier, lessThan(expert.speedMultiplier));
    expect(struggling.toleranceMultiplier, greaterThanOrEqualTo(1.0));
  });

  test('being stuck on one mechanic buys extra mercy for that mechanic', () {
    final difficulty = AdaptiveDifficulty(cfg, initialSkill: 0.5);
    final baseline = difficulty.toleranceMultiplier;

    for (var i = 0; i < 3; i++) {
      difficulty.registerResult(Grade.fail, 0.0, ring);
    }

    expect(difficulty.toleranceMultiplier, greaterThan(baseline));
  });

  test('skill is clamped to the unit interval', () {
    final low = AdaptiveDifficulty(cfg, initialSkill: 0.02);
    for (var i = 0; i < 50; i++) {
      low.registerResult(Grade.fail, 0.0, gate);
    }
    expect(low.skill, 0.0);

    final high = AdaptiveDifficulty(cfg, initialSkill: 0.98);
    for (var i = 0; i < 200; i++) {
      high.registerResult(Grade.perfect, 1.0, gate);
    }
    expect(high.skill, 1.0);
  });

  test('disabling adaptation pins everything to neutral', () {
    final difficulty = AdaptiveDifficulty(cfg, enabled: false, initialSkill: 0.1);
    difficulty.registerResult(Grade.fail, 0.0, gate);

    expect(difficulty.tier, 3);
    expect(difficulty.toleranceMultiplier, 1.0);
    expect(difficulty.speedMultiplier, 1.0);
  });

  test('a player who improves is eventually promoted', () {
    final difficulty = AdaptiveDifficulty(cfg, initialSkill: 0.1);
    final startTier = difficulty.tier;

    for (var i = 0; i < 40; i++) {
      difficulty.registerResult(Grade.perfect, 0.95, gate);
    }

    expect(difficulty.tier, greaterThan(startTier));
  });

  test('a player who collapses is eventually demoted', () {
    final difficulty = AdaptiveDifficulty(cfg, initialSkill: 0.9);
    final startTier = difficulty.tier;

    for (var i = 0; i < 6; i++) {
      difficulty.registerResult(Grade.fail, 0.0, gate);
    }

    expect(difficulty.tier, lessThan(startTier));
  });
}
