import 'package:flowline/core/game_balance_config.dart';
import 'package:flowline/game/difficulty/adaptive_difficulty.dart';
import 'package:flowline/game/generation/generation_rules.dart';
import 'package:flowline/game/generation/procedural_generator.dart';
import 'package:flowline/game/obstacles/obstacle_factory.dart';
import 'package:flowline/game/obstacles/obstacle_family.dart';
import 'package:flowline/game/segments/segment.dart';
import 'package:flutter_test/flutter_test.dart';

const GameBalanceConfig cfg = GameBalanceConfig();
const GenerationRules rules = GenerationRules();

DifficultySnapshot tierSnapshot(int tier) => DifficultySnapshot(
      tier: tier,
      toleranceMultiplier: 1.0,
      speedMultiplier: 1.0,
    );

/// Generates [count] segments and hands each to [inspect] before recycling it.
void generateRun({
  required int seed,
  required int count,
  required DifficultySnapshot Function(int index) difficultyFor,
  required void Function(Segment segment) inspect,
}) {
  final factory = ObstacleFactory();
  final generator = ProceduralGenerator(
    cfg: cfg,
    factory: factory,
    runSeed: seed,
    rules: rules,
  );
  final segment = Segment();
  var y = 0.0;

  for (var i = 0; i < count; i++) {
    generator.generate(segment, i, y, difficultyFor(i));
    inspect(segment);
    y = segment.endY;
    for (final obstacle in segment.obstacles) {
      factory.release(obstacle);
    }
  }
}

void main() {
  group('determinism', () {
    test('the same seed reproduces the same run', () {
      List<String> fingerprint(int seed) {
        final result = <String>[];
        generateRun(
          seed: seed,
          count: 400,
          difficultyFor: (i) => tierSnapshot(i % 6),
          inspect: (segment) {
            for (final o in segment.obstacles) {
              result.add(
                '${segment.index}:${o.family.id}:'
                '${o.params.openingWidth.toStringAsFixed(6)}:'
                '${o.params.period.toStringAsFixed(6)}:'
                '${o.params.phase.toStringAsFixed(6)}:'
                '${o.anchorY.toStringAsFixed(4)}',
              );
            }
          },
        );
        return result;
      }

      expect(fingerprint(1234), equals(fingerprint(1234)));
    });

    test('different seeds produce different runs', () {
      List<String> families(int seed) {
        final result = <String>[];
        generateRun(
          seed: seed,
          count: 120,
          difficultyFor: (_) => tierSnapshot(4),
          inspect: (segment) {
            for (final o in segment.obstacles) {
              result.add(o.family.id);
            }
          },
        );
        return result;
      }

      expect(families(1), isNot(equals(families(2))));
    });

    test('the daily seed depends only on the calendar date', () {
      final morning = DateTime(2026, 3, 14, 6, 30);
      final evening = DateTime(2026, 3, 14, 23, 59);
      final nextDay = DateTime(2026, 3, 15, 0, 1);

      expect(
        _dailySeed(morning),
        equals(_dailySeed(evening)),
      );
      expect(_dailySeed(morning), isNot(equals(_dailySeed(nextDay))));
    });
  });

  group('invariants across thousands of segments', () {
    test('geometry is always valid and playable', () {
      final minimumOpening = cfg.sparkRadius * 2.0 + 6.0;
      var inspected = 0;

      for (var seed = 0; seed < 12; seed++) {
        generateRun(
          seed: seed * 7919 + 13,
          count: 250,
          difficultyFor: (i) => tierSnapshot(i % 6),
          inspect: (segment) {
            inspected++;
            expect(segment.obstacles, isNotEmpty);
            expect(segment.length, greaterThan(0));
            expect(segment.tier, inInclusiveRange(0, 5));

            for (final o in segment.obstacles) {
              expect(o.params.period, greaterThan(0.0));
              expect(o.params.speedScale, greaterThan(0.0));
              expect(o.params.count, greaterThanOrEqualTo(2));
              expect(o.bandHeight, greaterThan(0.0));

              // Every gap must admit the Spark with margin to spare.
              expect(
                o.params.openingWidth,
                greaterThanOrEqualTo(minimumOpening),
              );

              // Obstacles never overhang their own segment.
              expect(o.anchorY, greaterThanOrEqualTo(segment.startY));
              expect(
                o.anchorY + o.bandHeight,
                lessThanOrEqualTo(segment.endY + 1e-6),
              );

              // The entry runway is always hazard-free.
              expect(
                o.anchorY - segment.startY,
                greaterThanOrEqualTo(ProceduralGenerator.entryPadding - 1e-6),
              );
            }
          },
        );
      }

      expect(inspected, 12 * 250);
    });

    test('crusher gaps never invert', () {
      generateRun(
        seed: 99,
        count: 400,
        difficultyFor: (i) => tierSnapshot(i % 6),
        inspect: (segment) {
          for (final o in segment.obstacles) {
            if (o.family != ObstacleFamily.crusher) continue;
            expect(o.params.extra, lessThan(o.params.openingWidth));
            expect(o.params.extra, greaterThan(0.0));
          }
        },
      );
    });
  });

  group('pacing rules', () {
    test('no family repeats beyond the configured limit', () {
      final history = <ObstacleFamily>[];
      generateRun(
        seed: 4242,
        count: 600,
        difficultyFor: (_) => tierSnapshot(5),
        inspect: (segment) {
          for (final o in segment.obstacles) {
            history.add(o.family);
          }
        },
      );

      var run = 1;
      for (var i = 1; i < history.length; i++) {
        run = history[i] == history[i - 1] ? run + 1 : 1;
        expect(
          run,
          lessThanOrEqualTo(rules.maxConsecutiveSameFamily),
          reason: 'family ${history[i].id} repeated $run times at index $i',
        );
      }
    });

    test('demanding families respect their cooldown', () {
      final history = <ObstacleFamily>[];
      generateRun(
        seed: 777,
        count: 600,
        difficultyFor: (_) => tierSnapshot(5),
        inspect: (segment) {
          for (final o in segment.obstacles) {
            history.add(o.family);
          }
        },
      );

      var sinceDemanding = 1 << 20;
      for (final family in history) {
        if (family.isDemanding) {
          expect(
            sinceDemanding,
            greaterThanOrEqualTo(rules.demandingCooldown),
          );
          sinceDemanding = 0;
        } else {
          sinceDemanding++;
        }
      }
    });

    test('onboarding only ever produces the teaching obstacle', () {
      generateRun(
        seed: 5,
        count: 60,
        difficultyFor: (_) => tierSnapshot(0),
        inspect: (segment) {
          for (final o in segment.obstacles) {
            expect(o.family, ObstacleFamily.movingGate);
          }
        },
      );
    });

    test('a recovery beat appears at least every N segments', () {
      var sinceRecovery = 0;
      generateRun(
        seed: 31,
        count: 300,
        difficultyFor: (_) => tierSnapshot(5),
        inspect: (segment) {
          final easy = segment.obstacles.length == 1 &&
              segment.obstacles.first.family.isRecovery;
          sinceRecovery = easy ? 0 : sinceRecovery + 1;
          expect(sinceRecovery, lessThanOrEqualTo(rules.recoveryInterval + 1));
        },
      );
    });

    test('low tiers never stack two obstacles in one segment', () {
      generateRun(
        seed: 8,
        count: 300,
        difficultyFor: (_) => tierSnapshot(2),
        inspect: (segment) {
          expect(segment.obstacles.length, 1);
        },
      );
    });
  });

  group('pooling', () {
    test('generation reuses obstacles instead of allocating forever', () {
      final factory = ObstacleFactory();
      final generator = ProceduralGenerator(
        cfg: cfg,
        factory: factory,
        runSeed: 3,
      );
      final segment = Segment();
      var y = 0.0;

      for (var i = 0; i < 500; i++) {
        generator.generate(segment, i, y, tierSnapshot(5));
        y = segment.endY;
        for (final obstacle in segment.obstacles) {
          factory.release(obstacle);
        }
      }

      // Eight families, at most two live at a time.
      expect(factory.createdCount, lessThanOrEqualTo(24));
    });
  });
}

int _dailySeed(DateTime date) {
  final key = date.year * 10000 + date.month * 100 + date.day;
  return _hash(key, 0x5EED);
}

int _hash(int a, int b) {
  const mask = 0x3FFFFFFFFFFFFFFF;
  var h = (a * 0x27220A95) & mask;
  h ^= (b + 0x9E3779B9 + ((h << 6) & mask) + (h >> 2)) & mask;
  h ^= h >> 31;
  return h & mask;
}
