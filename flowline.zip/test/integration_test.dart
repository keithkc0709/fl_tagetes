import 'package:flowline/analytics/analytics_service.dart';
import 'package:flowline/app.dart';
import 'package:flowline/core/feature_flags.dart';
import 'package:flowline/core/game_balance_config.dart';
import 'package:flowline/game/effects/effects_manager.dart';
import 'package:flowline/game/flowline_game.dart';
import 'package:flowline/game/game_state.dart';
import 'package:flowline/models/game_mode.dart';
import 'package:flowline/repositories/profile_repository.dart';
import 'package:flowline/services/audio_service.dart';
import 'package:flowline/services/haptic_service.dart';
import 'package:flowline/settings/settings_model.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

const double frame = 1 / 60;
const GameBalanceConfig balance = GameBalanceConfig();

FlowlineGame buildGame({FeatureFlags? flags}) {
  const settings = GameSettings();
  final effects = EffectsManager(
    cfg: balance,
    audio: SilentAudioService(),
    haptics: RecordingHapticService(),
    settings: settings,
  );
  return FlowlineGame(
    baseConfig: balance,
    flags: flags ?? const FeatureFlags(),
    analytics: LocalAnalyticsService(enabled: false),
    effects: effects,
  );
}

/// Runs [seconds] of gameplay while dragging at [pixelsPerSecond].
void play(FlowlineGame game, double seconds, double pixelsPerSecond) {
  final frames = (seconds / frame).round();
  for (var i = 0; i < frames; i++) {
    game.onPointerMove(pixelsPerSecond * frame);
    game.update(frame);
  }
}

void main() {
  group('headless session', () {
    test('a two-minute run scores, generates and never stalls', () {
      final game = buildGame()..visibleHeight = 210.0;
      game.start(mode: GameMode.flow, seed: 20260814);
      game.onPointerDown();

      // A mix of speeds: cruising, studying, and flicking.
      for (var cycle = 0; cycle < 12; cycle++) {
        play(game, 4.0, 900);
        play(game, 1.5, 180);
        play(game, 0.8, 0);
        play(game, 1.2, 3000);
        play(game, 2.5, 700);
      }

      expect(game.status, GameStatus.playing);
      expect(game.time.flowPosition, greaterThan(500.0));
      expect(game.segments.activeSegmentCount, greaterThan(0));
      expect(
        game.scoring.score + game.scoring.failCount,
        greaterThan(0),
        reason: 'a two-minute run must resolve at least one obstacle',
      );
    });

    test('object pools stay bounded over a long session', () {
      final game = buildGame()..visibleHeight = 210.0;
      game.start(mode: GameMode.flow, seed: 7);
      game.onPointerDown();

      play(game, 180.0, 1100);

      // Eight families, a handful live at any moment: allocation must plateau.
      expect(game.obstacleFactory.createdCount, lessThan(48));
      expect(game.segments.segmentPool.createdCount, lessThan(32));
      expect(game.rewind.count, lessThanOrEqualTo(game.rewind.capacity));
      expect(
        game.segments.activeSegmentCount,
        lessThan(24),
        reason: 'segments behind the player must be recycled',
      );
    });

    test('scrolling backwards rewinds the world and the score together', () {
      final game = buildGame()..visibleHeight = 210.0;
      game.start(mode: GameMode.flow, seed: 3131);
      game.onPointerDown();

      play(game, 12.0, 1000);
      final peakFlow = game.time.flowPosition;
      final peakScore = game.scoring.score;
      final peakGameTime = game.time.gameTime;

      play(game, 1.5, -1400);

      expect(game.time.isRewinding, isTrue);
      expect(game.time.gameTime, lessThan(peakGameTime));
      expect(game.time.flowPosition, lessThan(peakFlow));
      expect(game.scoring.score, lessThanOrEqualTo(peakScore));

      // And it recovers cleanly.
      play(game, 3.0, 1000);
      expect(game.time.isRewinding, isFalse);
      expect(game.status, GameStatus.playing);
    });

    test('a collision resolves itself without a modal or a restart', () {
      final game = buildGame()..visibleHeight = 210.0;
      game.start(mode: GameMode.flow, seed: 555);
      game.onPointerDown();

      // Barrel forward blindly until something is hit.
      var failuresSeen = 0;
      for (var i = 0; i < 200 && failuresSeen == 0; i++) {
        play(game, 1.0, 2600);
        failuresSeen = game.scoring.failCount;
      }

      if (failuresSeen > 0) {
        expect(game.status, GameStatus.playing);
        // The auto-rewind resolves inside a second of real time.
        play(game, 1.0, 0);
        expect(game.time.isAutoRewinding, isFalse);
      }
      expect(game.time.flowPosition, greaterThan(0.0));
    });

    test('60 mode ends on real seconds, not manipulated game time', () {
      final game = buildGame()..visibleHeight = 210.0;
      game.start(mode: GameMode.sixty, seed: 1);
      game.onPointerDown();

      // Crawl: game time barely advances, but the clock does not care.
      play(game, 59.0, 120);
      expect(game.status, GameStatus.playing);

      play(game, 2.0, 120);
      expect(game.status, GameStatus.finished);
      expect(game.buildStats().mode, GameMode.sixty);
    });

    test('the daily seed is stable for a given date', () {
      final a = FlowlineGame.dailySeedFor(DateTime(2026, 8, 14, 1));
      final b = FlowlineGame.dailySeedFor(DateTime(2026, 8, 14, 22));
      final c = FlowlineGame.dailySeedFor(DateTime(2026, 8, 15));

      expect(a, b);
      expect(a, isNot(c));
    });

    test('zen mode never breaks the run on contact', () {
      final game = buildGame()..visibleHeight = 210.0;
      game.start(mode: GameMode.zen, seed: 12);
      game.onPointerDown();

      play(game, 90.0, 2800);

      expect(game.status, GameStatus.playing);
      expect(game.scoring.failCount, 0);
    });

    test('switching modes mid-session returns objects to their pools', () {
      final game = buildGame()..visibleHeight = 210.0;

      game.start(mode: GameMode.flow, seed: 1);
      game.onPointerDown();
      play(game, 30.0, 1200);
      final createdAfterFirst = game.obstacleFactory.createdCount;

      game.start(mode: GameMode.zen, seed: 2);
      game.onPointerDown();
      play(game, 30.0, 1200);

      expect(
        game.obstacleFactory.createdCount,
        lessThanOrEqualTo(createdAfterFirst + 8),
      );
    });
  });

  group('launch to gameplay', () {
    testWidgets('the app opens straight into a playable world', (tester) async {
      await tester.pumpWidget(
        FlowlineApp(
          profileRepository: InMemoryProfileRepository(),
          flags: const FeatureFlags(enableAnalytics: false),
          balance: balance,
          analytics: NoopAnalyticsService(),
          audio: SilentAudioService(),
          haptics: RecordingHapticService(),
        ),
      );
      await tester.pump();

      // No lobby, no menu, no loading step: the world is on screen already.
      expect(find.byType(CustomPaint), findsWidgets);
      expect(find.text('PLAY'), findsNothing);
      expect(find.text('0'), findsOneWidget);
    });

    testWidgets('scroll, pause and resume survive a full cycle',
        (tester) async {
      await tester.pumpWidget(
        FlowlineApp(
          profileRepository: InMemoryProfileRepository(),
          flags: const FeatureFlags(enableAnalytics: false),
          balance: balance,
          analytics: NoopAnalyticsService(),
          audio: SilentAudioService(),
          haptics: RecordingHapticService(),
        ),
      );
      await tester.pump();

      final center = tester.getCenter(find.byType(Scaffold));
      final gesture = await tester.startGesture(center);
      for (var i = 0; i < 40; i++) {
        await gesture.moveBy(const Offset(0, -18));
        await tester.pump(const Duration(milliseconds: 16));
      }
      await gesture.up();
      await tester.pump(const Duration(milliseconds: 16));

      expect(tester.takeException(), isNull);

      // Let the world settle after the gesture ends; the inertial fling must
      // decay without throwing.
      for (var i = 0; i < 60; i++) {
        await tester.pump(const Duration(milliseconds: 16));
      }
      expect(tester.takeException(), isNull);
    });
  });
}
