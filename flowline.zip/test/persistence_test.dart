import 'dart:convert';

import 'package:flowline/models/game_mode.dart';
import 'package:flowline/models/player_profile.dart';
import 'package:flowline/models/replay.dart';
import 'package:flowline/models/run_stats.dart';
import 'package:flowline/repositories/profile_repository.dart';
import 'package:flowline/settings/settings_model.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  group('player profile', () {
    test('round-trips through JSON without loss', () {
      const original = PlayerProfile(
        installationId: 'abc123',
        highScore: 4820,
        longestDistance: 12345.5,
        bestCombo: 31,
        totalSessions: 9,
        totalPerfects: 402,
        totalRuns: 40,
        totalPlaySeconds: 3600.25,
        unlockedThemes: ['minimal', 'neon'],
        settings: GameSettings(
          soundEnabled: false,
          hapticsEnabled: false,
          reducedMotion: true,
          highContrast: true,
          generousTolerances: true,
          themeId: 'neon',
          sfxVolume: 0.3,
          ambientVolume: 0.1,
        ),
        tutorialComplete: true,
        skillScore: 0.77,
        lastDailyDate: '2026-03-14',
        lastDailyScore: 990,
      );

      final restored = PlayerProfile.fromJson(
        (jsonDecode(jsonEncode(original.toJson())) as Map)
            .cast<String, Object?>(),
      );

      expect(restored.installationId, original.installationId);
      expect(restored.highScore, original.highScore);
      expect(restored.longestDistance, original.longestDistance);
      expect(restored.bestCombo, original.bestCombo);
      expect(restored.totalPerfects, original.totalPerfects);
      expect(restored.unlockedThemes, original.unlockedThemes);
      expect(restored.settings.themeId, 'neon');
      expect(restored.settings.reducedMotion, isTrue);
      expect(restored.settings.soundEnabled, isFalse);
      expect(restored.tutorialComplete, isTrue);
      expect(restored.skillScore, closeTo(0.77, 1e-9));
      expect(restored.lastDailyDate, '2026-03-14');
    });

    test('missing fields fall back to safe defaults', () {
      final restored = PlayerProfile.fromJson(<String, Object?>{});

      expect(restored.highScore, 0);
      expect(restored.settings.themeId, 'minimal');
      expect(restored.unlockedThemes, contains('minimal'));
      expect(restored.skillScore, greaterThan(0.0));
    });

    test('copyWith leaves untouched fields alone', () {
      const profile = PlayerProfile(installationId: 'x', highScore: 10);
      final updated = profile.copyWith(highScore: 20);

      expect(updated.highScore, 20);
      expect(updated.installationId, 'x');
      expect(profile.highScore, 10);
    });
  });

  group('repository', () {
    test('creates a profile with a fresh installation id on first load',
        () async {
      final repository = InMemoryProfileRepository();
      final profile = await repository.load();

      expect(profile.installationId, isNotEmpty);
      expect(profile.installationId.length, 16);
    });

    test('save then load returns the saved document', () async {
      final repository = InMemoryProfileRepository();
      final profile = await repository.load();
      await repository.save(profile.copyWith(highScore: 777));

      final reloaded = await repository.load();
      expect(reloaded.highScore, 777);
    });

    test('installation ids are not obviously colliding', () {
      final ids = <String>{
        for (var i = 0; i < 50; i++) generateInstallationId(),
      };
      expect(ids.length, greaterThan(40));
    });
  });

  group('run stats and replays', () {
    test('run stats round-trip', () {
      const stats = RunStats(
        mode: GameMode.sixty,
        seed: 42,
        score: 1200,
        bestCombo: 14,
        perfectCount: 20,
        distance: 900.5,
        durationSeconds: 60.0,
        skillTier: 4,
      );

      final restored = RunStats.fromJson(stats.toJson());
      expect(restored.mode, GameMode.sixty);
      expect(restored.score, 1200);
      expect(restored.skillTier, 4);
    });

    test('a replay captures everything needed to reproduce a run', () {
      final recorder = ReplayRecorder()..enabled = true;
      for (var i = 0; i < 10; i++) {
        recorder.record(i / 60, 12.0, true);
      }
      final replay = recorder.build(
        gameVersion: '0.1.0',
        mode: GameMode.flow,
        seed: 99,
        finalScore: 500,
      );

      final restored = Replay.fromJson(
        (jsonDecode(jsonEncode(replay.toJson())) as Map)
            .cast<String, Object?>(),
      );

      expect(restored.seed, 99);
      expect(restored.inputs.length, 10);
      expect(restored.inputs.first.delta, 12.0);
      expect(restored.mode, GameMode.flow);
    });

    test('recording is off unless explicitly enabled', () {
      final recorder = ReplayRecorder();
      recorder.record(0.0, 5.0, true);

      final replay = recorder.build(
        gameVersion: '0.1.0',
        mode: GameMode.flow,
        seed: 1,
        finalScore: 0,
      );
      expect(replay.inputs, isEmpty);
    });
  });
}
