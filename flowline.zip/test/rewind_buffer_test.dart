import 'package:flowline/core/game_balance_config.dart';
import 'package:flowline/game/rewind/rewind_buffer.dart';
import 'package:flowline/game/rewind/rewindable.dart';
import 'package:flowline/game/rewind/snapshot.dart';
import 'package:flutter_test/flutter_test.dart';

class FakeRewindable implements Rewindable {
  @override
  final int rewindId;

  double value = 0.0;
  bool wasReset = false;

  FakeRewindable(this.rewindId);

  @override
  void captureState(SnapshotWriter writer) => writer.writeDouble(value);

  @override
  void restoreState(SnapshotReader reader) => value = reader.readDouble();

  @override
  void resetRewindState() {
    wasReset = true;
    value = -1.0;
  }
}

void main() {
  late GameBalanceConfig cfg;
  late RewindBuffer buffer;
  late FakeRewindable a;
  late FakeRewindable b;

  setUp(() {
    cfg = const GameBalanceConfig();
    buffer = RewindBuffer(cfg);
    a = FakeRewindable(10);
    b = FakeRewindable(11);
  });

  test('respects the capture interval', () {
    final targets = <Rewindable>[a];
    expect(buffer.maybeCapture(0.0, 0.0, targets), isTrue);
    expect(buffer.maybeCapture(cfg.snapshotInterval * 0.4, 1.0, targets), isFalse);
    expect(buffer.maybeCapture(cfg.snapshotInterval * 1.1, 2.0, targets), isTrue);
    expect(buffer.count, 2);
  });

  test('discards snapshots older than the rewind window', () {
    final targets = <Rewindable>[a];
    for (var t = 0.0; t < cfg.maxRewindSeconds * 3; t += cfg.snapshotInterval) {
      a.value = t;
      buffer.capture(t, t * 10.0, targets);
    }

    expect(buffer.count, lessThanOrEqualTo(buffer.capacity));
    expect(
      buffer.bufferedSeconds,
      lessThanOrEqualTo(cfg.maxRewindSeconds + cfg.snapshotInterval * 2),
    );
  });

  test('restores the state that was live at the requested time', () {
    final targets = <Rewindable>[a];
    for (var i = 0; i < 30; i++) {
      a.value = i.toDouble();
      buffer.capture(i * cfg.snapshotInterval, 0.0, targets);
    }

    a.value = 999.0;
    buffer.restoreTo(10 * cfg.snapshotInterval, {a.rewindId: a});

    expect(a.value, 10.0);
  });

  test('interpolates flow position between snapshots', () {
    final targets = <Rewindable>[a];
    buffer.capture(0.0, 0.0, targets);
    buffer.capture(1.0, 100.0, targets);

    expect(buffer.flowPositionAt(0.5), closeTo(50.0, 1e-9));
    expect(buffer.flowPositionAt(0.0), closeTo(0.0, 1e-9));
    expect(buffer.flowPositionAt(1.0), closeTo(100.0, 1e-9));
  });

  test('clamps flow position lookups outside the buffered range', () {
    buffer.capture(2.0, 40.0, <Rewindable>[a]);

    expect(buffer.flowPositionAt(0.0), 40.0);
    expect(buffer.flowPositionAt(99.0), 40.0);
  });

  test('returns null when the buffer is empty', () {
    expect(buffer.flowPositionAt(1.0), isNull);
    expect(buffer.restoreTo(1.0, <int, Rewindable>{}), isFalse);
  });

  test('resets objects that did not exist at the restored time', () {
    a.value = 5.0;
    buffer.capture(0.0, 0.0, <Rewindable>[a]);

    buffer.restoreTo(0.0, {a.rewindId: a, b.rewindId: b});

    expect(a.value, 5.0);
    expect(b.wasReset, isTrue);
  });

  test('discardAfter removes the future the player no longer took', () {
    final targets = <Rewindable>[a];
    for (var i = 0; i < 20; i++) {
      buffer.capture(i * cfg.snapshotInterval, i.toDouble(), targets);
    }

    buffer.discardAfter(5 * cfg.snapshotInterval);

    expect(buffer.newestTime, closeTo(5 * cfg.snapshotInterval, 1e-9));
    // A new capture immediately after the discard must be accepted.
    expect(
      buffer.maybeCapture(6 * cfg.snapshotInterval, 6.0, targets),
      isTrue,
    );
  });

  test('multiple objects round-trip independently', () {
    a.value = 1.5;
    b.value = -2.5;
    buffer.capture(0.0, 0.0, <Rewindable>[a, b]);

    a.value = 0.0;
    b.value = 0.0;
    buffer.restoreTo(0.0, {a.rewindId: a, b.rewindId: b});

    expect(a.value, 1.5);
    expect(b.value, -2.5);
  });
}
