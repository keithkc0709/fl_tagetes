import 'package:flowline/core/game_balance_config.dart';
import 'package:flowline/game/obstacles/obstacle_family.dart';
import 'package:flowline/game/rewind/rewind_buffer.dart';
import 'package:flowline/game/rewind/rewindable.dart';
import 'package:flowline/game/scoring/scoring_system.dart';
import 'package:flowline/models/score_event.dart';
import 'package:flutter_test/flutter_test.dart';

const GameBalanceConfig cfg = GameBalanceConfig();

ScoreEvent award(ScoringSystem s, Grade grade, {double precision = 1.0}) =>
    s.register(
      grade: grade,
      family: ObstacleFamily.movingGate,
      precision: precision,
      gameTime: 0.0,
    );

void main() {
  late ScoringSystem scoring;

  setUp(() => scoring = ScoringSystem(cfg));

  group('grading', () {
    test('maps precision onto the four grades', () {
      expect(scoring.gradeFor(1.0, collided: false), Grade.perfect);
      expect(
        scoring.gradeFor(cfg.perfectThreshold, collided: false),
        Grade.perfect,
      );
      expect(
        scoring.gradeFor(cfg.perfectThreshold - 0.01, collided: false),
        Grade.good,
      );
      expect(scoring.gradeFor(cfg.goodThreshold, collided: false), Grade.good);
      expect(
        scoring.gradeFor(cfg.goodThreshold - 0.01, collided: false),
        Grade.pass,
      );
      expect(scoring.gradeFor(0.0, collided: false), Grade.pass);
    });

    test('a collision is a fail regardless of precision', () {
      expect(scoring.gradeFor(1.0, collided: true), Grade.fail);
    });
  });

  group('points', () {
    test('perfect beats good beats pass', () {
      final pass = award(ScoringSystem(cfg), Grade.pass).points;
      final good = award(ScoringSystem(cfg), Grade.good).points;
      final perfect = award(ScoringSystem(cfg), Grade.perfect).points;

      expect(pass, cfg.basePoints);
      expect(good, greaterThan(pass));
      expect(perfect, greaterThan(good));
    });

    test('a fail scores nothing', () {
      expect(award(scoring, Grade.fail).points, 0);
      expect(scoring.score, 0);
    });
  });

  group('combo', () {
    test('perfect and good build the combo, a scrappy pass does not', () {
      award(scoring, Grade.perfect);
      award(scoring, Grade.good);
      expect(scoring.combo, 2);

      award(scoring, Grade.pass);
      expect(scoring.combo, 2);
    });

    test('the multiplier steps up and is capped', () {
      for (var i = 0; i < 200; i++) {
        award(scoring, Grade.perfect);
      }
      expect(scoring.comboMultiplier, cfg.maxComboMultiplier);
    });

    test('the multiplier only moves at the configured step size', () {
      for (var i = 0; i < cfg.comboStep - 1; i++) {
        award(scoring, Grade.perfect);
      }
      expect(scoring.comboMultiplier, 1.0);

      award(scoring, Grade.perfect);
      expect(
        scoring.comboMultiplier,
        closeTo(1.0 + cfg.comboMultiplierStep, 1e-9),
      );
    });

    test('a fail breaks the combo but keeps the best', () {
      for (var i = 0; i < 7; i++) {
        award(scoring, Grade.perfect);
      }
      expect(scoring.bestCombo, 7);

      award(scoring, Grade.fail);
      expect(scoring.combo, 0);
      expect(scoring.bestCombo, 7);
    });

    test('scores do not inflate unreadably over a long clean run', () {
      for (var i = 0; i < 120; i++) {
        award(scoring, Grade.perfect);
      }
      // 120 flawless passes should still be a legible four-digit number.
      expect(scoring.score, lessThan(100000));
    });
  });

  group('rewind integrity', () {
    test('scrubbing back and forth cannot farm the same gate twice', () {
      final buffer = RewindBuffer(cfg);
      final targets = <Rewindable>[scoring];

      buffer.capture(0.0, 0.0, targets);
      award(scoring, Grade.perfect);
      final afterFirstAward = scoring.score;
      buffer.capture(1.0, 10.0, targets);

      // Rewind to before the gate was cleared.
      buffer.restoreTo(0.0, {scoring.rewindId: scoring});
      expect(scoring.score, 0);
      expect(scoring.combo, 0);
      expect(scoring.perfectCount, 0);

      // Clear it again: the score lands in the same place, not double.
      award(scoring, Grade.perfect);
      expect(scoring.score, afterFirstAward);
    });

    test('tallies round-trip exactly', () {
      final buffer = RewindBuffer(cfg);
      award(scoring, Grade.perfect);
      award(scoring, Grade.good);
      award(scoring, Grade.pass);
      award(scoring, Grade.fail);
      buffer.capture(0.0, 0.0, <Rewindable>[scoring]);

      final expectedScore = scoring.score;
      scoring.reset();
      buffer.restoreTo(0.0, {scoring.rewindId: scoring});

      expect(scoring.score, expectedScore);
      expect(scoring.perfectCount, 1);
      expect(scoring.goodCount, 1);
      expect(scoring.passCount, 1);
      expect(scoring.failCount, 1);
    });
  });
}
