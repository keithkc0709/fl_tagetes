import 'package:flowline/core/game_balance_config.dart';
import 'package:flowline/game/time/time_controller.dart';
import 'package:flutter_test/flutter_test.dart';

const double frame = 1 / 60;

/// Drives the controller as if a thumb were dragging at a steady speed.
void drag(
  TimeController controller,
  double pixelsPerSecond,
  int frames, {
  double dt = frame,
}) {
  for (var i = 0; i < frames; i++) {
    controller.onPointerMove(pixelsPerSecond * dt);
    controller.update(dt);
  }
}

void main() {
  late GameBalanceConfig cfg;
  late TimeController controller;

  setUp(() {
    cfg = const GameBalanceConfig();
    controller = TimeController(cfg);
  });

  group('forward time scale', () {
    test('a stationary thumb freezes the simulation', () {
      controller.onPointerDown();
      drag(controller, 900, 40);
      expect(controller.actualTimeScale, greaterThan(0.3));

      // Thumb still on glass, no movement at all.
      drag(controller, 0, 60);

      expect(controller.actualTimeScale, lessThan(cfg.freezeEpsilon + 1e-9));
      expect(controller.isFrozen, isTrue);
      expect(controller.state, TimeFlowState.frozen);
    });

    test('a slow drag produces slow time, not stopped time', () {
      controller.onPointerDown();
      drag(controller, 220, 90);

      expect(controller.actualTimeScale, greaterThan(0.1));
      expect(controller.actualTimeScale, lessThan(0.6));
      expect(controller.gameTime, greaterThan(0.0));
    });

    test('a normal feed-speed scroll lands near 1x', () {
      controller.onPointerDown();
      drag(controller, cfg.referenceScrollSpeed, 120);

      expect(controller.actualTimeScale, closeTo(1.0, 0.2));
    });

    test('a flick accelerates but is capped', () {
      controller.onPointerDown();
      drag(controller, 5000, 120);

      expect(
        controller.actualTimeScale,
        greaterThan(cfg.normalMaxTimeScale),
      );
      expect(
        controller.actualTimeScale,
        lessThanOrEqualTo(cfg.maxForwardTimeScale + 1e-6),
      );
    });

    test('an ordinary scroll cannot reach the flick-only ceiling', () {
      controller.onPointerDown();
      drag(controller, cfg.flickThresholdSpeed - 400, 120);

      expect(
        controller.actualTimeScale,
        lessThanOrEqualTo(cfg.normalMaxTimeScale + 1e-6),
      );
    });

    test('game time never advances faster than the cap allows', () {
      controller.onPointerDown();
      const frames = 240;
      drag(controller, 8000, frames);

      expect(
        controller.gameTime,
        lessThanOrEqualTo(cfg.maxForwardTimeScale * frames * frame + 1e-6),
      );
    });
  });

  group('frame-rate independence', () {
    test('the same gesture advances the same game time at 30 and 120 fps', () {
      const speed = 900.0;
      const seconds = 1.5;

      final slow = TimeController(cfg)..onPointerDown();
      drag(slow, speed, (seconds * 30).round(), dt: 1 / 30);

      final fast = TimeController(cfg)..onPointerDown();
      drag(fast, speed, (seconds * 120).round(), dt: 1 / 120);

      expect(fast.gameTime, closeTo(slow.gameTime, 0.05));
      expect(fast.flowPosition, closeTo(slow.flowPosition, 0.5));
    });

    test('a long stall cannot teleport the simulation', () {
      controller.onPointerDown();
      controller.onPointerMove(2000);
      controller.update(5.0); // simulated hitch

      expect(controller.gameTime, lessThanOrEqualTo(cfg.maxRealDelta * 4));
    });
  });

  group('rewind', () {
    test('a downward drag reverses game time', () {
      controller.onPointerDown();
      drag(controller, 1200, 120);
      final peak = controller.gameTime;
      expect(peak, greaterThan(0.5));

      drag(controller, -1200, 60);

      expect(controller.isRewinding, isTrue);
      expect(controller.state, TimeFlowState.rewinding);
      expect(controller.gameTime, lessThan(peak));
    });

    test('rewind cannot pass the history floor', () {
      controller.onPointerDown();
      drag(controller, 1400, 400);
      final peak = controller.maxGameTime;

      drag(controller, -4000, 600);

      expect(
        controller.gameTime,
        greaterThanOrEqualTo(peak - cfg.maxRewindSeconds - 1e-6),
      );
    });

    test('resuming forward motion leaves the rewinding state cleanly', () {
      controller.onPointerDown();
      drag(controller, 1200, 120);
      drag(controller, -1200, 40);
      expect(controller.isRewinding, isTrue);

      drag(controller, 1200, 60);

      expect(controller.isRewinding, isFalse);
      expect(controller.state, TimeFlowState.forward);
      expect(controller.actualTimeScale, greaterThan(0.0));
    });

    test('auto rewind overrides input and completes on its own', () {
      controller.onPointerDown();
      drag(controller, 1200, 180);
      final before = controller.gameTime;

      controller.requestAutoRewind(cfg.autoRewindSeconds);
      expect(controller.state, TimeFlowState.autoRewinding);

      for (var i = 0; i < 240 && controller.isAutoRewinding; i++) {
        controller.update(frame);
      }

      expect(controller.isAutoRewinding, isFalse);
      expect(
        controller.gameTime,
        closeTo(before - cfg.autoRewindSeconds, 0.05),
      );
    });

    test('rewind is unavailable with no history', () {
      controller.onPointerDown();
      drag(controller, -1500, 60);

      expect(controller.isRewinding, isFalse);
      expect(controller.gameTime, 0.0);
    });
  });

  group('flow position', () {
    test('advances with displacement, not merely with time', () {
      controller.onPointerDown();
      drag(controller, 1000, 60);
      final flowAfterDrag = controller.flowPosition;

      // Same elapsed time, no displacement at all.
      final other = TimeController(cfg)..onPointerDown();
      drag(other, 0, 60);

      expect(flowAfterDrag, greaterThan(0.0));
      expect(other.flowPosition, 0.0);
    });

    test('never moves backwards on a forward drag', () {
      controller.onPointerDown();
      var previous = 0.0;
      for (var i = 0; i < 200; i++) {
        controller.onPointerMove(i.isEven ? 12 : 0);
        controller.update(frame);
        expect(controller.flowPosition, greaterThanOrEqualTo(previous));
        previous = controller.flowPosition;
      }
    });
  });
}
